declare type Account = {
  readonly id: string
  name: string
}

declare interface ProviderInfo {
  name: string
  baseURL: string
  apiUrl: string
  models: string[]
}

declare type LiveControlPlatform =
  | 'douyin'
  | 'buyin'
  | 'eos'
  | 'xiaohongshu'
  | 'pgy'
  | 'wxchannel'
  | 'kuaishou'
  | 'taobao'
  | 'tiktok'
  | 'dev'

declare type LivePlatformConfig = {
  tiktokUsername?: string
}

declare type GoodsItem = {
  id: number
  /** 单品循环弹窗次数，默认 1 */
  repeatCount?: number
  /** 单品弹窗间隔 [min, max] 毫秒，不设则用全局间隔 */
  itemInterval?: [number, number]
}

declare type AutoPopupConfig = {
  scheduler: {
    interval: [number, number]
  }
  goodsIds: number[]
  goodsItems?: GoodsItem[]
  random?: boolean
}

declare type AutoPopupTask = {
  type: 'auto-popup'
  config: AutoPopupConfig
}

declare type AutoCommentConfig = {
  scheduler: {
    interval: [number, number]
  }
  messages: {
    content: string
    pinTop: boolean
  }[]
  random?: boolean
  extraSpaces?: boolean
  unlimitedLength?: boolean
}

declare type AutoCommentTask = {
  type: 'auto-comment'
  config: AutoCommentConfig
}

declare type SendBatchMessagesConfig = {
  messages: string[]
  count: number
  noSpace?: boolean
}

declare type SendBatchMessagesTask = {
  type: 'send-batch-messages'
  config: SendBatchMessagesConfig
}

declare interface CommentListenerConfig {
  source:
    | 'compass'
    | 'control'
    | 'wechat-channel'
    | 'xiaohongshu'
    | 'taobao'
    | 'kuaishou'
    | 'tiktok'
  ws?: {
    port: number
  }
}

declare type CommentListenerTask = {
  type: 'comment-listener'
  config: CommentListenerConfig
}

declare type PinCommentTask = {
  type: 'pin-comment'
  config: {
    comment: string
  }
}

declare type LiveControlTask =
  | AutoPopupTask
  | AutoCommentTask
  | SendBatchMessagesTask
  | CommentListenerTask
  | PinCommentTask

declare type DouyinLiveMessage = {
  time: number
} & (
  | CommentMessage
  | RoomEnterMessage
  | RoomLikeMessage
  | LiveOrderMessage
  | SubscribeMerchantBrandVipMessage
  | RoomFollowMessage
  | EcomFansclubParticipateMessage
)

interface CommentMessage {
  msg_type: 'comment'
  msg_id: string
  nick_name: string
  content: string
}

interface RoomEnterMessage {
  msg_type: 'room_enter'
  msg_id: string
  nick_name: string
  user_id: string
}

interface RoomLikeMessage {
  msg_type: 'room_like'
  msg_id: string
  nick_name: string
  user_id: string
}

interface SubscribeMerchantBrandVipMessage {
  msg_type: 'subscribe_merchant_brand_vip'
  msg_id: string
  nick_name: string
  user_id: string
  content: string
}

interface RoomFollowMessage {
  msg_type: 'room_follow'
  msg_id: string
  nick_name: string
  user_id: string
}

interface EcomFansclubParticipateMessage {
  msg_type: 'ecom_fansclub_participate'
  msg_id: string
  nick_name: string
  user_id: string
  content: string
}

interface LiveOrderMessage {
  msg_type: 'live_order'
  nick_name: string
  msg_id: string
  order_status: '已下单' | '已付款' | '未知状态'
  order_ts: number
  product_id: string
  product_title: string
}

declare type WechatChannelLiveMessage = {
  msg_type: 'wechat_channel_live_msg'
  msg_id: string
  nick_name: string
  user_id: string
  content: string
  time: number
}

declare type XiaohongshuCommentLiveMessage = {
  is_self?: boolean
  msg_type: 'xiaohongshu_comment'
  msg_id: string
  nick_name: string
  user_id: string
  content: string
  time: number
}

declare type XiaohongshuMemberLiveMessage = {
  msg_type: 'xiaohongshu_member'
  msg_id: string
  nick_name: string
  user_id: string
  follow_status: number
  role: number
  room_id: string
  time: number
}

declare type XiaohongshuFollowLiveMessage = {
  msg_type: 'xiaohongshu_follow'
  msg_id: string
  nick_name: string
  user_id: string
  follow_status: number
  room_id: string
  time: number
}

declare type TaobaoCommentLiveMessage = {
  msg_type: 'taobao_comment'
  msg_id: string
  nick_name: string
  user_id: string
  content: string
  time: number
}

/** Positive or nonempty public SDK facts; decoder defaults are deliberately absent. */
declare type TikTokPublicViewerMetadata = {
  avatarUrl?: string
  followingCount?: number
  followStatus?: number
  subscriptionActive?: true
  bio?: string
}

declare type TikTokCommentLiveMessage = {
  msg_type: 'tiktok_comment'
  msg_id: string
  nick_name: string
  user_id: string
  unique_id: string
  mention_handle?: string
  pay_level?: number
  fans_club_level?: number
  follower_count?: number
  public_profile?: TikTokPublicViewerMetadata
  content: string
  time: number
}

declare type TikTokMemberLiveMessage = {
  msg_type: 'tiktok_member'
  msg_id: string
  nick_name: string
  user_id: string
  unique_id: string
  mention_handle?: string
  member_action?: number
  fans_club_level?: number
  pay_level?: number
  follower_count?: number
  public_profile?: TikTokPublicViewerMetadata
  is_subscriber: boolean
  follow_status: string
  time: number
}

declare type TikTokLeaveLiveMessage = Omit<TikTokMemberLiveMessage, 'msg_type'> & { msg_type: 'tiktok_leave' }

declare type TikTokEngagementLiveMessage = {
  msg_type: 'tiktok_follow' | 'tiktok_like'
  msg_id: string
  nick_name: string
  user_id: string
  unique_id: string
  mention_handle?: string
  pay_level?: number
  fans_club_level?: number
  follower_count?: number
  public_profile?: TikTokPublicViewerMetadata
  like_count?: number
  time: number
}

declare type TikTokGiftLiveMessage = {
  msg_type: 'tiktok_gift'
  msg_id: string
  nick_name: string
  user_id: string
  unique_id: string
  mention_handle?: string
  pay_level?: number
  fans_club_level?: number
  follower_count?: number
  public_profile?: TikTokPublicViewerMetadata
  time: number
  /** Empty when neither the event nor the active connection proves a numeric room ID. */
  room_id: string
  gift_id: string
  gift_name: string
  gift_type: number
  repeat_count: number
  repeat_end: boolean
  group_id?: string
  /** Native gift.diamondCount; unknown or invalid values are omitted, never cash-converted. */
  gift_unit_coins?: number
  /** Unit coins times this snapshot's repeat_count; omitted if the product is unsafe. */
  gift_total_coins?: number
}

declare type LiveMessage = (
  | WechatChannelLiveMessage
  | DouyinLiveMessage
  | XiaohongshuCommentLiveMessage
  | XiaohongshuMemberLiveMessage
  | XiaohongshuFollowLiveMessage
  | TaobaoCommentLiveMessage
  | TikTokCommentLiveMessage
  | TikTokMemberLiveMessage
  | TikTokLeaveLiveMessage
  | TikTokEngagementLiveMessage
  | TikTokGiftLiveMessage
) & { metadata?: import('./browserTranslation').LiveMessageTranslationMetadata }
