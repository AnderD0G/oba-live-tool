import type { LogMessage } from 'electron-log'
import type { ProgressInfo, UpdateDownloadedEvent } from 'electron-updater'
import type { AnalysisChanged, AnalysisCommand, AnalysisResponse } from './analysisRoom'
import type { AssistantDeskCommand, AssistantDeskResult } from './assistantDesk'
import type { AssistantVoiceCommand, AssistantVoiceResult } from './assistantVoice'
import type { MobileAssistantAccessCommand, MobileAssistantAccessResult } from './mobileAssistantDesk'
import type { EffectGroupCommand } from './effectGroups'
import type { PlatformSessionCommand, PlatformSessionResult } from './platformSession'
import type { AuditEntry } from './audit'
import type { TicketCommand, TicketResponse } from './capturePrinting'
import type { CodexAutoSettings, CodexAutoState } from './codexAutoReply'
import type { CodexDraftRequest, CodexDraftResult, CodexStatus } from './codexDraft'
import type { CatcherCommand, CatcherResponse } from './commentCatcher'
import type {
  DeepSeekAutoCommand,
  DeepSeekAutoSettings,
  HumanLiveCameraStatus,
  HumanLiveItem,
} from './deepSeekAuto'
import type { DirectorCommand, DirectorResponse } from './director'
import type { DirectorExperimentCommand, DirectorExperimentResponse } from './directorExperiment'
import type { HookCommand, HookResponse } from './hooks'
import { IPC_CHANNELS } from './ipcChannels'
import type { ObsEffectCommand, ObsEffectResponse } from './obsEffect'
import type { SetupAction, SetupResult } from './setup'

export interface IpcChannels {
  [IPC_CHANNELS.assistantDesk.request]: (command:AssistantDeskCommand)=>Promise<AssistantDeskResult>
  [IPC_CHANNELS.assistantVoice.request]: (command:AssistantVoiceCommand)=>Promise<AssistantVoiceResult>
  [IPC_CHANNELS.assistantMobile.request]: (command:MobileAssistantAccessCommand)=>Promise<MobileAssistantAccessResult>
  [IPC_CHANNELS.effectGroups.request]: (command:EffectGroupCommand)=>Promise<AssistantDeskResult>
  [IPC_CHANNELS.platformSession.request]: (command:PlatformSessionCommand)=>Promise<PlatformSessionResult>
  [IPC_CHANNELS.analysisRoom.request]: (command: AnalysisCommand) => Promise<AnalysisResponse>
  [IPC_CHANNELS.analysisRoom.changed]: (change: AnalysisChanged) => void
  [IPC_CHANNELS.audit.list]: (accountId?: string) => Promise<AuditEntry[]>
  [IPC_CHANNELS.director.request]: (command: DirectorCommand) => Promise<DirectorResponse>
  [IPC_CHANNELS.directorExperiment.request]: (command: DirectorExperimentCommand) => Promise<DirectorExperimentResponse>
  [IPC_CHANNELS.deepSeekAuto.request]: (command: DeepSeekAutoCommand) => Promise<{
    ok: boolean
    error?: string
    message?: string
    settings?: DeepSeekAutoSettings
    hasKey?: boolean
    enabled?: boolean
    records?: import('./director').LiveInteractionRecord[]
    humanItems?: HumanLiveItem[]
    companionUrl?: string
    companionUrls?: string[]
    cameraStatus?: HumanLiveCameraStatus
    viewerCount?: number
  }>
  [IPC_CHANNELS.hooks.request]: (command: HookCommand) => Promise<HookResponse>
  [IPC_CHANNELS.obsEffect.request]: (command: ObsEffectCommand) => Promise<ObsEffectResponse>
  [IPC_CHANNELS.setup.request]: (action: SetupAction) => Promise<SetupResult>
  [IPC_CHANNELS.catcher.request]: (command: CatcherCommand) => Promise<CatcherResponse>
  [IPC_CHANNELS.tickets.request]: (command: TicketCommand) => Promise<TicketResponse>
  [IPC_CHANNELS.codexAuto.configure]: (
    settings: CodexAutoSettings,
  ) => Promise<{ ok: boolean; error?: string }>
  [IPC_CHANNELS.codexAuto.state]: () => CodexAutoState
  [IPC_CHANNELS.codexAuto.voiceStatus]: () => Promise<{ ok: boolean; message: string }>
  [IPC_CHANNELS.codexAuto.changed]: (state: CodexAutoState) => void
  [IPC_CHANNELS.codexDraft.status]: () => Promise<CodexStatus>
  [IPC_CHANNELS.codexDraft.generate]: (request: CodexDraftRequest) => Promise<CodexDraftResult>
  [IPC_CHANNELS.codexDraft.cancel]: (requestId: string) => boolean
  [IPC_CHANNELS.codexDraft.progress]: (event: {
    requestId: string
    message: string
    text?: string
  }) => void
  // LiveControl
  [IPC_CHANNELS.tasks.liveControl.connect]: (params: {
    chromePath?: string
    headless?: boolean
    storageState?: string
    platform: LiveControlPlatform
    account: Account
    platformConfig?: LivePlatformConfig
  }) => boolean
  [IPC_CHANNELS.tasks.liveControl.disconnect]: (accountId: string) => boolean
  [IPC_CHANNELS.tasks.liveControl.disconnectedEvent]: (id: string) => void
  [IPC_CHANNELS.tasks.liveControl.notifyAccountName]: (
    params:
      | {
          ok: true
          accountId: string
          accountName: string | null
        }
      | { ok: false },
  ) => void

  // AutoMessage
  [IPC_CHANNELS.tasks.autoMessage.start]: (accountId: string, config: AutoCommentConfig) => boolean
  [IPC_CHANNELS.tasks.autoMessage.stop]: (accountId: string) => boolean
  [IPC_CHANNELS.tasks.autoMessage.stoppedEvent]: (id: string) => void
  [IPC_CHANNELS.tasks.autoMessage.sendBatchMessages]: (
    accountId: string,
    messages: string[],
    count: number,
  ) => boolean
  [IPC_CHANNELS.tasks.autoMessage.updateConfig]: (
    accountId: string,
    config: Parital<AutoCommentConfig>,
  ) => void

  // AutoPopup
  [IPC_CHANNELS.tasks.autoPopUp.start]: (accountId: string, config: AutoPopupConfig) => boolean
  [IPC_CHANNELS.tasks.autoPopUp.stop]: (accountId: string) => boolean
  [IPC_CHANNELS.tasks.autoPopUp.stoppedEvent]: (id: string) => void
  [IPC_CHANNELS.tasks.autoPopUp.updateConfig]: (
    accountId: string,
    config: Parital<AutoPopupConfig>,
  ) => void
  [IPC_CHANNELS.tasks.autoPopUp.registerShortcuts]: (
    accountId: string,
    shortcuts: { accelerator: string; goodsIds: number[] }[],
  ) => void
  [IPC_CHANNELS.tasks.autoPopUp.unregisterShortcuts]: () => void

  // AutoReply
  [IPC_CHANNELS.tasks.autoReply.startCommentListener]: (
    accountId: string,
    config: CommentListenerConfig,
  ) => boolean
  [IPC_CHANNELS.tasks.autoReply.stopCommentListener]: (accountId: string) => void
  [IPC_CHANNELS.tasks.autoReply.sendReply]: (accountId: string, replyContent: string) => boolean
  [IPC_CHANNELS.tasks.autoReply.listenerStopped]: (accountId: string) => void
  [IPC_CHANNELS.tasks.autoReply.showComment]: (data: {
    comment: LiveMessage
    accountId: string
  }) => void

  // AIChat
  [IPC_CHANNELS.tasks.aiChat.normalChat]: (params: {
    messages: AIChatMessage[]
    provider: string
    model: string
    apiKey: string
    customBaseURL?: string
  }) => string | null
  [IPC_CHANNELS.tasks.aiChat.testApiKey]: (params: {
    apiKey: string
    provider: string
    customBaseURL?: string
  }) => { success: boolean; models?: string[]; error?: string }
  [IPC_CHANNELS.tasks.aiChat.chat]: (params: {
    messages: AIChatMessage[]
    provider: string
    model: string
    apiKey: string
    customBaseURL?: string
  }) => void
  [IPC_CHANNELS.tasks.aiChat.stream]: (
    data:
      | {
          chunk: string
          type: 'content' | 'reasoning'
        }
      | { done: boolean },
  ) => void
  [IPC_CHANNELS.tasks.aiChat.error]: (data: { error: string }) => void

  // 视频号上墙
  [IPC_CHANNELS.tasks.pinComment]: (params: { accountId: string; content: string }) => void

  // 一键发红包
  [IPC_CHANNELS.tasks.redPacket.send]: (accountId: string, duration: string) => boolean

  // Updater
  [IPC_CHANNELS.updater.checkUpdate]: () => Promise<
    { latestVersion: string; currentVersion: string; releaseNote?: string } | undefined
  >
  [IPC_CHANNELS.updater.startDownload]: (source: string) => void
  [IPC_CHANNELS.updater.quitAndInstall]: () => void
  [IPC_CHANNELS.updater.updateAvailable]: (info: VersionInfo) => void
  [IPC_CHANNELS.updater.updateError]: (error: ErrorType) => void
  [IPC_CHANNELS.updater.downloadProgress]: (progress: ProgressInfo) => void
  [IPC_CHANNELS.updater.updateDownloaded]: (event?: UpdateDownloadedEvent) => void

  // Chrome
  [IPC_CHANNELS.chrome.selectPath]: () => string | null
  [IPC_CHANNELS.chrome.getPath]: (edge?: boolean) => string | null
  [IPC_CHANNELS.chrome.toggleDevTools]: () => void
  [IPC_CHANNELS.chrome.setPath]: (path: string) => void
  [IPC_CHANNELS.chrome.saveState]: (accountId: string, state: string) => void

  // App
  [IPC_CHANNELS.app.openLogFolder]: () => void
  [IPC_CHANNELS.app.openExternal]: (url: string) => void
  [IPC_CHANNELS.app.notifyUpdate]: (arg: {
    currentVersion: string
    latestVersion: string
    releaseNote?: string
  }) => void
  [IPC_CHANNELS.app.getProviders]: () => Record<string, ProviderInfo>
  [IPC_CHANNELS.app.providersUpdated]: (providers: Record<string, ProviderInfo>) => void

  [IPC_CHANNELS.account.switch]: (params: { account: Account }) => void

  // Log
  [IPC_CHANNELS.log]: (message: LogMessage) => void
}

export interface ElectronAPI {
  ipcRenderer: {
    invoke: <Channel extends keyof IpcChannels>(
      channel: Channel,
      ...args: Parameters<IpcChannels[Channel]>
    ) => ReturnType<IpcChannels[Channel]> extends Promise<infer _U>
      ? ReturnType<IpcChannels[Channel]>
      : Promise<ReturnType<IpcChannels[Channel]>>

    send: <Channel extends keyof IpcChannels>(
      channel: Channel,
      ...args: Parameters<IpcChannels[Channel]>
    ) => void

    on: <Channel extends keyof IpcChannels>(
      channel: Channel,
      listener: (...args: Parameters<IpcChannels[Channel]>) => void,
    ) => () => void
  }
}
