import type { Result } from '@praha/byethrow'
import type { Page } from 'playwright'
import type { PlatformError } from '#/errors/PlatformError'
import type { BrowserSession } from '#/managers/BrowserSessionManager'
import type { AnalysisScope, BusinessObservation, CaptureTransports } from '../../../shared/analysisRoom'
import type { TikTokWireDiagnosticsSnapshot } from '../../../shared/platformPageDiagnostics'
import type { PlatformLoginSnapshot, PlatformLoginQrPreview } from '../../../shared/platformSession'
import type { BrowserTranslationObservation } from '../../../shared/browserTranslation'

/** Optional passive rendering channel; its subscribers never receive canonical platform events. */
export interface ITranslationObserver {
  subscribeTranslations(listener: (observation: BrowserTranslationObservation) => void): () => void
}
export function isTranslationObserver(platform: unknown): platform is ITranslationObserver {
  return !!platform && typeof platform === 'object' && 'subscribeTranslations' in platform && typeof platform.subscribeTranslations === 'function'
}

export interface ICommentListener {
  _isCommentListener: true
  startCommentListener(
    onComment: (comment: LiveMessage) => void,
    /** 暂定，control 为中控台互动评论监听， compass 为直播大屏监听 */
    source: CommentListenerConfig['source'],
  ): void | Promise<void>
  stopCommentListener(): void | Promise<void>
  /** Unexpected loss of the current listener page; ordinary stop must not emit this. */
  subscribeListenerInvalidation?(listener: (reason: string) => void): () => void
  getCommentListenerPage(): Page
  getSdkNetworkDiagnostics?(marker?: string): TikTokWireDiagnosticsSnapshot
}

export type BusinessSourceObservation = Omit<BusinessObservation, 'scope'>
export interface IBusinessDataSource {
  subscribeBusiness(listener: (observation: BusinessSourceObservation) => void): () => void
  businessCapabilities(): { sources: AnalysisScope['source'][]; formatVersion: number; captureTransports?: CaptureTransports }
}

export function isBusinessDataSource(platform: unknown): platform is IBusinessDataSource {
  return (
    !!platform &&
    typeof platform === 'object' &&
    'subscribeBusiness' in platform &&
    typeof platform.subscribeBusiness === 'function' &&
    'businessCapabilities' in platform &&
    typeof platform.businessCapabilities === 'function'
  )
}

export function isCommentListener(platform: IPlatform): platform is IPlatform & ICommentListener {
  return '_isCommentListener' in platform && platform._isCommentListener === true
}

export interface IPerformPopup {
  _isPerformPopup: true
  /** 弹窗指定商品序号 */
  performPopup(id: number, signal?: AbortSignal): Result.ResultAsync<void, Error>
  /** 获取弹窗任务所需的页面 */
  getPopupPage(): Page | null
}

export function isPerformPopup(platform: IPlatform): platform is IPlatform & IPerformPopup {
  return '_isPerformPopup' in platform && platform._isPerformPopup === true
}

export interface IPerformComment {
  _isPerformComment: true
  /** 在互动评论区域发送评论，返回结果表示是否成功置顶 */
  performComment(message: string, pinTop?: boolean): Result.ResultAsync<boolean, PlatformError>
  /** 获取评论任务所需的页面 */
  getCommentPage(): Page | null
}

export function isPerformComment(platform: IPlatform): platform is IPlatform & IPerformComment {
  return '_isPerformComment' in platform && platform._isPerformComment === true
}

export interface IPinComment {
  _isPinComment: true
  /** 置顶评论 */
  pinComment(comment: string, signal?: AbortSignal): Result.ResultAsync<void, PlatformError>
  /** 获取置顶评论任务所需的页面 */
  getPinCommentPage(): Page | null
}

export function isPinComment(platform: IPlatform): platform is IPlatform & IPinComment {
  return '_isPinComment' in platform && platform._isPinComment === true
}

export interface ISendRedPacket {
  _isSendRedPacket: true
  /** 一键发红包：点击发红包按钮，选择店铺红包，投放已有红包，选择限时领取时长 */
  sendRedPacket(duration: string, signal?: AbortSignal): Result.ResultAsync<void, PlatformError>
  getRedPacketPage(): Page | null
}

export function isSendRedPacket(platform: IPlatform): platform is IPlatform & ISendRedPacket {
  return '_isSendRedPacket' in platform && platform._isSendRedPacket === true
}

export interface IPlatform {
  get platformName(): string
  /** 连接到中控台，最终停留在中控台页面 */
  connect(browserSession: BrowserSession): Promise<boolean>
  /** 登录 */
  login(browserSession: BrowserSession): Promise<void>
  /** 在中控台页面获取用户名 */
  getAccountName(session: BrowserSession): Promise<string>

  disconnect(): Promise<void>
}

/** Optional split login/room workflow; connect/login remain compatible with older callers. */
export interface ILoginFirstPlatform {
  _isLoginFirstPlatform: true
  openLoginBrowser(session: BrowserSession): Promise<void>
  /** Adopts an already open, authenticated live page without navigating it. */
  attachLoginBrowser?(session: BrowserSession, pageUrl: string): Promise<void>
  getPlatformSessionState(session: BrowserSession): Promise<PlatformLoginSnapshot>
  setLiveTarget(session: BrowserSession, target: string): Promise<void>
  getLoginQrPreview(session: BrowserSession): Promise<PlatformLoginQrPreview>
}

export function isLoginFirstPlatform(platform: IPlatform): platform is IPlatform & ILoginFirstPlatform {
  return '_isLoginFirstPlatform' in platform && platform._isLoginFirstPlatform === true &&
    'openLoginBrowser' in platform && typeof platform.openLoginBrowser === 'function' &&
    'getPlatformSessionState' in platform && typeof platform.getPlatformSessionState === 'function' &&
    'setLiveTarget' in platform && typeof platform.setLiveTarget === 'function' &&
    'getLoginQrPreview' in platform && typeof platform.getLoginQrPreview === 'function'
}

export interface IConfigurablePlatform {
  configure(config: LivePlatformConfig): void
}

export function isConfigurablePlatform(
  platform: IPlatform,
): platform is IPlatform & IConfigurablePlatform {
  return 'configure' in platform && typeof platform.configure === 'function'
}
