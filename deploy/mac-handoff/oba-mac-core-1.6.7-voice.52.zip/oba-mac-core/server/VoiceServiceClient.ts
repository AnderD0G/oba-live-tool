import type { HostVoicePath } from './HostBridgeProtocol'

const PATHS = new Set(['/api/state', '/api/rec/start', '/api/rec/stop', '/api/rec/cancel'])
export interface VoiceServiceOptions { baseUrl: string; token?: string }
/** Fixed private-origin adapter. No renderer-selected URL, eval, redirects or uploads. */
export class VoiceServiceClient {
  private base: URL
  constructor(private options: VoiceServiceOptions) {
    this.base = new URL(options.baseUrl)
    if (!['http:', 'https:'].includes(this.base.protocol) || this.base.username || this.base.password || this.base.search || this.base.hash || this.base.pathname !== '/') throw Error('语音服务须配置固定HTTP源地址')
  }
  async request(path: HostVoicePath, timeoutMs: number): Promise<unknown> {
    if (!PATHS.has(path)) throw Error('VOICE_PATH_FORBIDDEN')
    const response = await fetch(new URL(path, this.base), { method: path === '/api/state' ? 'GET' : 'POST', redirect: 'error',
      headers: this.options.token ? { Authorization: `Bearer ${this.options.token}` } : {}, signal: AbortSignal.timeout(timeoutMs) })
    if (!response.ok || !response.body) throw Error('VOICE_SERVICE_UNAVAILABLE')
    const reader = response.body.getReader(), chunks: Uint8Array[] = []
    let size = 0
    try {
      for (;;) { const part = await reader.read(); if (part.done) break; size += part.value.byteLength; if (size > 128 * 1024) throw Error('VOICE_RESPONSE_TOO_LARGE'); chunks.push(part.value) }
      return JSON.parse(Buffer.concat(chunks).toString('utf8'))
    } finally { await reader.cancel().catch(() => {}) }
  }
  async available() {
    try { const state = await this.request('/api/state', 2000) as any; return typeof state?.recording === 'boolean' && (state.busy === null || typeof state.busy === 'string') }
    catch { return false }
  }
}
