import { mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { AssistantDeskService } from '../electron/main/services/assistantDesk/AssistantDeskService'
import { AssistantVoiceCoordinator } from '../electron/main/services/AssistantVoiceCoordinator'
import { MobileAssistantDeskServer } from '../electron/main/services/MobileAssistantDeskServer'
import { validateDeskHttp } from '../shared/assistantDeskContract.mjs'
import { validatePlatformSessionCommand } from '../shared/platformSession'
import type { AssistantDeskCommand, AssistantDeskResult } from '../shared/assistantDesk'
import type { AssistantVoiceCommand } from '../shared/assistantVoice'
import { AdminServer } from './AdminServer'
import { HostBridgeClient, HostBridgeError, type BridgeOptions } from './HostBridgeClient'
import { HOST_BRIDGE_ROUTES as routes } from './HostBridgeProtocol'
import { VoiceServiceClient, type VoiceServiceOptions } from './VoiceServiceClient'

export interface CoreRuntimeOptions {
  dataDirectory: string; adminToken: string; accountId: string; accountName?: string; bridge?: BridgeOptions
  voiceService?: VoiceServiceOptions
  adminHost: string; adminPort: number; mobileHost: string; mobilePort: number; advertisedAddress: string
  mobileAssetDirectory: string; adminAssetDirectory: string
}
export async function createCoreRuntime(options: CoreRuntimeOptions) {
  if (!/^[A-Za-z0-9_.:-]{1,100}$/.test(options.accountId)) throw new Error('账号ID无效')
  await mkdir(options.dataDirectory, { recursive: true })
  const bridge = new HostBridgeClient(options.bridge), accountId = options.accountId
  const privateVoice = options.voiceService ? new VoiceServiceClient(options.voiceService) : undefined
  await bridge.status(accountId)
  const captures = new Map<string, { startedAt: number }>()
  const service: AssistantDeskService = new AssistantDeskService(join(options.dataDirectory, 'assistant-desk'), {
    interpret: async (id, prompt, signal) => (await bridge.request(routes.interpret, { accountId: id, prompt }, 120000, signal)).text,
    translateDraft: async (id, input, signal) => (await bridge.request(routes.translateDraft, { accountId: id, input }, 120000, signal)).text,
    send: (id, text, signal) => bridge.send(id, text, signal),
    ...(bridge.configured ? { localTranslate: (input: { text: string; signal: AbortSignal }) => bridge.request(routes.localTranslate, { text: input.text }, 120000, input.signal), localTranslationState: () => bridge.translationHealth() } : {}),
    recording: (id, action) => bridge.request(routes.recording, { accountId: id, action }),
    captureMetadata: async (_id, _platform, captureId) => captures.get(captureId),
    startCapture: (id, sessionId, onMessage, onCreated) => bridge.startCapture(id, sessionId, {
      onMessage, onBusiness: observation => service.observeBusiness(observation),
      onCreated: async lease => { captures.set(lease.captureSessionId, { startedAt: lease.startedAt }); while (captures.size > 1000) captures.delete(captures.keys().next().value!); await onCreated?.({ captureSessionId: lease.captureSessionId, startedAt: lease.startedAt, ...(lease.target ? { target: lease.target } : {}) }) },
      onDisconnected: captureId => { void service.disconnect(id, 'HOST_BRIDGE_DISCONNECTED', captureId).catch(() => {}) },
    }),
  })
  const execute = async (input: AssistantDeskCommand): Promise<AssistantDeskResult> => {
    try {
      const command = validateDeskHttp('/assistant/command', input) as AssistantDeskCommand
      if (command.params.accountId !== accountId) throw new Error('FOREIGN_ACCOUNT')
      if (command.action === 'start' && command.params.platform && command.params.platform !== 'tiktok') throw new Error('UNSUPPORTED_PLATFORM')
      return await service.execute(command)
    } catch { return { ok: false, error: { code: 'CORE_INVALID_COMMAND', message: '操作参数或账号无效' } } }
  }
  const voice = new AssistantVoiceCoordinator({ state: (id, row) => service.voiceScene(id, row), request: (path, timeoutMs) => privateVoice ? privateVoice.request(path, timeoutMs) : bridge.request(routes.voice, { accountId, path }, timeoutMs) })
  const mobile = new MobileAssistantDeskServer({ accountId, accountName: options.accountName ?? accountId, assetDirectory: options.mobileAssetDirectory,
    host: options.mobileHost, port: options.mobilePort, addresses: () => [options.advertisedAddress], execute,
    voiceScene: (id, row) => service.voiceScene(id, row), voice: command => voice.execute(command),
  })
  const state = () => execute({ action: 'state', params: { accountId } })
  const admin = new AdminServer({ host: options.adminHost, port: options.adminPort, token: options.adminToken, assetDirectory: options.adminAssetDirectory,
    dispatch: async (method, path, body, signal) => {
      if (method === 'GET' && path === '/api/state') return state()
      if (method === 'GET' && path === '/api/status') {
        const [host, voiceAvailable] = await Promise.all([bridge.status(accountId), privateVoice?.available()])
        return { ok: true, data: { accountId, accountName: options.accountName ?? accountId, hostBridge: { configured: bridge.configured, connected: host.connected },
          capabilities: { ...host.capabilities, ...(privateVoice ? { voice: voiceAvailable } : {}), rawAnalysisArchive: false, obsEffects: false, camera: false }, supportedPlatforms: ['tiktok'], voiceSource: privateVoice ? 'private-service' : 'host-bridge', platform: host.platform, mobile: mobile.status(), storage: 'sqlite', desktop: 'core-management' } }
      }
      if (method === 'GET' && path === '/api/mobile') return { ok: true, data: mobile.status() }
      if (method === 'POST' && path === '/api/command') return execute(body)
      if (method === 'POST' && path === '/api/platform') {
        const command = validatePlatformSessionCommand(body)
        if (command.accountId !== accountId) throw new Error('FOREIGN_ACCOUNT')
        return { ok: true, data: await bridge.request(routes.platform, command, 120000) }
      }
      if (method === 'POST' && path === '/api/voice') {
        if (body?.accountId !== accountId) throw new Error('FOREIGN_ACCOUNT')
        const result = await voice.execute(body as AssistantVoiceCommand)
        if (body.action === 'start' && signal.aborted && result.ok) await voice.execute({ action: 'cancel', accountId, rowId: body.rowId })
        return result
      }
      return { ok: false, error: { code: 'CORE_NOT_FOUND', message: '当前独立服务尚未提供此接口' } }
    },
  })
  let stopping: Promise<void> | undefined
  const stop = () => stopping ??= (async () => {
    // Stop accepting HTTP work while cancellation releases existing handlers.
    // Waiting for HTTP drain first would hold shutdown behind a provider timeout.
    const results = await Promise.allSettled([admin.stop(), mobile.stop(), voice.dispose(), service.shutdown()])
    try { await bridge.close() } catch (reason) { results.push({ status: 'rejected', reason }) }
    const failed = results.find(result => result.status === 'rejected') as PromiseRejectedResult | undefined
    if (failed) throw failed.reason
  })()
  try {
    const ready = await state(); if (!ready.ok) throw new Error('数据库初始化失败')
    const mobileStatus = await mobile.start(), adminUrl = await admin.start()
    return { adminUrl, mobileUrls: mobileStatus.urls, stop }
  } catch (error) { await stop().catch(() => {}); throw error }
}
