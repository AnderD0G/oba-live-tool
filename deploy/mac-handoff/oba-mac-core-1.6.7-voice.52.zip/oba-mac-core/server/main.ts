import { randomBytes } from 'node:crypto'
import { lstat, mkdir, readFile, writeFile } from 'node:fs/promises'
import { isAbsolute, join, resolve } from 'node:path'
import { createCoreRuntime } from './CoreRuntime'

async function secret(name: string, fallbackFile?: string): Promise<string> {
  if (process.env[name]) return process.env[name]!
  const file = process.env[`${name}_FILE`] || fallbackFile
  if (!file) return ''
  try {
    const info = await lstat(file)
    if (!info.isFile() || info.isSymbolicLink() || info.size > 4096) throw new Error('Invalid secret file')
    return (await readFile(file, 'utf8')).trim()
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT' || !fallbackFile || process.env[`${name}_FILE`]) throw error
    const value = randomBytes(32).toString('hex')
    await writeFile(file, value + '\n', { flag: 'wx', mode: 0o600 })
    return value
  }
}
function port(name: string, fallback: number) {
  const value = Number(process.env[name] ?? fallback)
  if (!Number.isSafeInteger(value) || value < 0 || value > 65535) throw Error('Invalid port')
  return value
}
async function main() {
  const directory = process.env.OBA_DATA_DIR ?? '/data'
  if (!isAbsolute(directory)) throw Error('OBA_DATA_DIR must be absolute')
  await mkdir(directory, { recursive: true })
  const adminToken = await secret('OBA_ADMIN_TOKEN', join(directory, 'admin-token.txt'))
  const bridgeUrl = process.env.OBA_HOST_BRIDGE_URL
  const bridgeToken = bridgeUrl ? await secret('OBA_HOST_BRIDGE_TOKEN') : ''
  const voiceUrl = process.env.OBA_VOICE_SERVICE_URL
  const voiceToken = voiceUrl ? await secret('OBA_VOICE_SERVICE_TOKEN') : ''
  const runtime = await createCoreRuntime({
    dataDirectory: resolve(directory), adminToken, accountId: process.env.OBA_ACCOUNT_ID ?? 'default', accountName: process.env.OBA_ACCOUNT_NAME ?? 'OBA',
    ...(bridgeUrl ? { bridge: { baseUrl: bridgeUrl, token: bridgeToken } } : {}),
    ...(voiceUrl ? { voiceService: { baseUrl: voiceUrl, ...(voiceToken ? { token: voiceToken } : {}) } } : {}),
    adminHost: process.env.OBA_ADMIN_HOST ?? '0.0.0.0', adminPort: port('OBA_ADMIN_PORT', 17892),
    mobileHost: process.env.OBA_MOBILE_HOST ?? '0.0.0.0', mobilePort: port('OBA_MOBILE_PORT', 17893), advertisedAddress: process.env.OBA_MOBILE_ADDRESS ?? '127.0.0.1',
    adminAssetDirectory: join(__dirname, 'public'), mobileAssetDirectory: join(__dirname, 'assistant-mobile'),
  })
  // Access tokens and mobile capability URLs are intentionally absent from logs.
  console.log(JSON.stringify({ ready: true, role: 'oba-core', adminUrl: runtime.adminUrl, mobilePort: port('OBA_MOBILE_PORT', 17893), accountId: process.env.OBA_ACCOUNT_ID ?? 'default' }))
  let stopped = false
  const stop = () => {
    if (stopped) return
    stopped = true
    void runtime.stop().catch(() => { process.exitCode = 1; console.error('OBA core shutdown failed') })
  }
  process.once('SIGTERM', stop); process.once('SIGINT', stop)
  // Optional parent-process IPC also makes graceful shutdown testable on Windows.
  process.on('message', message => { if (message === 'shutdown') { stop(); process.disconnect?.() } })
}
void main().catch(() => { process.exitCode = 1; console.error('OBA core startup failed; check configuration and persistent volume permissions') })
