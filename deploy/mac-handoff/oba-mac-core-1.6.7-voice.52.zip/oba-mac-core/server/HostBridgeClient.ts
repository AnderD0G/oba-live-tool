import type { AssistantLocalTranslationHealth } from '../shared/assistantDesk'
import type { BusinessObservation } from '../shared/analysisRoom'
import { HOST_BRIDGE_ROUTES as routes, type HostCapabilities, type HostCaptureLease, type HostStatus, unavailableCapabilities } from './HostBridgeProtocol'

const MAX_JSON = 512 * 1024, MAX_LINE = 256 * 1024
const validId = (value: unknown): value is string => typeof value === 'string' && /^[A-Za-z0-9_.:-]{1,256}$/.test(value)
export class HostBridgeError extends Error {
  constructor(readonly code = 'HOST_BRIDGE_UNAVAILABLE') { super(code === 'HOST_CAPABILITY_UNAVAILABLE' ? '宿主桥尚未提供此功能' : '宿主桥不可用，请检查 Mac 本机桥接程序') }
}
export interface BridgeOptions { baseUrl: string; token: string }
interface ActiveLease { released: boolean; controller: AbortController; task?: Promise<void>; lease: HostCaptureLease; accountId: string; release(): Promise<void> }
async function boundedJson(response: Response) {
  if (!response.body) throw new HostBridgeError()
  const reader = response.body.getReader(), chunks: Uint8Array[] = []
  let bytes = 0
  try {
    for (;;) { const part = await reader.read(); if (part.done) break; bytes += part.value.byteLength; if (bytes > MAX_JSON) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL'); chunks.push(part.value) }
    return JSON.parse(Buffer.concat(chunks).toString('utf8'))
  } finally { await reader.cancel().catch(() => {}) }
}

export class HostBridgeClient {
  private base?: URL
  private capabilities = unavailableCapabilities()
  private leases = new Set<ActiveLease>()
  private closed = false
  constructor(private options: BridgeOptions | undefined) {
    if (!options) return
    this.base = new URL(options.baseUrl)
    if (!['http:', 'https:'].includes(this.base.protocol) || this.base.username || this.base.password || this.base.search || this.base.hash || this.base.pathname !== '/' || options.token.length < 24)
      throw new Error('宿主桥配置无效；须使用固定HTTP源地址和至少24字符令牌')
  }
  get configured() { return !!this.base }
  private headers() { return { Authorization: `Bearer ${this.options!.token}`, 'Content-Type': 'application/json' } }
  async request<T = any>(path: string, body?: unknown, timeoutMs = 15000, signal?: AbortSignal): Promise<T> {
    if (!this.base || this.closed) throw new HostBridgeError()
    try {
      const response = await fetch(new URL(path, this.base), { method: body === undefined ? 'GET' : 'POST', headers: this.headers(), redirect: 'error',
        ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(timeoutMs)]) : AbortSignal.timeout(timeoutMs) })
      if (!response.ok) throw new HostBridgeError()
      const json = await boundedJson(response)
      if (json?.ok !== true || !Object.hasOwn(json, 'data')) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
      return json.data as T
    } catch (error) { if (error instanceof HostBridgeError) throw error; throw new HostBridgeError() }
  }
  async status(accountId: string): Promise<{ connected: boolean; capabilities: HostCapabilities; platform?: unknown }> {
    if (!this.configured || this.closed) return { connected: false, capabilities: unavailableCapabilities() }
    try {
      const data = await this.request<HostStatus>(`${routes.status}?accountId=${encodeURIComponent(accountId)}`, undefined, 3000)
      if (data?.version !== 1 || !data.capabilities || Object.keys(unavailableCapabilities()).some(key => typeof (data.capabilities as any)[key] !== 'boolean')) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
      this.capabilities = Object.fromEntries(Object.keys(unavailableCapabilities()).map(key => [key, (data.capabilities as any)[key]])) as unknown as HostCapabilities
      return { connected: true, capabilities: { ...this.capabilities }, ...(data.platform === undefined ? {} : { platform: data.platform }) }
    } catch { this.capabilities = unavailableCapabilities(); return { connected: false, capabilities: { ...this.capabilities } } }
  }
  translationHealth(): AssistantLocalTranslationHealth { return { status: this.capabilities.localTranslation ? 'idle' : 'unavailable', queued: 0, activeLanguages: [] } }
  async send(accountId: string, text: string, signal: AbortSignal) {
    const owner = [...this.leases].find(lease => !lease.released && lease.accountId === accountId)
    if (!owner) throw new HostBridgeError('HOST_CAPTURE_NOT_ACTIVE')
    const result = await this.request(routes.send, { accountId, text, leaseId: owner.lease.leaseId, generation: owner.lease.generation }, 30000, signal)
    if (result?.sent !== true) throw new HostBridgeError('HOST_SEND_UNCONFIRMED')
  }
  async startCapture(accountId: string, assistantSessionId: string, callbacks: {
    onCreated(lease: HostCaptureLease): Promise<void>; onMessage(message: any): void; onBusiness(observation: BusinessObservation): void; onDisconnected(captureSessionId: string): void
  }) {
    const status = await this.status(accountId)
    if (!status.capabilities.capture) throw new HostBridgeError('HOST_CAPABILITY_UNAVAILABLE')
    const lease = await this.request<HostCaptureLease>(routes.captureStart, { accountId, assistantSessionId })
    if (!validId(lease?.leaseId) || !validId(lease.generation) || !validId(lease.captureSessionId) || !Number.isSafeInteger(lease.startedAt) || lease.startedAt < 0 || lease.platform && lease.platform !== 'tiktok') throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
    const controller = new AbortController()
    let releaseWork: Promise<void> | undefined
    const active: ActiveLease = { released: false, controller, lease, accountId, release: () => {
      releaseWork ??= (async () => {
        active.released = true; controller.abort()
        try { const result = await this.request(routes.captureStop, { accountId, leaseId: lease.leaseId, generation: lease.generation }, 5000); if (result?.stopped !== true) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL') }
        finally { await active.task?.catch(() => {}); this.leases.delete(active) }
      })()
      return releaseWork
    } }
    this.leases.add(active)
    try {
      await callbacks.onCreated(lease)
      const timer = setTimeout(() => controller.abort(), 5000)
      let response: Response
      try { response = await fetch(new URL(`${routes.captureEvents}?accountId=${encodeURIComponent(accountId)}&leaseId=${encodeURIComponent(lease.leaseId)}&generation=${encodeURIComponent(lease.generation)}`, this.base), { headers: this.headers(), redirect: 'error', signal: controller.signal }) }
      finally { clearTimeout(timer) }
      if (!response.ok || !response.body || !response.headers.get('content-type')?.includes('application/x-ndjson')) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
      active.task = this.readStream(response, active, callbacks)
      return { captureSessionId: lease.captureSessionId, captureStartedAt: lease.startedAt, ...(lease.target ? { target: lease.target } : {}), release: active.release }
    } catch (error) { await active.release().catch(() => {}); throw error }
  }
  private async readStream(response: Response, active: ActiveLease, callbacks: { onMessage(message: any): void; onBusiness(observation: BusinessObservation): void; onDisconnected(captureSessionId: string): void }) {
    const reader = response.body!.getReader(), decoder = new TextDecoder('utf-8', { fatal: true })
    let buffer = '', sequence = 0, lastEvent = Date.now()
    const watchdog = setInterval(() => { if (Date.now() - lastEvent > 45000) active.controller.abort() }, 10000)
    watchdog.unref()
    try {
      for (;;) {
        const part = await reader.read()
        if (part.done) { if (buffer.trim()) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL'); break }
        buffer += decoder.decode(part.value, { stream: true })
        for (;;) {
          const newline = buffer.indexOf('\n'); if (newline < 0) break
          if (Buffer.byteLength(buffer.slice(0, newline)) > MAX_LINE) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
          const line = buffer.slice(0, newline); buffer = buffer.slice(newline + 1)
          if (!line.trim()) continue
          const event = JSON.parse(line)
          if (event.version !== 1 || event.leaseId !== active.lease.leaseId || event.generation !== active.lease.generation) continue
          if (!Number.isSafeInteger(event.sequence) || event.sequence < 1) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
          if (event.sequence <= sequence) continue
          if (event.sequence !== sequence + 1) throw new HostBridgeError('HOST_BRIDGE_SEQUENCE_GAP')
          sequence = event.sequence; lastEvent = Date.now()
          if (active.released || this.closed) return
          if (event.kind === 'message') {
            const message = event.message
            if (!message || typeof message !== 'object' || Array.isArray(message) || typeof message.msg_type !== 'string' || message.msg_type.length > 100) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
            callbacks.onMessage({ ...message, metadata: { ...message.metadata, captureGeneration: active.lease.generation } })
          } else if (event.kind === 'business') {
            const observation = event.observation
            if (observation?.scope?.accountId !== active.accountId || observation.scope.platform !== 'tiktok' || observation.scope.source !== 'control' || !Number.isSafeInteger(observation.receivedAt)) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
            callbacks.onBusiness(observation)
          } else if (event.kind !== 'heartbeat') throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
        }
        if (Buffer.byteLength(buffer) > MAX_LINE) throw new HostBridgeError('HOST_BRIDGE_PROTOCOL')
      }
    } catch { /* The owning scene is explicitly interrupted below. */ }
    finally {
      clearInterval(watchdog); await reader.cancel().catch(() => {})
      if (!active.released && !this.closed) queueMicrotask(() => callbacks.onDisconnected(active.lease.captureSessionId))
    }
  }
  async close() {
    const results = await Promise.allSettled([...this.leases].map(lease => lease.release()))
    this.closed = true
    if (results.some(result => result.status === 'rejected')) throw new HostBridgeError()
  }
}
