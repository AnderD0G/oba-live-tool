import { timingSafeEqual } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { createServer, type IncomingMessage, type Server } from 'node:http'
import { join } from 'node:path'

export class AdminServer {
  private server?: Server
  private url = ''
  private stopping = false
  constructor(private options: { host: string; port: number; token: string; assetDirectory: string; dispatch(method: string, path: string, body: any, signal: AbortSignal): Promise<unknown> }) {
    if (options.token.length < 24) throw new Error('管理令牌至少24字符')
  }
  async start() {
    this.server = createServer((request, response) => {
      const controller = new AbortController()
      response.once('close', () => { if (!response.writableFinished) controller.abort() })
      const send = (status: number, body: unknown, type = 'application/json; charset=utf-8') => {
        if (response.destroyed) return
        response.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', ...(this.stopping ? { Connection: 'close' } : {}),
          'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'" })
        response.end(type.startsWith('application/json') ? JSON.stringify(body) : body)
      }
      void (async () => {
        const method = request.method ?? '', path = request.url ?? ''
        if (method === 'GET' && path === '/healthz') return send(200, { ok: true, role: 'oba-core', storage: 'sqlite', version: 1 })
        const assets: Record<string, [string, string]> = { '/': ['index.html', 'text/html; charset=utf-8'], '/app.js': ['app.js', 'application/javascript; charset=utf-8'], '/app.css': ['app.css', 'text/css; charset=utf-8'] }
        if (method === 'GET' && Object.hasOwn(assets, path)) { const [file, type] = assets[path]; return send(200, await readFile(join(this.options.assetDirectory, file)), type) }
        const given = Buffer.from(request.headers.authorization ?? ''), expected = Buffer.from(`Bearer ${this.options.token}`)
        if (given.length !== expected.length || !timingSafeEqual(given, expected)) return send(401, { ok: false, error: { code: 'CORE_UNAUTHORIZED', message: '请输入管理令牌' } })
        if (request.headers.origin !== undefined && request.headers.origin !== `http://${request.headers.host}`) return send(403, { ok: false, error: { code: 'CORE_ORIGIN_FORBIDDEN', message: '请求来源无效' } })
        if (!['GET', 'POST'].includes(method)) return send(405, { ok: false, error: { code: 'CORE_METHOD_NOT_ALLOWED', message: '请求方法无效' } })
        let body: unknown
        if (method === 'POST') {
          if (request.headers['content-type']?.split(';')[0].trim() !== 'application/json') return send(415, { ok: false, error: { code: 'CORE_CONTENT_TYPE', message: '请求格式须为JSON' } })
          body = await this.readBody(request)
        }
        const result = await this.options.dispatch(method, path, body, controller.signal) as any
        send(result?.ok === false ? 400 : 200, result)
      })().catch(error => send(400, { ok: false, error: { code: /^[A-Z_]+$/.test(error?.code) ? error.code : 'CORE_INVALID_REQUEST', message: '操作失败，请检查参数及宿主桥状态' } }))
    })
    this.server.requestTimeout = 30000
    await new Promise<void>((done, reject) => { this.server!.once('error', reject); this.server!.listen(this.options.port, this.options.host, done) })
    this.url = `http://127.0.0.1:${(this.server.address() as any).port}`
    return this.url
  }
  private async readBody(request: IncomingMessage) {
    let bytes = 0; const chunks: Buffer[] = []
    for await (const chunk of request) { bytes += chunk.length; if (bytes > 4 * 1024 * 1024) throw new Error('BODY_LIMIT'); chunks.push(chunk) }
    return JSON.parse(Buffer.concat(chunks).toString('utf8'))
  }
  async stop() { if (!this.server) return; this.stopping = true; const server = this.server; this.server = undefined; server.closeIdleConnections(); await new Promise<void>((done, reject) => server.close(error => error ? reject(error) : done())) }
}
