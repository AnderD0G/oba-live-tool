import type { AssistantLocalTranslationResult } from '../shared/assistantDesk'
import type { BusinessObservation } from '../shared/analysisRoom'

/** Private, bearer-authenticated host API. It never exposes cookies or provider keys. */
export const HOST_BRIDGE_VERSION = 1
export const HOST_BRIDGE_ROUTES = {
  status: '/v1/status', platform: '/v1/platform', captureStart: '/v1/capture/start', captureStop: '/v1/capture/stop', captureEvents: '/v1/capture/events',
  localTranslate: '/v1/local-translate', interpret: '/v1/interpret', translateDraft: '/v1/translate-draft', send: '/v1/send', voice: '/v1/voice', recording: '/v1/recording',
} as const
export interface HostCapabilities { capture: boolean; platform: boolean; localTranslation: boolean; voice: boolean; send: boolean; ai: boolean; recording: boolean }
export const unavailableCapabilities = (): HostCapabilities => ({ capture: false, platform: false, localTranslation: false, voice: false, send: false, ai: false, recording: false })
export type HostResponse<T> = { ok: true; data: T } | { ok: false; error: { code: string; message: string } }
export interface HostStatus { version: 1; capabilities: HostCapabilities; platform?: unknown }
export interface HostCaptureStart { accountId: string; assistantSessionId: string }
export interface HostCaptureLease { leaseId: string; generation: string; captureSessionId: string; startedAt: number; platform?: 'tiktok'; target?: { username: string; url: string } }
export interface HostCaptureStop { accountId: string; leaseId: string; generation: string }
interface EventOwner { version: 1; leaseId: string; generation: string; sequence: number }
export type HostCaptureEvent = EventOwner & (
  { kind: 'message'; message: Record<string, unknown> } |
  { kind: 'business'; observation: BusinessObservation } |
  { kind: 'heartbeat' }
)
export type HostVoicePath = '/api/state' | '/api/rec/start' | '/api/rec/stop' | '/api/rec/cancel'
/** Route bodies:
 * GET status?accountId=... -> HostStatus.
 * POST platform -> validated PlatformSessionCommand, returning its data.
 * POST capture/start -> HostCaptureStart, returning HostCaptureLease.
 * POST capture/stop -> HostCaptureStop, returning {stopped:true}.
 * GET capture/events?accountId=...&leaseId=...&generation=... -> application/x-ndjson HostCaptureEvent stream.
 * Send headers immediately. Emit a heartbeat at least every 15 seconds; finish on release/page loss.
 * POST local-translate -> {text:string}, returning AssistantLocalTranslationResult.
 * POST interpret -> {accountId,prompt}, returning {text:string} containing the model JSON contract.
 * POST translate-draft -> {accountId,input:{chinese,targetLanguage,originalComment?}}, returning {text:string}.
 * POST send -> {accountId,text,leaseId,generation}, returning {sent:true}; recheck owner/room just before submission. Abort HTTP work on disconnect/timeout; no implicit network retries.
 * POST voice -> {accountId,path:HostVoicePath}, returning the original Doubao JSON object as data.
 * POST recording -> {accountId,action:'status'|'start'|'stop'}, returning confirmed host recording data.
 * JSON routes use HostResponse<T>; NDJSON lines do not use the response envelope.
 */
export type HostLocalTranslation = AssistantLocalTranslationResult
