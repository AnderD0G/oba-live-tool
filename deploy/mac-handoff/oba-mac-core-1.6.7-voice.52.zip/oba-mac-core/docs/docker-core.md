# 独立 Docker 助播核心

容器运行真实 AssistantDeskService、原文/译文/任务/草稿/打点业务、SQLite、管理 API 与手机页面，不依赖 Windows 上另一个助手服务。TikTok 浏览器、本地 Chrome 翻译、真实麦克风由 **Mac 本机 Host Bridge** 提供。Chromium 容器化不属于这一版的启动前提。

## 启动

运行时为 Node 24。本次实际基础镜像为 Node 24.22.0，使用 Docker 官方 Node 镜像的 public ECR 镜像源，固定多架构 index digest `sha256:a5f4366e834695d5f363b920c104953a535d3a9864d1bdf74566a0ebe01daee5`，其中包含 linux/amd64 与 linux/arm64/v8。镜像构建不使用项目的 Electron/Vite 入口，最终镜像没有 Electron、Chrome 或开发依赖。需要更换镜像源时可用 `--build-arg NODE_IMAGE=...` 显式覆盖，并重新验收。

在 Mac 的项目目录创建不入库的 `.env`，填实际局域网地址和本机桥接配置：

```dotenv
OBA_ACCOUNT_ID=default
OBA_ACCOUNT_NAME=OBA
OBA_MOBILE_ADDRESS=192.168.1.5
OBA_HOST_BRIDGE_URL=http://host.docker.internal:7801/
OBA_HOST_BRIDGE_TOKEN=填写本机桥接程序的令牌
```

地址只是示例，须换成 Mac 当前的 LAN IP。本机桥必须允许 Docker Desktop 到它的连接并验证令牌；不能把 Mac 的 `127.0.0.1` 当成容器里的同一地址。未配置桥时可先删除最后两行，核心仍可独立运行、查看数据并保存配置，设备相关能力会显示不可用。

```sh
docker compose up -d --build
docker compose exec -T core cat /data/admin-token.txt
```

打开 `http://127.0.0.1:17892/`，输入上一步令牌。也可在运行时指定 `OBA_ADMIN_TOKEN` 或 `OBA_ADMIN_TOKEN_FILE`，以及 `OBA_HOST_BRIDGE_TOKEN_FILE`；密钥不属于镜像内容。

管理页可打开宿主登录浏览器、选择直播间、开始/停止采集、保存知识和翻译/回复配置、保存客户策略、查看实时消息/任务，以及复制手机入口。手机入口复用现有手机完整界面，含任务、语音草稿、筛选、钉住、倒计时、打点。当前网页不是 Electron 全桌面编辑器的等价版本；历史分析、OBS 布景编辑、摄像头设备管理尚未接入此独立网页。

## 协议与能力边界

- 管理 API 使用 Bearer 令牌；手机另有每次启动生成的能力 URL。完整配置不会进入手机投影。
- `GET /api/status`：真实宿主连接与 capabilities。`GET /api/state`：真实核心/SQLite 状态。
- `POST /api/command`：现有助播命令格式 `{action,params:{accountId,...}}`，只允许当前账号。
- `POST /api/platform`：现有平台会话命令。`POST /api/voice`：现有语音命令。
- `GET /api/mobile`：手机能力 URL。手机固定使用 17893 端口；Docker 内外应使用相同端口以保留 Host/Origin 校验。
- 宿主端接口完整定义在 `server/HostBridgeProtocol.ts`。核心向固定地址的桥发请求，桥不返回浏览器 cookies 或模型密钥。
- 原始消息和后续状态写入容器 SQLite。此最小版没有原始 protobuf 分析档案服务，`rawAnalysisArchive=false`；也不宣称 OBS 效果控制或摄像头已可用。
- 采集事件按 lease/generation 隔离并校验连续序号。流断开、序号缺口或长时间没有 heartbeat 会中断所属场次，不能继续显示采集中。
- 发送携带当前 lease/generation，不自动重试不确定的网络发送。宿主在实际提交前再次确认登录、直播间和 owner。
- 语音由核心保留场次/消息所有权；宿主只能执行专用语音开始、结束、取消接口。容器不原生读取 Mac 麦克风。

已有独立语音容器时，可选 `OBA_VOICE_SERVICE_URL` 配置固定私有源地址（以及可选 `OBA_VOICE_SERVICE_TOKEN`/`_FILE`）。核心仅允许 `/api/state`、`/api/rec/start`、`/api/rec/stop`、`/api/rec/cancel`，不会转发 `/api/eval`；禁止跟随重定向，响应限制128KiB。`capabilities.voice` 会实际检查该服务状态，未配置时仍使用宿主桥语音。若已有保留登录 profile 的 `oba-voice-poc`，可执行：

```sh
docker compose -f compose.yaml -f deploy/docker/compose.voice.yaml up -d
```

这只把核心加入现有 `oba-voice-poc_default` 网络，通过 `http://chromium:7799/` 连接，不重建语音服务、不发布其7799端口，也不修改 Windows 7799。真实 Mac 麦克风能否进入语音容器仍需单独授权和实机验收；固定 WAV 的 ASR 验证不能替代真实设备验证。

## 数据、备份和迁移

Compose 的 `oba_core_data` 命名卷挂载到 `/data`，保存 SQLite、现有备份/审计导出及管理令牌。重建镜像、重启容器不会清空该卷。本版不做压缩、冷热分层或测试数据清理。不要对正在运行的 SQLite 只复制一个主文件；使用现有 `storage-backup` 命令生成一致备份，或在服务正常停止后备份整个数据目录。备份含私人数据和令牌，应单独保管，不放入镜像或 Git。

Mac 本机桥的 Chrome profile、翻译模型缓存、系统授权和录音保持在宿主自己的目录。不要把 Windows 的 `safeStorage` 加密登录状态直接当成 Mac 可用状态；Mac 应重新登录。已有 OBS UUID 与素材路径须在 Mac 重新核对。

Compose 只运行一个核心实例，共享业务卷不用于多个同时活动的核心写者。`docker compose down` 保留数据；不要使用 `down -v`，除非确实要删除该卷。

## 验收

```sh
node scripts/build-server.mjs
./node_modules/.bin/tsx --test tests/serverCoreRuntime.test.ts tests/serverBuild.test.ts
docker compose ps
curl http://127.0.0.1:17892/healthz
```

隔离 HTTP fixture 验收覆盖真实 SQLite、手机任务、桥事件、翻译、语音所有权与发送幂等；它不调用真实麦克风、模型、OBS 或公屏。实际 Docker 镜像与 Mac 宿主桥还需分别实跑：检查选房/登录、真实翻译、语音开始/结束/取消，然后小流量采集。Mac arm64 实机未跑之前，不能以 Windows amd64 容器测试代称 Mac 完成验收。
