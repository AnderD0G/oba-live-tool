# 给 Mac Codex 的部署路书

本包是助播核心、SQLite、手机端、可选豆包 Chromium 和原生设备桥的部署代码。先在 Mac 的独立目录解压，保留现在能用的 OBS。Windows 的登录 profile、密钥和数据库没有放进包里。

1. 确认 Mac Docker Desktop 正常运行，使用 Linux/arm64 镜像。核心和语音镜像均固定了包含 arm64 的多架构索引，Windows 端实跑的是 amd64，不能把它写成 Mac 实机已验收。
2. 按 `docs/docker-host-bridge.md` 准备原生桥：本机 Node 24、Google Chrome。包中已带 `dist-host-bridge/index.mjs` 和锁文件，进入 `dist-host-bridge` 执行 `npm ci --omit=dev --ignore-scripts` 即可，不需要先装整个 Electron 开发环境。
3. 创建仅当前用户可读的随机宿主令牌文件，配置桥的 `OBA_HOST_TOKEN_FILE`、`OBA_HOST_BIND=0.0.0.0`、`OBA_HOST_PORT=7801` 和独立数据目录。使用本机防火墙限制接口访问。模型 key 在 Mac 配置 `OBA_AI_API_KEY_FILE`，不搬 Windows safeStorage 密文；默认 DeepSeek chat completions。不要在日志里打印 key、token 或 cookies。
4. 根目录新建不入库的 `.env`，设置 `OBA_MOBILE_ADDRESS=Mac实际局域网IP`、`OBA_HOST_BRIDGE_URL=http://host.docker.internal:7801/`，以及与宿主文件相同的 `OBA_HOST_BRIDGE_TOKEN`。按 `docs/docker-core.md` 启动 `docker compose up -d --build`。管理网页是 `http://127.0.0.1:17892/`；管理令牌保存在容器持久卷 `/data/admin-token.txt`。
5. 原生桥运行 `node dist-host-bridge/index.mjs`。在管理页打开 TikTok 登录浏览器、人工登录、选择直播间，再开始采集。手机入口需使用 Mac 实际 LAN 地址，不能把容器 IP 或 127.0.0.1 发给手机。
6. 如要使用已验证的容器豆包，先执行 `docker compose -f deploy/voice-container/compose.yaml up -d --build`，打开 `https://127.0.0.1:13443/` 人工登录豆包。然后用 `docker compose -f compose.yaml -f deploy/docker/compose.voice.yaml up -d --build` 将核心加入语音私有网络；7799 和 CDP 不公开映射。
7. 真正说话时，在 Mac 的本地浏览器打开 Selkies 入口并开启侧栏麦克风，允许浏览器和 macOS 使用麦克风；保持这个客户端连接。识别仍是“开始录音 → 结束并取文字”，取消必须调用 cancel。Windows 已实测合成中文经这个音频链进入豆包并识别、取消成功；Mac 物理麦克风仍须当地核对。
8. 本版先验收采集、手机筛选/钉住/倒计时/打点、中文草稿、一键清空、翻译和单次确认发送。普通进场被钉住不会自动生成招呼；回复语言是手选优先，再按真实发言、同场近期发言、昵称弱提示，最后英语。语言建议不能当成国家或原文语言事实。
9. 完成真实直播间测试后，先停止并排空，再执行 `node dist-host-bridge/index.mjs --close-room`，停止受管理的直播播放以节省 VPN 流量。接入的外部用户浏览器不会被自动关闭。

另有单独私下交付的 `OBA-Mac配置迁移-20261016.json`，保存 Windows 当时的知识、客户规则和回复规则，不含观众记录或凭据。需要沿用时，将它单独传到 Mac，停止采集，在仅当前用户可读的临时文件保存管理令牌后执行 `node scripts/import-docker-core-config.mjs 配置文件.json 管理令牌文件`。脚本逐项读取 Mac 当前 revision，调用已有保存命令；失败会报告已保存的项目，不自动回滚或重试。首次正式直播前核对其中的知识内容，避免沿用测试话术。不要把这个私人配置文件提交到 Git。API key、Chrome 登录和 OBS 场景仍按各自步骤配置。

核心持久卷保存 SQLite 与配置，重建镜像不会清空；不要使用 `down -v`。本版不做压缩、冷热分层或历史数据清理。OBS 布景编辑、摄像头管理、原始 protobuf 分析档案尚未接入容器管理网页，它不是完整 Electron 桌面的替代品；现有 OBS 场景和素材应按原迁移工作单独核对。

先把这些核心功能在 Mac 小流量实测一轮，再接正式直播。不要在未核对的陌生直播间重复发送测试消息。
