# Mac / Windows 原生宿主桥

Docker 内运行助播核心、SQLite 与手机页面；Mac 或 Windows 本机运行这个 Node 24 进程，持有 Chrome 登录、平台监听、模型凭据、豆包接口与 OBS 录像控制。桥只绑定一个账号，默认 `default`。它复用现有 TikTokPlatform 的原生监听和 `performConfirmedComment`，不需要启动 Electron。

## 构建与启动

在仓库已安装依赖的环境中执行：

```sh
node scripts/build-host-bridge.mjs
```

生成 `dist-host-bridge/index.mjs`、固定版本的运行 `package.json` 和 `package-lock.json`。将整个 `dist-host-bridge` 复制到 Mac，在该目录执行 `npm ci --omit=dev --ignore-scripts`，按锁文件安装。需要本机 Node.js 24+ 与正常安装的 Google Chrome；不需要下载 Playwright 自带 Chromium。仓库内直接运行生成的脚本也会复用现有 `node_modules`。Playwright、TikTok SDK、tiktok-live-proto 等包全部 external，保留各自的运行目录与 protobuf 资源，不被打成丢失资源路径的单文件。

先创建随机的至少 24 字符宿主令牌，保存在权限受限的本机文件，Docker 核心使用同一令牌。不要把令牌、API key、登录 profile 或 `.env` 写入镜像或 Git。

Mac 示例：

```sh
export OBA_HOST_TOKEN_FILE="$HOME/.config/oba/host-token"
export OBA_HOST_DATA_DIR="$HOME/Library/Application Support/OBA Host"
export OBA_HOST_ACCOUNT=default
export OBA_HOST_BIND=0.0.0.0
export OBA_HOST_PORT=7801
node dist-host-bridge/index.mjs
```

Windows PowerShell 示例：

```powershell
$env:OBA_HOST_TOKEN_FILE = "$env:USERPROFILE\.config\oba\host-token"
$env:OBA_HOST_DATA_DIR = "$env:LOCALAPPDATA\OBA-Host"
$env:OBA_HOST_ACCOUNT = 'default'
$env:OBA_HOST_BIND = '0.0.0.0'
$env:OBA_HOST_PORT = '7801'
node dist-host-bridge/index.mjs
```

默认只监听 `127.0.0.1`。Docker Desktop 访问宿主时使用 `http://host.docker.internal:7801`，并需要宿主监听 Docker 可达的接口；示例中的 `0.0.0.0` 应配合本机防火墙限制访问。所有接口都要求 Bearer 令牌，不提供浏览器跨域授权。不要将这个端口转发到公网。

Docker 核心设置：

```text
OBA_HOST_BRIDGE_URL=http://host.docker.internal:7801
OBA_HOST_BRIDGE_TOKEN=与宿主令牌文件相同的值
```

将这些值放进仓库根目录不入库的 `.env`，让现有 Compose 读取；账号标识也要一致。若使用 `OBA_HOST_BRIDGE_TOKEN_FILE`，须另行在 Compose 中显式传递该变量并只读挂载对应文件，单把它写进 `.env` 不会自动建立挂载。Linux Docker 需自行配置 `host.docker.internal:host-gateway`。这条桥不会把整个请求转发给旧 Windows 服务。

## 可选宿主功能

| 配置 | 含义 |
| --- | --- |
| `OBA_CHROME_EXECUTABLE` | 可选 Chrome 可执行文件绝对路径；未设置时使用 Playwright 的 `channel: chrome`。 |
| `OBA_CHROME_CDP_URL` | “接入现有浏览器”的固定 loopback CDP 地址；例如 `http://127.0.0.1:9222`。也可通过经验证的 attach-browser 命令指定。 |
| `OBA_AI_API_KEY_FILE` / `OBA_AI_API_KEY` | 模型 key 只在宿主保存；设置后提供真实 chat completions。 |
| `OBA_AI_BASE_URL` | 默认 `https://api.deepseek.com/v1`，兼容 OpenAI chat completions 的固定源。 |
| `OBA_AI_MODEL` | 默认 `deepseek-chat`；无额外昵称识别请求。 |
| `OBA_VOICE_URL` | 固定豆包控制 API 的源地址，例如 `http://127.0.0.1:7799`；不含路径。 |
| `OBA_OBS_URL` | OBS WebSocket 地址，例如 `ws://127.0.0.1:4455`。 |
| `OBA_OBS_PASSWORD_FILE` / `OBA_OBS_PASSWORD` | OBS 密码。录像只允许停止由本控制启动的录像，不控制推流。 |
| `OBA_LOCAL_TRANSLATION=0` | 关闭本机 Chrome 翻译；默认提供该能力，运行时仍须 Chrome 支持 LanguageDetector / Translator。 |
| `OBA_HOST_DEBUG=1` | 输出仅含组件名、scope、level 的诊断；平台参数和原始错误不写日志。 |

`*_FILE` 优先于对应环境变量。缺少模型、语音或 OBS 配置时，状态能力明确为不可用；不会偷偷使用其他服务或猜测配置。

Chrome 的 TikTok profile 位于宿主数据目录的 `tiktok-chrome`，本地翻译使用独立的 `translation-chrome`。这些目录包含登录状态或模型缓存，保留在宿主，Mac 上建议将父目录设为仅当前用户可访问。桥不加载原 Windows 的个人 Chrome profile。现有浏览器接入只接受 loopback CDP 与合法的 TikTok 直播页；释放时只断开 CDP，不关闭用户的 context 或页面。

Node 模式的 Electron `resolveProxy` 适配器明确返回 `DIRECT`，不会自动读取 macOS/Windows 系统代理。SDK 如需代理，请在启动宿主前显式设置 `HTTPS_PROXY` / `HTTP_PROXY` 为 HTTP(S) 代理地址。Chrome 自身仍由本机 Chrome/系统网络配置决定；两条路径都需要能访问 TikTok。不要把代理认证信息写进命令历史或日志。

## 生命周期与失败语义

- 通过登录浏览器完成真实登录，再设置目标直播间并开始采集。每次采集分配全新 lease、generation 与 captureSessionId。
- 监听在 start 过程中产生的消息先进入有界缓冲；事件流携带严格递增序号，每 10 秒至少一条 heartbeat。
- 缓冲最多 2048 条、合计 1 MiB，单行最多 256 KiB。超限或慢客户端无法跟上时关闭该采集；不截断或静默丢弃事件。
- 没有在 30 秒内接入事件流的 lease 自动清理。事件流断开、页面丢失或切换会释放采集，旧 generation 不可继续发送。
- 发送同时核对当前 lease、generation、登录状态与直播间 URL，最终仍走平台既有的草稿/单次提交校验。HTTP 断开或超时会传递 AbortSignal；发送与模型请求都不自动重试。
- 已进入公开提交的操作即便超时也可能到达直播间，必须先人工核实；服务不会把“请求结束”当作已发送。停止清理失败会保持拒绝新采集，需排查本机平台状态后重启桥。
- 语音只代理固定的 `/api/state`、`/api/rec/start`、`/api/rec/stop`、`/api/rec/cancel`；不暴露 eval 或任意 URL。取消录音使用 cancel，不能用按键松开代替。
- 宿主只拥有自己在空闲状态下发起的录音。宿主先于核心退出时，会中断本桥未完成的语音请求，等启动结果或服务忙状态结束，再用 cancel 确认麦克风关闭；取消不会发布识别文字。服务繁忙或取消无法确认时退出报告失败，不假报清理成功。其他程序已有的录音不会被本桥启动覆盖或取消。

每次真实测试结束，先停止采集并等待核心保存队列 drain，再执行：

```sh
node dist-host-bridge/index.mjs --close-room
```

命令通过同一 Bearer 令牌调用宿主 `/v1/room/close`。采集尚未释放时返回拒绝；成功时把宿主自己管理的 Chrome 页导航到 `about:blank`，关闭直播播放并节省 VPN 流量，保留 Chrome profile 与登录。接入的外部用户浏览器不会被导航或关闭，返回 `external: true`，需由用户自行处理。这里不清理或压缩任何 SQLite 数据。

## 无外部副作用检查

```sh
node dist-host-bridge/index.mjs --check
```

这个检查只加载原生依赖和报告能力，不打开 Chrome、不调用模型或麦克风、不访问 TikTok，不输出凭据。仓库验证命令：

```sh
node node_modules/tsx/dist/cli.mjs --test tests/hostBridgeServer.test.ts tests/hostBridgeLifecycle.test.ts tests/hostBridgeNative.test.ts
node node_modules/typescript/bin/tsc --noEmit -p host-bridge/tsconfig.json
```

Windows 与 Apple Silicon Mac 使用同一宿主脚本，但真实 Chrome 登录、语言包、麦克风权限及 OBS 凭据仍需在对应设备验证。离线 fixture 通过不能代替真实直播验收。
