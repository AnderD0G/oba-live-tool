"""Derive the public handoff receipt from actual local acceptance artifacts."""
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent.parent
def read(name):
    return json.loads((root / name).read_text(encoding='utf-8-sig'))

version = read('package.json')['version']
label = version.split('-')[-1].replace('.', '')
prefix = f'artifacts/mobile-assistant/{label}'
live = read(prefix + '-live-pressure.json')['summary']
pressure = read(prefix + '-stable-pressure.json')
functional = read(prefix + '-live-functional.json')
container = read('artifacts/docker-core/container-functional.json')
voice_probe = read('artifacts/docker-core/private-voice-probe.json')
voice = read('deploy/voice-container/verification.json')
smoke = read('artifacts/mobile-assistant/packaged-smoke.json')
hashes = read(prefix + '-installed-hashes.json')
assert live['reason'] == 'duration-complete'
assert live['stopped'] and live['drained'] and live['roomClosedAfterTest']
assert live['newDrops'] == 0 and live['uiErrors'] == 0 and live['cleanupErrors'] == []
assert live['actualDurationMs'] >= 720000 and live['maxStateMs'] <= 5000
assert live['phone']['failures'] == 0 and live['phone']['responses'] > 0
assert live['raw']['counters']['received'] == live['raw']['counters']['saved']
assert live['raw']['counters']['dropped'] == 0 and live['raw']['counters']['pending'] == 0
assert live['raw']['counters']['parseFailed'] == 0
assert live['raw']['originals']['received'] == live['raw']['originals']['saved']
assert live['raw']['originals']['dropped'] == live['raw']['originals']['pending'] == 0
assert pressure['passed'] and pressure['received'] == pressure['persisted'] == 2000
assert pressure['preCleanup']['dropped'] == 0 and pressure['cleanup']['drained']
assert pressure['controls']['successfulProbes'] == 4
assert functional['translated'] and functional['replyStatus'] == 'review'
assert container['passed'] and container['persistedRestart'] and container['dropped'] == 0
assert voice_probe['passed'] and smoke['ok'] and smoke['version'] == version
assert voice_probe['imageId'] == container['imageId']
report = {
    'version': version, 'createdAt': datetime.now(timezone.utc).isoformat(),
    'verifiedHost': 'Windows; Linux amd64 Docker containers', 'macHardwareTested': False,
    'installedRuntimeHashes': hashes,
    'live': {key: live[key] for key in ['reason', 'actualDurationMs', 'newDrops', 'maxPending', 'stateP95Ms', 'maxStateMs', 'onlineCount', 'stopped', 'drained', 'roomClosedAfterTest', 'phone', 'uiErrors']},
    'liveCaptureCounters': live['raw']['counters'],
    'actualDraftTranslation': {key: functional[key] for key in ['version', 'translated', 'languageSource', 'targetLanguage', 'replyStatus', 'translationMs', 'publicSendAttempts']},
    'privacyRedaction': live['raw'].get('complete') is False,
    'capacity': {'offeredPerSecond': 30, 'seconds': 60, 'burst': 200, 'canonicalReceived': pressure['received'], 'canonicalSaved': pressure['persisted'], 'dropped': 0,
        'fixtureControls': pressure['controls']['successfulProbes'], 'realPublicSendsInSyntheticTest': 0, 'externalDependencies': '100ms cancellable fixtures'},
    'dockerCore': {key: container[key] for key in ['passed', 'imageId', 'node', 'rows', 'dropped', 'persistedRestart', 'sendAttempts', 'checks']},
    'privateVoiceProbe': {'passed': True, 'physicalMicrophoneUsed': False},
    'voiceAsr': {key: voice[key] for key in ['transport', 'recognition', 'cancel', 'physicalMicrophoneUsed']},
    'sourcePackageContainsRuntimeUserData': False,
    'privateConfigurationDeliveredSeparately': True,
    'knownLimits': ['Mac physical microphone, arm64 hardware and OBS need local verification',
        'The core web UI excludes OBS scene editing, camera management and original protobuf analysis archives',
        'Older 40/80-per-second capacity failures and voice49/51 five-second live threshold failures remain recorded',
        'The old Windows test database retains 831 historical drops and two manual original-AI safeguards; no reset API exists',
        'SQLite compression, hot/cold tiers and historical cleanup were deferred'],
}
(root / 'deploy/docker/verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'written': 'deploy/docker/verification.json', 'version': version, 'livePassed': True, 'roomClosed': True}))
