import { build } from 'esbuild'
import { cp, mkdir, writeFile } from 'node:fs/promises'
import { isBuiltin } from 'node:module'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..'), out = join(root, 'dist-server')
await mkdir(out, { recursive: true })
const result = await build({ entryPoints: [join(root, 'server/main.ts')], outfile: join(out, 'main.cjs'), platform: 'node', target: 'node24', format: 'cjs',
  bundle: true, sourcemap: false, metafile: true, logLevel: 'silent' })
const externals = Object.values(result.metafile.outputs).flatMap(output => output.imports.filter(item => item.external).map(item => item.path))
if (externals.some(name => !isBuiltin(name)) || Object.keys(result.metafile.inputs).some(path => /node_modules[\\/]electron[\\/]/.test(path))) throw Error('Server bundle contains a non-Node/Electron runtime dependency')
await cp(join(root, 'server/public'), join(out, 'public'), { recursive: true })
await cp(join(root, 'public/assistant-mobile'), join(out, 'assistant-mobile'), { recursive: true })
await writeFile(join(out, 'build-info.json'), JSON.stringify({ role: 'oba-core', target: 'node24', electron: false, externals: [...new Set(externals)] }, null, 2))
console.log(JSON.stringify({ role: 'oba-core', output: 'dist-server/main.cjs', bytes: Object.values(result.metafile.outputs)[0].bytes, electron: false }))
