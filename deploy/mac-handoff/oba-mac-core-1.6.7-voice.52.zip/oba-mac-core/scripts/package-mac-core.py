"""Create a source/portable-bridge handoff, excluding all runtime user data."""
from pathlib import Path
import hashlib
import json
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parent.parent
VERSION = json.loads((ROOT / 'package.json').read_text(encoding='utf-8'))['version']
OUTPUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'artifacts' / 'mac-deployment' / f'oba-mac-core-{VERSION}.zip'
if OUTPUT.exists():
    raise SystemExit('Refusing to overwrite a previously delivered package')

roots = ['server', 'host-bridge', 'electron/main', 'shared', 'public/assistant-mobile', 'deploy/docker', 'deploy/voice-container', 'dist-host-bridge']
singles = ['Dockerfile', '.dockerignore', 'compose.yaml', 'package.json', 'pnpm-lock.yaml', 'tsconfig.json', 'tsconfig.node.json', 'electron/electron-env.d.ts', 'LICENSE', 'THIRD-PARTY-NOTICES.txt']
singles += [str(p.relative_to(ROOT)) for p in (ROOT / 'scripts').glob('*') if any(word in p.name for word in ['build-server', 'build-host-bridge', 'docker-core', 'voice-container', 'package-mac-core']) and p.is_file()]
singles += [str(p.relative_to(ROOT)) for p in (ROOT / 'docs').glob('docker*.md')]
singles += [str(p.relative_to(ROOT)) for p in (ROOT / 'tests').glob('*.test.ts') if p.name.startswith(('server', 'hostBridge', 'voiceContainer'))]
singles += ['tests/serverFixtureHost.mjs', 'scripts/stress-assistant-mobile-effects.ts', 'scripts/export-assistant-mac-config.mjs', 'tests/assistantPolicyAttentionRefresh.test.ts']
singles += [str(p.relative_to(ROOT)) for p in (ROOT / 'tests' / 'helpers').rglob('*.ts')]
paths = set()
for name in roots:
    folder = ROOT / name
    if folder.exists():
        paths.update(p for p in folder.rglob('*') if p.is_file())
paths.update(ROOT / name for name in singles if (ROOT / name).is_file())

def allowed(path):
    relative = path.relative_to(ROOT)
    if path.is_symlink() or any(part in {'node_modules', '.git', 'cookies', 'backups', 'logs', '__pycache__'} for part in relative.parts):
        return False
    lower = path.name.lower()
    if lower.startswith('.env') or lower.endswith(('.env', '.sqlite', '.sqlite3', '.sqlite-wal', '.sqlite-shm', '.db', '.db-wal', '.db-shm', '.jsonl', '.log', '.wav', '.exe', '.pyc', '.pem', '.key', '.pfx')):
        return False
    if lower in {'director-api.json', 'admin-token.txt', 'settings.json', 'cookies.json', 'host-token', 'api-key', 'secrets.json'} or 'credentials' in lower or 'token.txt' in lower:
        return False
    return True

entries = []
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUTPUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(filter(allowed, paths)):
        relative = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        archive.writestr('oba-mac-core/' + relative, data)
        entries.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    manifest = {'version': VERSION, 'createdAt': int(time.time()), 'includesRuntimeUserData': False, 'files': entries}
    archive.writestr('oba-mac-core/PACKAGE-MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(OUTPUT) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        assert name.startswith('oba-mac-core/') and '..' not in Path(name).parts
    for entry in entries:
        assert hashlib.sha256(archive.read('oba-mac-core/' + entry['path'])).hexdigest() == entry['sha256']
print(json.dumps({'file': str(OUTPUT), 'files': len(entries), 'bytes': OUTPUT.stat().st_size, 'sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(), 'verified': True}))
