param([string]$OutputPath = (Join-Path $env:TEMP ('oba-voice-known-zh-' + [Guid]::NewGuid().ToString('N') + '.wav')))

$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $OutputPath) { throw 'Refusing to overwrite an existing speech fixture' }
Add-Type -AssemblyName System.Speech
$synth = [System.Speech.Synthesis.SpeechSynthesizer]::new()
try {
    $synth.SelectVoice('Microsoft Huihui Desktop')
    $format = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(48000, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)
    $synth.SetOutputToWaveFile($OutputPath, $format)
    $synth.Speak('这是一个语音输入测试，今天直播准备好了。这是一个语音输入测试，今天直播准备好了。')
    $synth.SetOutputToNull()
    Write-Output $OutputPath
} finally {
    $synth.Dispose()
}
