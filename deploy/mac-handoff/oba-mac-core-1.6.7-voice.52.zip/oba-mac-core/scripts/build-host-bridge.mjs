import { build } from 'esbuild'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const out = resolve(root, 'dist-host-bridge')
await mkdir(out, { recursive: true })
const pkg = JSON.parse(await readFile(resolve(root, 'host-bridge/package.json'), 'utf8'))
const external = Object.keys(pkg.dependencies)
await build({ absWorkingDir: root, entryPoints: ['host-bridge/index.ts'], outfile: resolve(out, 'index.mjs'), bundle: true, platform: 'node', target: 'node24', format: 'esm', external,
  plugins: [{ name: 'native-host-only', setup(builder) {
    builder.onResolve({ filter: /^electron$/ }, () => ({ path: resolve(root, 'host-bridge/adapters/electron.ts') }))
    builder.onResolve({ filter: /logger$/ }, args => args.path === '#/logger' || resolve(args.resolveDir, args.path) === resolve(root, 'electron/main/logger') ? { path: resolve(root, 'host-bridge/adapters/logger.ts') } : undefined)
  } }],
})
await writeFile(resolve(out, 'package.json'), JSON.stringify(pkg, null, 2) + '\n')
await writeFile(resolve(out, 'package-lock.json'), await readFile(resolve(root, 'host-bridge/package-lock.json')))
console.log('Native host bridge built in dist-host-bridge (no Electron runtime).')
