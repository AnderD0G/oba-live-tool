// Private configuration handoff. Uses the existing optimistic-revision commands.
import { readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'

const applied = []
function fail(code) { throw Object.assign(Error(code), { code }) }
async function main() {
  const [configFile, tokenFile, address = 'http://127.0.0.1:17892/'] = process.argv.slice(2)
  if (!configFile || !tokenFile) fail('CONFIG_AND_ADMIN_TOKEN_FILES_REQUIRED')
  const base = new URL(address)
  if (base.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(base.hostname) || base.username || base.password || base.pathname !== '/' || base.search || base.hash) fail('LOCAL_ADMIN_ADDRESS_REQUIRED')
  const raw = await readFile(configFile)
  if (raw.length > 2 * 1024 * 1024) fail('CONFIG_FILE_TOO_LARGE')
  const config = JSON.parse(raw.toString('utf8'))
  if (config.format !== 'oba-assistant-config' || config.version !== 1 || typeof config.accountId !== 'string' || !config.context || !config.audiencePolicy || !config.replyPolicy) fail('INVALID_CONFIG_HANDOFF')
  const token = (await readFile(tokenFile, 'utf8')).trim()
  if (!/^[\x21-\x7e]{24,512}$/.test(token)) fail('INVALID_ADMIN_TOKEN_FILE')
  async function api(path, body) {
    const response = await fetch(new URL(path, base), { method: body === undefined ? 'GET' : 'POST', redirect: 'error', signal: AbortSignal.timeout(15000),
      headers: { Authorization: `Bearer ${token}`, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) })
    const result = await response.json()
    if (!response.ok || result.ok !== true) fail(/^[A-Z_]{1,80}$/.test(result.error?.code ?? '') ? result.error.code : 'CONFIG_IMPORT_REQUEST_FAILED')
    return result.data
  }
  const fingerprint = createHash('sha256').update(raw).digest('hex').slice(0, 24)
  for (const [action, field, parameter] of [['context-save', 'context', 'context'], ['policy-save', 'audiencePolicy', 'policy'], ['reply-policy-save', 'replyPolicy', 'policy']]) {
    const state = await api('api/state')
    if (state.activeSession) fail('STOP_CAPTURE_BEFORE_CONFIG_IMPORT')
    const revision = state[field]?.revision
    if (!Number.isSafeInteger(revision)) fail('TARGET_CONFIG_REVISION_UNAVAILABLE')
    const result = await api('api/command', { action, params: { accountId: config.accountId, expectedRevision: revision, [parameter]: config[field],
      ...(action === 'reply-policy-save' ? { requestId: `config-import-${fingerprint}-${revision}` } : {}) } })
    applied.push({ action, revision: result.revision })
  }
  console.log(JSON.stringify({ imported: true, applied, audienceRecordsImported: 0, credentialsImported: false }))
}
main().catch(error => {
  console.error(JSON.stringify({ imported: false, applied, code: /^[A-Z_]{1,80}$/.test(error?.code ?? '') ? error.code : 'CONFIG_IMPORT_FAILED', partial: applied.length > 0 }))
  process.exitCode = 1
})
