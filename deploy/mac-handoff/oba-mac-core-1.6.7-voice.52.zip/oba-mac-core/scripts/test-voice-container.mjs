import { execFile } from 'node:child_process'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { promisify } from 'node:util'
import { chromium } from 'playwright'
import { createToneWav } from '../deploy/voice-container/probe-tools.mjs'

const exec = promisify(execFile)
const compose = fileURLToPath(new URL('../deploy/voice-container/compose.yaml', import.meta.url))
const args = ['compose', '-f', compose]
const recognize = process.argv.includes('--recognize')
const cancel = process.argv.includes('--cancel')
const speech = recognize || cancel
const audio = process.argv.includes('--audio') || speech
const wavArgument = process.argv.indexOf('--wav')
if (speech && wavArgument < 0) throw new Error('--recognize / --cancel requires --wav <known-speech-fixture.wav>')
const desktopUrl = 'https://127.0.0.1:13443/'
const runProbe = async () => {
  const result = await exec('docker', [...args, 'exec', '-T', 'voice', 'node', speech ? 'recognize.mjs' : 'probe.mjs', ...(cancel ? ['--cancel'] : []), ...(audio && !speech ? ['--audio'] : [])], { timeout: speech ? 65000 : 25000, maxBuffer: 100000 })
  return JSON.parse(result.stdout.trim())
}

if (!audio) {
  console.log(JSON.stringify(await runProbe()))
} else {
  const fixture = await mkdtemp(join(tmpdir(), 'oba-voice-audio-fixture-'))
  let browser
  try {
    const wav = join(fixture, '440hz.wav')
    await writeFile(wav, speech ? await readFile(resolve(process.argv[wavArgument + 1])) : createToneWav())
    // All capture in this fresh browser is Chromium's fake file device. It cannot
    // select or open the host's physical microphone and does not reuse profiles.
    browser = await chromium.launch({ channel: 'chrome', headless: true, args: [
      '--use-fake-device-for-media-stream',
      `--use-file-for-fake-audio-capture=${wav}`,
      '--use-fake-ui-for-media-stream',
      '--autoplay-policy=no-user-gesture-required',
    ] })
    const context = await browser.newContext({ ignoreHTTPSErrors: true, permissions: ['microphone'], viewport: { width: 1280, height: 720 } })
    const page = await context.newPage()
    await page.goto(desktopUrl, { waitUntil: 'domcontentloaded', timeout: 30000 })
    const play = page.getByRole('button', { name: 'Play Stream', exact: true })
    if (await play.isVisible()) await play.click()
    await page.locator('.toggle-handle[title="Open Dashboard"]').click()
    const microphone = page.getByRole('button', { name: /microphone|麦克风/i }).first()
    const titledMicrophone = page.locator('[title*="microphone" i], [title*="麦克风"]').first()
    const control = await microphone.count() ? microphone : titledMicrophone
    await control.waitFor({ state: 'visible', timeout: 25000 })
    await control.click()
    await page.waitForTimeout(2000)
    console.log(JSON.stringify({ ...(await runProbe()), input: speech ? 'isolated-browser-fake-file-known-speech' : 'isolated-browser-fake-file-440Hz', physicalMicrophoneUsed: false }))
  } finally {
    await browser?.close()
    const resolved = resolve(fixture)
    if (dirname(resolved) !== resolve(tmpdir()) || !basename(resolved).startsWith('oba-voice-audio-fixture-')) throw new Error('Unexpected fixture path')
    await rm(resolved, { recursive: true, force: true })
  }
}
