// Isolated pressure replay: real Service/SQLite/MobileHTTP/effect admission; no external services.
// Run only when builds/other diagnostics are idle. --help never creates a fixture.
import assert from 'node:assert/strict'
import { mkdir, mkdtemp, rm, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { monitorEventLoopDelay, performance } from 'node:perf_hooks'
import { setImmediate as turn, setTimeout as sleep } from 'node:timers/promises'
import { AssistantDeskService } from '../electron/main/services/assistantDesk/AssistantDeskService'
import { MobileAssistantDeskServer } from '../electron/main/services/MobileAssistantDeskServer'
import { EffectGroupService, type EffectGroupObservedEvent } from '../electron/main/services/effectGroups/EffectGroupService'
import { EffectGroupStore } from '../electron/main/services/effectGroups/EffectGroupStore'
import { defaultAudiencePolicy } from '../shared/assistantAudiencePolicy'
import { applyEffectGroupsPatch, normalizeEffectGroupsConfig } from '../shared/effectGroups'

const args = new Set(process.argv.slice(2))
if (args.has('--help')) {
  console.log('tsx scripts/stress-assistant-mobile-effects.ts [--smoke] [--controls] [--history=N] [--rates=30,80] [--seconds=60] [--animation-ms=0] [--out=path]')
  console.log('Default: 30k historical run_events (~52 MiB JSON), 30/s 60s, 80/s 60s, drain, 200-event burst. Two 2s state readers. External translation/playback are stubs.')
  process.exit(0)
}
const option = (name: string) => process.argv.find(value => value.startsWith(`--${name}=`))?.split('=').slice(1).join('=')
const smoke = args.has('--smoke'), seconds = Number(option('seconds') ?? (smoke ? 1 : 60))
const controls = args.has('--controls'), controlIntervalMs = smoke ? 250 : 12000
const rates = (option('rates') ?? '30,80').split(',').map(Number)
const animationMs = Number(option('animation-ms') ?? 0)
assert.ok(Number.isFinite(seconds) && seconds > 0 && seconds <= 120)
assert.ok(rates.length > 0 && rates.length <= 4 && rates.every(rate => Number.isSafeInteger(rate) && rate > 0 && rate <= 200))
assert.ok(Number.isSafeInteger(animationMs) && animationMs >= 0 && animationMs <= 5000)
const historyCount = Number(option('history') ?? (smoke ? 300 : 30000))
const historyTargetJsonBytes = smoke ? 512 * 1024 : 52 * 1024 * 1024
assert.ok(Number.isSafeInteger(historyCount) && historyCount >= 0 && historyCount <= 60000)
const output = resolve(option('out') ?? `artifacts/mobile-assistant/isolated-effects-pressure${smoke ? '-smoke' : ''}.json`)
const folder = await mkdtemp(join(tmpdir(), 'oba-effects-pressure-'))
const effectFile = join(folder, 'effects.sqlite'), effectStore = new EffectGroupStore(effectFile)
const elapsed = monitorEventLoopDelay({ resolution: 10 })
const policy = defaultAudiencePolicy(), accountId = 'pressure'
const summary = (values: number[]) => {
  const s = [...values].sort((a, b) => a - b), q = (p: number) => +(s[Math.min(s.length - 1, Math.floor(s.length * p))] ?? 0).toFixed(3)
  return { count: s.length, p50Ms: q(.5), p95Ms: q(.95), p99Ms: q(.99), maxMs: q(1) }
}
let receive!: (message: any) => void, received = 0, persisted = 0, localCalls = 0, played = 0, sequence = 0
let maxPending = 0, maxLocalJobs = 0, maxEffectTasks = 0, maxPendingWrites = 0, rowAppends = 0, rawInitialWrites = 0
let hasRunChecks = 0, fullRunHistoryReads = 0, failure: string | undefined
const effectTasks = new Set<Promise<unknown>>(), pollTasks = new Set<Promise<unknown>>()
const effectErrors: string[] = [], pollErrors: string[] = [], pressureErrors: unknown[] = []
const sentAt = new Map<string, number>(), ackMs: number[] = [], dispatchMs: number[] = [], checkMs: number[] = []
const duplicateSamples: EffectGroupObservedEvent[] = [], phases: unknown[] = [], samples: unknown[] = []
const effectReceipts: Record<string, number> = {}
const effectAuditCounts: Record<string, number> = {}
const controlProbes: Array<Record<string, unknown>> = [], controlErrors: string[] = [], probedRows = new Set<string>()
let controlTranslateCalls = 0, controlSendCalls = 0, controlTask: Promise<void> | undefined
let effectRunEventSummary: unknown[] = []
const polls = { desktop: [] as number[], mobile: [] as number[] }
const baselineMemory = process.memoryUsage()
let capturedMemory = baselineMemory, loadStartMemory = baselineMemory, maxRss = baselineMemory.rss, maxHeap = baselineMemory.heapUsed
const hasRun = effectStore.hasRunEvent.bind(effectStore)
effectStore.hasRunEvent = (...input) => { const at = performance.now(); hasRunChecks++; try { return hasRun(...input) } finally { checkMs.push(performance.now() - at) } }
const listRuns = effectStore.listRunEvents.bind(effectStore)
effectStore.listRunEvents = (...input) => { fullRunHistoryReads++; return listRuns(...input) }
const appendRunEvent = effectStore.appendRunEvent.bind(effectStore)
effectStore.appendRunEvent = event => { const result = appendRunEvent(event); const key = `${event.status}:${event.reason ?? ''}`; effectAuditCounts[key] = (effectAuditCounts[key] ?? 0) + 1; return result }
const effects = new EffectGroupService({ store: effectStore, getAudiencePolicy: () => policy,
  player: {
    catalog: async () => [], sync: async () => { throw Error('No OBS resource mutation permitted') },
    recover: async () => {}, retire: async () => {}, stop: async () => {},
    play: async (_job, _resource, signal, started) => {
      played++; await started({ fixture: true })
      if (animationMs) await new Promise<void>(done => { const timer = setTimeout(done, animationMs); signal.addEventListener('abort', () => { clearTimeout(timer); done() }, { once: true }) })
    },
  }, onError: error => effectErrors.push((error as any)?.code ?? 'EFFECT_ERROR'),
})
const service = new AssistantDeskService(join(folder, 'assistant'), {
  interpret: async () => { throw Error('No model permitted') },
  send: async (_id, _text, signal) => {
    if (!controls) throw Error('No public send permitted')
    // This callback is never connected to a platform. --controls permits only
    // a delayed in-memory acknowledgement, with the real Service send guards.
    controlSendCalls++; await sleep(100, undefined, { signal })
  },
  ...(controls ? { translateDraft: async (_id: string, _input: unknown, signal: AbortSignal) => {
    controlTranslateCalls++; await sleep(100, undefined, { signal }); return 'Fixture item is available. Thank you.'
  } } : {}),
  startCapture: async (_account, _session, callback) => { receive = callback; return { captureSessionId: 'isolated-capture', release: async () => {} } },
  localTranslate: async () => { localCalls++; return { status: 'ready', method: 'chrome', chinese: '这是隔离压力测试的合成译文。', language: 'en', confidence: .99 } },
  localTranslationState: () => ({ status: 'idle', queued: 0, activeLanguages: [] }),
  onObservedPersisted: (_account, message, row) => {
    persisted++; ackMs.push(performance.now() - sentAt.get((message as any).msg_id)!)
    if (!['enter', 'like', 'follow'].includes(row.kind) || !row.userId) return
    const work = (async () => {
      const triage = await service.classifyAudienceEvent(accountId, message)
      const input: EffectGroupObservedEvent = { accountId, eventId: row.id, actionKind: row.kind as any, userId: row.userId!, displayName: row.nickname,
        receivedAt: row.receivedAt, sequence: ++sequence, triage, persisted: true, facts: { sourceEventId: row.sourceEventId, sessionId: row.sessionId, payLevel: row.payLevel } }
      if (duplicateSamples.length < 5) duplicateSamples.push(input)
      const at = performance.now()
      try {
        const result = await effects.dispatchObserved(input)
        const key = result.receipt?.reason ?? (result.receipt?.accepted ? 'ACCEPTED' : result.handled ? 'HANDLED' : 'UNHANDLED')
        effectReceipts[key] = (effectReceipts[key] ?? 0) + 1
      } finally { dispatchMs.push(performance.now() - at) }
    })()
    effectTasks.add(work); maxEffectTasks = Math.max(maxEffectTasks, effectTasks.size)
    void work.catch(error => effectErrors.push((error as any)?.code ?? 'DISPATCH_ERROR')).finally(() => effectTasks.delete(work))
    return work
  },
}, { trace: event => { if (['overflow', 'storage-error'].includes(event.stage) && pressureErrors.length < 20) pressureErrors.push(event) } })
const internal = service as any
const execute = async (action: string, params: Record<string, unknown> = {}) => {
  const result = await service.execute({ action, params: { accountId, ...params } } as any)
  assert.equal(result.ok, true, JSON.stringify(result)); return (result as any).data
}
const server = new MobileAssistantDeskServer({ accountId, accountName: 'Isolated pressure fixture', assetDirectory: resolve('public/assistant-mobile'),
  host: '127.0.0.1', addresses: () => ['127.0.0.1'], execute: command => service.execute(command),
})
let sampleTimer: ReturnType<typeof setInterval> | undefined
let controlTimer: ReturnType<typeof setInterval> | undefined
const pollTimers: ReturnType<typeof setInterval>[] = []
let initialEffectCount = 0, historyJsonBytes = 0, effectBytesAfterSeed = 0, initialHealth: any, finalState: any
let cleanup: Record<string, unknown> = {}, preCleanup: Record<string, unknown> = {}, durableRowsAfterCleanup: number | undefined
const startedAt = performance.now(), cpuAt = process.cpuUsage()

function observe() {
  maxPending = Math.max(maxPending, internal.ingestPending)
  maxPendingWrites = Math.max(maxPendingWrites, internal.journal.pending)
  maxLocalJobs = Math.max(maxLocalJobs, internal.localJobs.size)
}
function emitOne() {
  if (controls && controlErrors.length) throw Error('CONTROL_PROBE_FAILED: inspect controls.errors')
  const i = received++, eventId = `pressure-${i}`, kind = i % 10 === 0 ? 'tiktok_member' : i % 10 === 1 ? 'tiktok_like' : i % 10 === 2 ? 'tiktok_follow' : 'tiktok_comment'
  sentAt.set(eventId, performance.now())
  receive({ msg_type: kind, msg_id: eventId, user_id: `viewer-${i % 500}`, nick_name: `Fixture ${i % 500}`, content: kind === 'tiktok_comment' ? `Synthetic product question ${i}` : '',
    pay_level: i % 100 < 5 ? 20 : 0, fans_club_level: 0, follower_count: i % 100 < 5 ? 200 : undefined, like_count: 1,
    metadata: { provenance: 'sdk-decoded', captureGeneration: 'isolated-generation' } })
  observe()
  if (internal.journal.dropped) throw Error('CAPACITY_EXCEEDED: canonical/ingest drop observed; stopping offered load')
}
function launchControlProbe() {
  if (!controls || controlTask || failure) return controlTask
  const task = (async () => {
    const state = await execute('state')
    const row = state.rows.find((item: any) => item.kind === 'comment' && item.translation.status === 'ready' && item.reply.status === 'none' && !probedRows.has(item.id))
    if (!row) return
    probedRows.add(row.id)
    const trace: Record<string, unknown> = { rowId: row.id, receivedAtProbe: received, startedMs: performance.now() - startedAt }
    const measure = async <T>(name: string, work: () => Promise<T>) => { const at = performance.now(); try { return await work() } finally { trace[name] = performance.now() - at } }
    try {
      await measure('pinMs', () => execute('attention-pin', { rowId: row.id, pinned: true }))
      const requestId = `control-translation-${row.id}`, chinese = '隔离压力测试：这件商品有货，谢谢。'
      const beforeTranslation = controlTranslateCalls
      const translated = await measure('translateMs', () => execute('reply-translate', { rowId: row.id, chinese, requestId }))
      await measure('translationReplayMs', () => execute('reply-translate', { rowId: row.id, chinese, requestId }))
      assert.equal(controlTranslateCalls - beforeTranslation, 1, 'a repeated exact translation request must reuse its result')
      trace.translationReplay = true
      const params = { rowId: row.id, expectedText: translated.reply.text, requestId: `control-send-${row.id}` }
      const beforeSend = controlSendCalls
      await measure('sendMs', () => execute('reply-approve', params))
      await measure('sendReplayMs', () => execute('reply-approve', params))
      assert.equal(controlSendCalls - beforeSend, 1, 'a repeated exact send request must not invoke the sender twice')
      trace.sendReplay = true; trace.ok = true
    } catch (error) { trace.ok = false; trace.error = error instanceof Error ? error.message : String(error); throw error }
    finally { controlProbes.push(trace) }
  })()
  controlTask = task
  void task.catch(error => { controlErrors.push(error instanceof Error ? error.message : String(error)); failure ??= 'CONTROL_PROBE_FAILED' }).finally(() => { if (controlTask === task) controlTask = undefined })
  return task
}
async function drain(label: string, timeoutMs = 30000) {
  const at = performance.now()
  while (true) {
    observe()
    const effectStatus = effects.scheduler.status(accountId)
    if (!internal.ingestPending && !internal.journal.pending && !internal.rowTails.size && !internal.localTasks.size && !internal.localJobs.size && !effectTasks.size && !effectStatus.queued.length && !effectStatus.active.length) break
    if (performance.now() - at > timeoutMs) throw Error(`DRAIN_TIMEOUT:${label}`)
    await sleep(20)
  }
  await internal.journal.flush()
  return performance.now() - at
}

try {
  await internal.ready
  const context = await execute('context-get')
  await execute('context-save', { expectedRevision: context.revision, context: { ...context, translationEnabled: true, translationMode: 'local', replyMode: 'off', aiPaused: true, localEffectsEnabled: false } })
  const actions = ['enter', 'like', 'follow'] as const
  const config = applyEffectGroupsPatch(normalizeEffectGroupsConfig({}, accountId), { enabled: true, targetSceneName: 'Fixture Program', operations: actions.flatMap(actionKind => ['baseline-gold', '$fallback'].map(audienceRuleId => ({ op: 'upsert' as const, group: {
    audienceRuleId, actionKind, enabled: true, slot: 'main-stage' as const, concurrency: 'auto' as const, priority: 100, durationMs: 4000,
    animations: [{ assetId: 'google-flower' as const, placement: 'border' as const, shortAssetEnd: 'hold-last-frame' as const }], caption: { template: 'Fixture {{viewer.displayName}}', style: 'brief' as const }, coalesce: 'none' as const,
  } }))) })
  const saved = effectStore.save(accountId, 0, config, 'fixture-config')
  for (const group of saved.groups) effectStore.saveResource({ accountId, groupId: group.groupId, generation: 1, installId: effectStore.installId,
    sceneName: `fixture-${group.groupId}`, sceneUuid: `fixture-scene-uuid-${group.groupId}`, parentSceneName: saved.targetSceneName, parentSceneUuid: 'fixture-program-uuid', parentItemId: 1,
    captionInputName: `fixture-caption-${group.groupId}`, captionInputUuid: `fixture-caption-uuid-${group.groupId}`,
    animationInputs: [{ assetId: 'google-flower', inputName: `fixture-animation-${group.groupId}`, inputUuid: `fixture-animation-uuid-${group.groupId}`, kind: 'obs-media' }], state: 'ready', configHash: 'fixture', label: 'Fixture', ownedIdentities: [], snapshot: group })
  // Real durable store schema, one offline seed transaction, no production profile reads.
  const db = (effectStore as any).db, groupId = saved.groups[0].groupId
  const insertRun = db.prepare('INSERT INTO runs(run_id,account_id,group_id,event_id,snapshot_json) VALUES(?,?,?,?,?)')
  const insertEvent = db.prepare('INSERT INTO run_events(run_id,account_id,group_id,at,json) VALUES(?,?,?,?,?)')
  const padding = 'x'.repeat(historyCount ? Math.max(0, Math.round(historyTargetJsonBytes / historyCount) - 230) : 0)
  db.exec('BEGIN IMMEDIATE')
  try {
    for (let i = 0; i < historyCount; i++) {
      const runId = `historical-${Math.floor(i / 3)}`, eventId = `historical-event-${Math.floor(i / 3)}`
      const event = { runId, accountId, groupId, eventId, at: Date.now() - 86400000 + i, status: i % 3 === 2 || i === historyCount - 1 ? 'completed' : 'queued', detail: { fixture: true, padding } }
      const json = JSON.stringify(event); historyJsonBytes += Buffer.byteLength(json)
      if (i % 3 === 0) insertRun.run(runId, accountId, groupId, eventId, json)
      insertEvent.run(runId, accountId, groupId, event.at, json)
      if (i % 250 === 249) await turn()
    }
    db.exec('COMMIT')
  } catch (error) { db.exec('ROLLBACK'); throw error }
  initialEffectCount = Number(db.prepare('SELECT COUNT(*) AS n FROM run_events').get().n)
  effectBytesAfterSeed = (await stat(effectFile)).size + (await stat(`${effectFile}-wal`).catch(() => ({ size: 0 }))).size
  await effects.start()
  await execute('start')
  initialHealth = (await execute('state')).health
  loadStartMemory = process.memoryUsage()
  const append = internal.journal.append.bind(internal.journal), initialIds = new Set<string>()
  internal.journal.append = (record: any, guard?: () => boolean) => {
    if (record.type === 'row') { rowAppends++; if (!initialIds.has(record.data.id)) { initialIds.add(record.data.id); rawInitialWrites++ } }
    return append(record, guard)
  }
  const base = (await server.start()).urls[0]
  const poll = (client: 'desktop' | 'mobile', work: () => Promise<unknown>) => {
    let active = false
    const run = () => {
      if (active) return
      active = true; const at = performance.now()
      const task = work().catch(error => pollErrors.push((error as any)?.code ?? `${client.toUpperCase()}_POLL_FAILED`)).finally(() => { polls[client].push(performance.now() - at); active = false; pollTasks.delete(task) })
      pollTasks.add(task)
    }
    run(); pollTimers.push(setInterval(run, 2000))
  }
  poll('desktop', () => execute('state'))
  poll('mobile', async () => { const response = await fetch(base + 'api/state', { signal: AbortSignal.timeout(15000) }); const body = await response.json() as any; assert.equal(body.ok, true) })
  if (controls) controlTimer = setInterval(() => { void launchControlProbe()?.catch(() => {}) }, controlIntervalMs)
  elapsed.enable()
  sampleTimer = setInterval(() => {
    observe(); capturedMemory = process.memoryUsage(); maxRss = Math.max(maxRss, capturedMemory.rss); maxHeap = Math.max(maxHeap, capturedMemory.heapUsed)
    samples.push({ elapsedMs: Math.round(performance.now() - startedAt), received, persisted, ingestPending: internal.ingestPending, pendingWrites: internal.journal.pending, localJobs: internal.localJobs.size, effectTasks: effectTasks.size, dropped: internal.journal.dropped, rss: capturedMemory.rss, heapUsed: capturedMemory.heapUsed })
    if (samples.length % 30 === 0) console.log(JSON.stringify({ progressSeconds: samples.length, received, persisted, pending: internal.ingestPending, dropped: internal.journal.dropped }))
  }, 1000)
  for (const rate of rates) {
    const at = performance.now(), before = received, beforeCpu = process.cpuUsage()
    let maxScheduledLagMs = 0, completed = false
    try {
      for (let i = 0; i < rate * seconds; i++) {
        const due = at + i * 1000 / rate, delay = due - performance.now()
        if (delay > 0) await sleep(delay)
        maxScheduledLagMs = Math.max(maxScheduledLagMs, performance.now() - due)
        emitOne()
      }
      completed = true
    } finally {
      const durationMs = performance.now() - at, cpu = process.cpuUsage(beforeCpu)
      phases.push({ rate, targetSeconds: seconds, completed, emitted: received - before, durationMs, achievedRate: (received - before) * 1000 / durationMs, maxScheduledLagMs, cpuMs: (cpu.user + cpu.system) / 1000, pendingAtEnd: internal.ingestPending, persistedAtEnd: persisted })
      console.log(JSON.stringify({ phase: `${rate}/s`, completed, received, persisted, pending: internal.ingestPending, dropped: internal.journal.dropped, durationMs: Math.round(durationMs) }))
    }
  }
  clearInterval(controlTimer)
  await controlTask
  if (controls && !controlProbes.length) await launchControlProbe()
  if (controls) {
    assert.equal(controlErrors.length, 0, 'fixture controls must not fail silently')
    assert.ok(controlProbes.some(probe => probe.ok), 'at least one manual control probe must complete')
  }
  const beforeBurstDrainMs = await drain('before-burst')
  const at = performance.now(), before = received
  for (let i = 0; i < 200; i++) emitOne()
  phases.push({ name: 'burst', emitted: received - before, durationMs: performance.now() - at, precondition: 'all prior queues drained', beforeBurstDrainMs, pendingAtEnd: internal.ingestPending })
  const finalDrainMs = await drain('final')
  finalState = await execute('state')
  effectRunEventSummary = db.prepare("SELECT json_extract(json,'$.status') AS status,json_extract(json,'$.reason') AS reason,COUNT(*) AS n FROM run_events WHERE sequence>? GROUP BY status,reason").all(initialEffectCount)
  assert.equal(finalState.health.dropped - initialHealth.dropped, 0, 'the requested offered load must not lose canonical facts')
  assert.equal(persisted, received, 'all received raw facts were durably persisted')
  assert.equal(rawInitialWrites, received)
  const durableRows = Number(internal.journal.database.core.connect().prepare('SELECT COUNT(*) AS n FROM latest_records WHERE record_type=? AND account_id=?').get('row', accountId).n)
  assert.equal(durableRows, received, 'exact canonical latest rows match input')
  assert.equal(fullRunHistoryReads, 0, 'hot effect admission must not fetch complete run history')
  const beforeDuplicates = Number(db.prepare('SELECT COUNT(*) AS n FROM run_events').get().n)
  for (const input of duplicateSamples) assert.equal((await effects.dispatchObserved(input)).receipt?.reason, 'DUPLICATE_EVENT')
  assert.equal(Number(db.prepare('SELECT COUNT(*) AS n FROM run_events').get().n), beforeDuplicates, 'duplicate identity checks do not append another run')
  assert.equal(effectErrors.length, 0); assert.equal(pollErrors.length, 0)
  phases.push({ name: 'drained', finalDrainMs, durableRows, rowAppends, rawInitialWrites, localCalls, played, duplicateReplays: duplicateSamples.length, newEffectRunEvents: beforeDuplicates - initialEffectCount })
} catch (error) {
  failure = error instanceof Error ? error.message : String(error)
  console.log(JSON.stringify({ failed: failure, received, persisted, pending: internal.ingestPending, dropped: internal.journal.dropped }))
} finally {
  clearInterval(sampleTimer); clearInterval(controlTimer); for (const timer of pollTimers) clearInterval(timer)
  await controlTask?.catch(() => {})
  await Promise.allSettled([...pollTasks])
  preCleanup = { received, persisted, ingestPending: internal.ingestPending, pendingWrites: internal.journal.pending, dropped: internal.journal.dropped }
  const cleanupAt = performance.now()
  try {
    await server.stop()
    await execute('stop')
    const cleanupDrainMs = await drain('cleanup')
    finalState = await execute('state')
    durableRowsAfterCleanup = Number(internal.journal.database.core.connect().prepare('SELECT COUNT(*) AS n FROM latest_records WHERE record_type=? AND account_id=?').get('row', accountId).n)
    effectRunEventSummary = (effectStore as any).db.prepare("SELECT json_extract(json,'$.status') AS status,json_extract(json,'$.reason') AS reason,COUNT(*) AS n FROM run_events WHERE sequence>? GROUP BY status,reason").all(initialEffectCount)
    await service.shutdown(); await effects.stop(); effectStore.close()
    assert.equal(dirname(resolve(folder)), resolve(tmpdir())); assert.ok(basename(folder).startsWith('oba-effects-pressure-'))
    await rm(folder, { recursive: true, force: true })
    cleanup = { stopped: true, drained: true, closed: true, tempRemoved: true, durationMs: performance.now() - cleanupAt, cleanupDrainMs }
  } catch (error) {
    cleanup = { error: error instanceof Error ? error.message : String(error), durationMs: performance.now() - cleanupAt }
    failure ??= 'CLEANUP_FAILED'
  }
  capturedMemory = process.memoryUsage()
  elapsed.disable()
  const cpu = process.cpuUsage(cpuAt)
  const result = { recordedAt: new Date().toISOString(), passed: !failure, failure, smoke, runtime: process.version, sqlite: process.versions.sqlite,
    scope: 'isolated real AssistantDeskService + FULL canonical SQLite + MobileHTTP + EffectGroupStore/Service/scheduler; synthetic local translation and instant fixture-only playback',
    planned: { historyCount, historyTargetJsonBytes, phases: rates.map(rate => ({ rate, seconds })), animationMs, burst: 200, desktopPollMs: 2000, mobilePollMs: 2000, ingestCap: 256, localCap: 128 },
    history: { rows: initialEffectCount, jsonBytes: historyJsonBytes, databaseAndWalBytes: effectBytesAfterSeed },
    received, persisted, rowAppends, rawInitialWrites, durableRowsAfterCleanup, localCalls, played, maxPending, maxPendingWrites, maxLocalJobs, maxEffectTasks, effectReceipts, effectAuditCounts, effectRunEventSummary, preCleanup, cleanup,
    controls: { enabled: controls, intervalMs: controls ? controlIntervalMs : undefined, stubDelayMs: controls ? 100 : undefined,
      translateDraftCalls: controlTranslateCalls, fixtureSendCalls: controlSendCalls, realPublicMessagesSent: 0, successfulProbes: controlProbes.filter(probe => probe.ok).length, probes: controlProbes, errors: controlErrors },
    finalHealth: finalState?.health ?? { dropped: internal.journal.dropped, pendingWrites: internal.journal.pending, ingestPending: internal.ingestPending },
    acknowledgment: summary(ackMs), effectDispatch: summary(dispatchMs), effectIdentityChecks: { calls: hasRunChecks, ...summary(checkMs) }, fullRunHistoryReads,
    desktopState: summary(polls.desktop), mobileHttpState: summary(polls.mobile),
    eventLoopDelay: { meanMs: elapsed.mean / 1e6, p95Ms: elapsed.percentile(95) / 1e6, p99Ms: elapsed.percentile(99) / 1e6, maxMs: elapsed.max / 1e6 },
    processCpuMs: (cpu.user + cpu.system) / 1000, wallMs: performance.now() - startedAt,
    memory: { initial: baselineMemory, loadStart: loadStartMemory, last: capturedMemory, maxRss, maxHeap }, phases, samples, effectErrors, pollErrors, pressureErrors,
    limitations: ['No real TikTok decode, local Chrome translation, OBS rendering, microphone, network model, or mobile DOM rendering; external latency/CPU is not reproduced.',
      'Offered input keeps its fixed event schedule and catches up after delays; achieved rate and schedule lag are reported. Input stops on the first canonical drop.',
      'Historical JSON seed uses the real store schema in one durable transaction; normal live append paths retain their original FULL transactions.',
      'Memory samples use normal runtime collection; no forced GC or memory-leak conclusion from two minutes.'] }
  await mkdir(dirname(output), { recursive: true }); await writeFile(output, JSON.stringify(result, null, 2))
  console.log(JSON.stringify({ artifact: output, passed: !failure, received, persisted, maxPending, desktop: result.desktopState, mobile: result.mobileHttpState, eventLoop: result.eventLoopDelay }))
}
if (failure) process.exitCode = 1
