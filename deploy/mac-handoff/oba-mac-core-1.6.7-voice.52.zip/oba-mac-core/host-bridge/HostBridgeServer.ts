import { createHash, randomUUID, timingSafeEqual } from 'node:crypto'
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http'
import { validatePlatformSessionCommand, type PlatformSessionCommand } from '../shared/platformSession'
import type { HostCaptureLease, HostStatus, HostVoicePath } from '../server/HostBridgeProtocol'

export interface HostBridgeDriver {
  status(): Promise<HostStatus>
  platform(command: PlatformSessionCommand, signal: AbortSignal): Promise<any>
  start(emit: (event: any) => void, signal: AbortSignal, scene: { assistantSessionId: string }): Promise<Partial<HostCaptureLease> | void>
  stop(): Promise<void>
  send(text: string, signal: AbortSignal): Promise<{ sent: boolean }>
  localTranslate?(text: string, signal: AbortSignal): Promise<unknown>
  interpret?(prompt: string, signal: AbortSignal): Promise<string>
  translateDraft?(input: { chinese: string; targetLanguage: string; originalComment?: string }, signal: AbortSignal): Promise<string>
  voice?(path: HostVoicePath, signal: AbortSignal): Promise<unknown>
  recording?(action: 'status' | 'start' | 'stop', signal: AbortSignal): Promise<unknown>
  closeRoom?(signal: AbortSignal): Promise<unknown>
  close(): Promise<void>
}
interface Lease {
  value: HostCaptureLease
  released: boolean
  connected: boolean
  sequence: number
  queue: string[]
  pendingEvents: number
  pendingBytes: number
  blocked: boolean
  controller: AbortController
  response?: ServerResponse
  orphan?: ReturnType<typeof setTimeout>
  heartbeat?: ReturnType<typeof setInterval>
  startWork?: Promise<void>
  releaseWork?: Promise<void>
}
export interface HostBridgeServerOptions {
  token: string
  accountId: string
  driver: HostBridgeDriver
  host?: string
  port?: number
  requestTimeoutMs?: number
  orphanTimeoutMs?: number
  heartbeatMs?: number
}
export class HostBridgeFailure extends Error { constructor(readonly status: number, readonly code: string) { super(code) } }
function fail(status: number, code: string): never { throw new HostBridgeFailure(status, code) }
const identifier = (value: unknown): value is string => typeof value === 'string' && /^[A-Za-z0-9_.:-]{1,256}$/.test(value)
const string = (value: unknown, maximum: number): value is string => typeof value === 'string' && value.trim().length > 0 && value.length <= maximum && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)
const voicePaths = new Set(['/api/state', '/api/rec/start', '/api/rec/stop', '/api/rec/cancel'])
const MAX_EVENTS = 2048, MAX_BUFFER = 1024 * 1024, MAX_LINE = 256 * 1024, MAX_BODY = 256 * 1024

/** One authenticated native account. A lost stream invalidates its capture and every send. */
export class HostBridgeServer {
  private server?: Server
  private starting?: Promise<string>
  private closing?: Promise<void>
  private lease?: Lease
  private released = new Map<string, string>()
  private requests = new Set<AbortController>()
  private tokenHash: Buffer
  constructor(private readonly options: HostBridgeServerOptions) {
    if (!identifier(options.accountId) || typeof options.token !== 'string' || options.token.length < 24 || options.token.length > 4096) throw Error('Host bridge account/token configuration is invalid')
    for (const [value, maximum] of [[options.requestTimeoutMs, 150000], [options.orphanTimeoutMs, 30000], [options.heartbeatMs, 15000]] as const) {
      if (value !== undefined && (!Number.isSafeInteger(value) || value < 1 || value > maximum)) throw Error('Host bridge deadline configuration is invalid')
    }
    this.tokenHash = createHash('sha256').update(options.token).digest()
  }
  start(): Promise<string> {
    if (this.starting) return this.starting
    this.starting = (async () => {
      if (this.closing) throw Error('Host bridge is closing')
      const server = createServer((request, response) => { void this.handle(request, response) })
      server.requestTimeout = 150000; server.headersTimeout = 10000
      this.server = server
      await new Promise<void>((resolve, reject) => { server.once('error', reject); server.listen(this.options.port ?? 7801, this.options.host ?? '127.0.0.1', () => { server.off('error', reject); resolve() }) })
      const address = server.address()
      if (!address || typeof address === 'string') throw Error('Host bridge address is unavailable')
      const host = address.address === '::' ? '[::1]' : address.address === '0.0.0.0' ? '127.0.0.1' : address.address.includes(':') ? `[${address.address}]` : address.address
      return `http://${host}:${address.port}`
    })()
    return this.starting
  }
  close(): Promise<void> {
    return this.closing ??= (async () => {
      for (const request of this.requests) request.abort()
      const failures: unknown[] = []
      try { if (this.lease) await this.release(this.lease) } catch (error) { failures.push(error) }
      await this.starting?.catch(() => {})
      if (this.server) await new Promise<void>(resolve => { this.server!.close(() => resolve()); this.server!.closeAllConnections() })
      try { await this.options.driver.close() } catch (error) { failures.push(error) }
      if (failures.length) throw new AggregateError(failures, 'Host bridge cleanup failed')
    })()
  }
  private account(value: unknown) { if (value !== this.options.accountId) fail(403, 'HOST_ACCOUNT_MISMATCH') }
  private owner(body: any): Lease {
    const lease = this.lease
    if (!lease || lease.released || body.leaseId !== lease.value.leaseId || body.generation !== lease.value.generation) fail(409, 'HOST_CAPTURE_CHANGED')
    return lease
  }
  private current(lease: Lease, signal?: AbortSignal) {
    if (this.lease !== lease || lease.released || signal?.aborted) fail(409, 'HOST_CAPTURE_CHANGED')
  }
  private release(lease: Lease): Promise<void> {
    if (lease.releaseWork) return lease.releaseWork
    lease.released = true; lease.controller.abort()
    if (lease.orphan) clearTimeout(lease.orphan)
    if (lease.heartbeat) clearInterval(lease.heartbeat)
    lease.response?.end(); lease.queue = []; lease.pendingEvents = 0; lease.pendingBytes = 0
    lease.releaseWork = (async () => {
      // A synchronous startup emit can overflow before startWork has been assigned.
      await Promise.resolve()
      // Stop must interrupt a pending native startup. Waiting for startup first can deadlock cleanup.
      await this.options.driver.stop()
      await lease.startWork?.catch(() => {})
      // A failed cleanup stays poisoned: it cannot admit a new capture or manufacture a stop receipt.
      this.released.set(lease.value.leaseId, lease.value.generation)
      if (this.released.size > 64) this.released.delete(this.released.keys().next().value!)
      if (this.lease === lease) this.lease = undefined
    })()
    void lease.releaseWork.catch(() => {})
    return lease.releaseWork
  }
  private enqueue(lease: Lease, event: any) {
    if (this.lease !== lease || lease.released) return
    if (!event || typeof event !== 'object' || !['message', 'business', 'heartbeat'].includes(event.kind)) { void this.release(lease); return }
    let line: string
    try {
      const payload = event.kind === 'message' ? { kind: 'message', message: event.message } : event.kind === 'business' ? { kind: 'business', observation: event.observation } : { kind: 'heartbeat' }
      line = JSON.stringify({ ...payload, version: 1, leaseId: lease.value.leaseId, generation: lease.value.generation, sequence: ++lease.sequence }) + '\n'
    } catch { void this.release(lease); return }
    const bytes = Buffer.byteLength(line)
    if (bytes > MAX_LINE || lease.pendingEvents >= MAX_EVENTS || lease.pendingBytes + bytes > MAX_BUFFER) { void this.release(lease); return }
    lease.pendingEvents++; lease.pendingBytes += bytes; lease.queue.push(line)
    this.flush(lease)
  }
  private flush(lease: Lease) {
    const response = lease.response
    if (!response || lease.released || lease.blocked) return
    while (lease.queue.length && !lease.released) {
      const line = lease.queue.shift()!
      const written = response.write(line, () => {
        if (!lease.released) { lease.pendingEvents--; lease.pendingBytes -= Buffer.byteLength(line) }
      })
      if (!written) { lease.blocked = true; return }
    }
  }
  private async body(request: IncomingMessage) {
    if (request.headers['content-type']?.split(';')[0].trim().toLowerCase() !== 'application/json') fail(415, 'HOST_JSON_REQUIRED')
    let bytes = 0
    const chunks: Buffer[] = []
    for await (const chunk of request) {
      const data = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
      bytes += data.length
      if (bytes > MAX_BODY) fail(413, 'HOST_BODY_TOO_LARGE')
      chunks.push(data)
    }
    try {
      const body = JSON.parse(Buffer.concat(chunks).toString('utf8'))
      if (!body || typeof body !== 'object' || Array.isArray(body)) fail(400, 'HOST_INVALID_REQUEST')
      return body
    } catch { fail(400, 'HOST_INVALID_REQUEST') }
  }
  private async handle(request: IncomingMessage, response: ServerResponse) {
    const controller = new AbortController()
    this.requests.add(controller)
    let deadline: ReturnType<typeof setTimeout> | undefined
    const abort = () => { if (!response.writableFinished) controller.abort() }
    request.once('aborted', abort); response.once('close', abort)
    const send = (status: number, body: unknown) => {
      if (response.destroyed || response.writableEnded) return
      response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
      response.end(JSON.stringify(body))
    }
    try {
      const header = request.headers.authorization
      if (typeof header !== 'string' || !header.startsWith('Bearer ') || !timingSafeEqual(createHash('sha256').update(header.slice(7)).digest(), this.tokenHash)) fail(401, 'HOST_UNAUTHORIZED')
      if (request.headers.origin !== undefined) fail(403, 'HOST_ORIGIN_FORBIDDEN')
      if (this.closing || this.requests.size > 128) fail(503, 'HOST_BUSY')
      const url = new URL(request.url ?? '/', 'http://localhost')
      if (!['GET', 'POST'].includes(request.method ?? '')) fail(405, 'HOST_METHOD_NOT_ALLOWED')
      const isEvents = url.pathname === '/v1/capture/events'
      if (request.method === 'GET') {
        this.account(url.searchParams.get('accountId'))
        if (url.pathname === '/v1/status') {
          const status = await this.options.driver.status()
          return send(200, { ok: true, data: status })
        }
        if (!isEvents) fail(404, 'HOST_NOT_FOUND')
        const lease = this.owner({ leaseId: url.searchParams.get('leaseId'), generation: url.searchParams.get('generation') })
        if (lease.connected || !lease.startWork) fail(409, 'HOST_STREAM_ALREADY_CONNECTED')
        lease.connected = true
        response.once('close', () => { void this.release(lease) })
        response.once('error', () => { void this.release(lease) })
        await lease.startWork; this.current(lease, controller.signal)
        lease.response = response
        if (lease.orphan) clearTimeout(lease.orphan)
        response.on('drain', () => { lease.blocked = false; this.flush(lease) })
        response.writeHead(200, { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
        response.flushHeaders(); this.flush(lease)
        lease.heartbeat = setInterval(() => this.enqueue(lease, { kind: 'heartbeat' }), this.options.heartbeatMs ?? 10000)
        lease.heartbeat.unref()
        return
      }
      if (isEvents || url.pathname === '/v1/status') fail(405, 'HOST_METHOD_NOT_ALLOWED')
      deadline = setTimeout(() => { controller.abort(); send(504, { ok: false, error: { code: 'HOST_TIMEOUT', message: '宿主操作未确认，请核实状态后再操作' } }) }, this.options.requestTimeoutMs ?? (url.pathname === '/v1/local-translate' ? 125000 : 45000))
      const body = await this.body(request)
      if (controller.signal.aborted) fail(408, 'HOST_ABORTED')
      if (url.pathname !== '/v1/local-translate') this.account(body.accountId)
      let data: unknown
      if (url.pathname === '/v1/platform') {
        const command = validatePlatformSessionCommand(body)
        if (this.lease && !['state', 'qr-preview'].includes(command.action)) fail(409, 'HOST_CAPTURE_ACTIVE')
        data = await this.options.driver.platform(command, controller.signal)
      } else if (url.pathname === '/v1/capture/start') {
        if (!identifier(body.assistantSessionId)) fail(400, 'HOST_INVALID_REQUEST')
        if (this.lease) fail(409, 'HOST_CAPTURE_ACTIVE')
        const lease: Lease = { value: { leaseId: randomUUID(), generation: randomUUID(), captureSessionId: randomUUID(), startedAt: Date.now(), platform: 'tiktok' }, released: false, connected: false, sequence: 0, queue: [], pendingEvents: 0, pendingBytes: 0, blocked: false, controller: new AbortController() }
        this.lease = lease
        const abandoned = () => { if (controller.signal.aborted) void this.release(lease) }
        controller.signal.addEventListener('abort', abandoned, { once: true })
        lease.orphan = setTimeout(() => { void this.release(lease) }, this.options.orphanTimeoutMs ?? 30000); lease.orphan.unref()
        lease.startWork = (async () => {
          const result = await this.options.driver.start(event => this.enqueue(lease, event), lease.controller.signal, { assistantSessionId: body.assistantSessionId })
          if (result?.target) lease.value.target = { ...result.target }
        })()
        try { await lease.startWork; this.current(lease, controller.signal); data = lease.value }
        catch (error) { await this.release(lease); throw error }
        finally { controller.signal.removeEventListener('abort', abandoned) }
      } else if (url.pathname === '/v1/capture/stop') {
        if (this.released.get(body.leaseId) === body.generation && identifier(body.leaseId) && identifier(body.generation)) data = { stopped: true }
        else { await this.release(this.owner(body)); data = { stopped: true } }
      } else if (url.pathname === '/v1/send') {
        if (!string(body.text, 2000)) fail(400, 'HOST_INVALID_REQUEST')
        const lease = this.owner(body)
        const signal = AbortSignal.any([controller.signal, lease.controller.signal])
        const state = await this.options.driver.platform({ action: 'state', accountId: this.options.accountId }, signal)
        this.current(lease, signal)
        if (!state?.browserOpen || state.loginStatus !== 'authenticated' || state.roomReady !== true || lease.value.target && state.target?.url !== lease.value.target.url) fail(409, 'HOST_ROOM_NOT_READY')
        const result = await this.options.driver.send(body.text, signal)
        this.current(lease, signal)
        if (result?.sent !== true) fail(502, 'HOST_SEND_UNCONFIRMED')
        data = { sent: true }
      } else if (url.pathname === '/v1/voice') {
        if (!voicePaths.has(body.path)) fail(400, 'HOST_INVALID_VOICE_PATH')
        if (!this.options.driver.voice) fail(503, 'HOST_CAPABILITY_UNAVAILABLE')
        data = await this.options.driver.voice(body.path, controller.signal)
      } else if (url.pathname === '/v1/local-translate') {
        if (!string(body.text, 2000) || Object.keys(body).some(key => key !== 'text')) fail(400, 'HOST_INVALID_REQUEST')
        if (!this.options.driver.localTranslate) fail(503, 'HOST_CAPABILITY_UNAVAILABLE')
        data = await this.options.driver.localTranslate(body.text, controller.signal)
      } else if (url.pathname === '/v1/interpret') {
        if (!string(body.prompt, 100000)) fail(400, 'HOST_INVALID_REQUEST')
        if (!this.options.driver.interpret) fail(503, 'HOST_CAPABILITY_UNAVAILABLE')
        data = { text: await this.options.driver.interpret(body.prompt, controller.signal) }
      } else if (url.pathname === '/v1/translate-draft') {
        if (!body.input || !string(body.input.chinese, 1000) || !string(body.input.targetLanguage, 100) || body.input.originalComment !== undefined && (typeof body.input.originalComment !== 'string' || body.input.originalComment.length > 8000)) fail(400, 'HOST_INVALID_REQUEST')
        if (!this.options.driver.translateDraft) fail(503, 'HOST_CAPABILITY_UNAVAILABLE')
        data = { text: await this.options.driver.translateDraft(body.input, controller.signal) }
      } else if (url.pathname === '/v1/recording') {
        if (!['status', 'start', 'stop'].includes(body.action)) fail(400, 'HOST_INVALID_REQUEST')
        if (!this.options.driver.recording) fail(503, 'HOST_CAPABILITY_UNAVAILABLE')
        data = await this.options.driver.recording(body.action, controller.signal)
      } else if (url.pathname === '/v1/room/close') {
        if (Object.keys(body).some(key => key !== 'accountId')) fail(400, 'HOST_INVALID_REQUEST')
        if (this.lease) fail(409, 'HOST_CAPTURE_ACTIVE')
        if (!this.options.driver.closeRoom) fail(503, 'HOST_CAPABILITY_UNAVAILABLE')
        data = await this.options.driver.closeRoom(controller.signal)
      } else fail(404, 'HOST_NOT_FOUND')
      if (!controller.signal.aborted) send(200, { ok: true, data })
    } catch (error) {
      const status = error instanceof HostBridgeFailure ? error.status : 502
      const code = error instanceof HostBridgeFailure ? error.code : 'HOST_OPERATION_FAILED'
      send(status, { ok: false, error: { code, message: '宿主操作未完成，请检查本机状态后重试；发送结果不确定时须先核实直播间' } })
    } finally {
      if (deadline) clearTimeout(deadline)
      this.requests.delete(controller); request.off('aborted', abort); response.off('close', abort)
    }
  }
}
