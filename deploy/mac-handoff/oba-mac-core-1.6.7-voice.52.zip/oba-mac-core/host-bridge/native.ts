import { mkdir } from 'node:fs/promises'
import { join } from 'node:path'
import { chromium } from 'playwright'
import { TikTokPlatform } from '../electron/main/platforms/tiktok'
import { browserManager, type BrowserSession } from '../electron/main/managers/BrowserSessionManager'
import { ChromeLocalTranslationService } from '../electron/main/services/assistantDesk/ChromeLocalTranslationService'
import { ObsRecordingControl } from '../electron/main/services/ObsRecordingControl'
import { ObsWebSocketClient } from '../electron/main/services/ObsWebSocketClient'
import { NativeHostDriver } from './NativeHostDriver'
import { nativeModel, type NativeModelOptions } from './provider'

export interface NativeHostOptions {
  accountId: string
  dataDirectory: string
  chromeExecutable?: string
  attachEndpoint?: string
  model?: NativeModelOptions
  voiceUrl?: string
  obs?: { url: string; password: string }
  localTranslation?: boolean
}
export function createNativeHostDriver(options: NativeHostOptions) {
  const platform = new TikTokPlatform()
  const local = options.localTranslation === false ? undefined : new ChromeLocalTranslationService({ profileDirectory: join(options.dataDirectory, 'translation-chrome'), executablePath: options.chromeExecutable })
  const recording = options.obs ? new ObsRecordingControl(new ObsWebSocketClient(undefined, false), () => options.obs!) : undefined
  let voiceBase: URL | undefined
  if (options.voiceUrl) {
    voiceBase = new URL(options.voiceUrl)
    if (!['http:', 'https:'].includes(voiceBase.protocol) || voiceBase.username || voiceBase.password || voiceBase.search || voiceBase.hash || voiceBase.pathname !== '/') throw Error('HOST_VOICE_CONFIGURATION_INVALID')
  }
  return new NativeHostDriver({ accountId: options.accountId, platform,
    createBrowser: async () => {
      await mkdir(options.dataDirectory, { recursive: true, mode: 0o700 })
      const context = await chromium.launchPersistentContext(join(options.dataDirectory, 'tiktok-chrome'), {
        ...(options.chromeExecutable ? { executablePath: options.chromeExecutable } : { channel: 'chrome' }), headless: false, viewport: null, timeout: 30000,
      })
      const browser = context.browser()
      if (!browser) { await context.close(); throw Error('HOST_BROWSER_UNAVAILABLE') }
      return { browser, context, page: context.pages()[0] ?? await context.newPage(), ownership: 'owned' } satisfies BrowserSession
    },
    attachBrowser: (endpoint, pageUrl) => browserManager.attachSession(endpoint, pageUrl, { timeoutMs: 30000 }), attachEndpoint: options.attachEndpoint,
    ...(local ? { localTranslate: (text: string, signal: AbortSignal) => local.translate({ text, signal }), closeLocalTranslation: () => local.shutdown() } : {}),
    ...(options.model ? { model: nativeModel(options.model) } : {}),
    ...(voiceBase ? { voice: async (path, signal) => {
      const response = await fetch(new URL(path, voiceBase), { method: path === '/api/state' ? 'GET' : 'POST', redirect: 'error', signal: AbortSignal.any([signal, AbortSignal.timeout(path === '/api/rec/stop' ? 40000 : 15000)]) })
      if (!response.ok || !response.body) { await response.body?.cancel().catch(() => {}); throw Error('HOST_VOICE_REQUEST_FAILED') }
      const reader = response.body.getReader(), chunks: Uint8Array[] = []
      let bytes = 0
      try {
        for (;;) { const part = await reader.read(); if (part.done) break; bytes += part.value.byteLength; if (bytes > 256 * 1024) throw Error('HOST_VOICE_RESPONSE_INVALID'); chunks.push(part.value) }
        return JSON.parse(Buffer.concat(chunks).toString('utf8'))
      } finally { await reader.cancel().catch(() => {}) }
    } } : {}),
    ...(recording ? { recording: async (action, signal) => { if (signal.aborted) throw Error('HOST_ABORTED'); const result = await recording.execute(options.accountId, action); if (signal.aborted) throw Error('HOST_ABORTED'); return result } } : {}),
  })
}
