import { readFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { HostBridgeServer } from './HostBridgeServer'
import { createNativeHostDriver } from './native'

export { HostBridgeServer } from './HostBridgeServer'
export { createNativeHostDriver } from './native'
async function secret(name: string) {
  const path = process.env[`${name}_FILE`]
  return path ? (await readFile(path, 'utf8')).trim() : process.env[name]?.trim()
}
export async function main() {
  if (Number(process.versions.node.split('.')[0]) < 24) throw Error('Host bridge requires Node.js 24 or newer')
  const token = await secret('OBA_HOST_TOKEN')
  if (!token || token.length < 24) throw Error('OBA_HOST_TOKEN or OBA_HOST_TOKEN_FILE must supply at least 24 characters')
  if (process.argv.includes('--close-room')) {
    const response = await fetch(`http://127.0.0.1:${Number(process.env.OBA_HOST_PORT ?? 7801)}/v1/room/close`, {
      method: 'POST', redirect: 'error', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ accountId: process.env.OBA_HOST_ACCOUNT ?? 'default' }), signal: AbortSignal.timeout(10000),
    })
    const result = await response.json()
    if (!response.ok || result?.ok !== true) throw Error('HOST_ROOM_CLOSE_UNCONFIRMED')
    console.log(JSON.stringify(result.data)); return
  }
  const key = await secret('OBA_AI_API_KEY')
  const obsPassword = await secret('OBA_OBS_PASSWORD') ?? ''
  const driver = createNativeHostDriver({ accountId: process.env.OBA_HOST_ACCOUNT ?? 'default', dataDirectory: resolve(process.env.OBA_HOST_DATA_DIR ?? join(homedir(), '.oba-host')),
    chromeExecutable: process.env.OBA_CHROME_EXECUTABLE, attachEndpoint: process.env.OBA_CHROME_CDP_URL,
    ...(key ? { model: { apiKey: key, model: process.env.OBA_AI_MODEL ?? 'deepseek-chat', baseUrl: process.env.OBA_AI_BASE_URL ?? 'https://api.deepseek.com/v1' } } : {}),
    voiceUrl: process.env.OBA_VOICE_URL, ...(process.env.OBA_OBS_URL ? { obs: { url: process.env.OBA_OBS_URL, password: obsPassword } } : {}), localTranslation: process.env.OBA_LOCAL_TRANSLATION !== '0',
  })
  const server = new HostBridgeServer({ token, accountId: process.env.OBA_HOST_ACCOUNT ?? 'default', driver, host: process.env.OBA_HOST_BIND ?? '127.0.0.1', port: Number(process.env.OBA_HOST_PORT ?? 7801) })
  if (process.argv.includes('--check')) { console.log(JSON.stringify(await driver.status())); await driver.close(); return }
  const address = await server.start()
  console.log(JSON.stringify({ event: 'host-bridge-ready', address, accountId: process.env.OBA_HOST_ACCOUNT ?? 'default' }))
  let closing = false
  const stop = () => { if (closing) return; closing = true; void server.close().then(() => { process.exitCode = 0 }, () => { process.exitCode = 1 }) }
  process.on('SIGINT', stop); process.on('SIGTERM', stop)
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) void main().catch(() => { console.error('Native host bridge failed; check local configuration. No credentials were logged.'); process.exitCode = 1 })
