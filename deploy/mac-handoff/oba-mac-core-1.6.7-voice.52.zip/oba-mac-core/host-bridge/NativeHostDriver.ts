import { randomUUID } from 'node:crypto'
import { setTimeout as delay } from 'node:timers/promises'
import { interpretAssistantPrompt } from '../electron/main/services/assistantDesk/interpretAssistant'
import { translateReplyDraft, type ReplyDraftTranslationInput } from '../electron/main/services/assistantDesk/translateReplyDraft'
import type { BrowserSession } from '../electron/main/managers/BrowserSessionManager'
import type { TikTokPlatform } from '../electron/main/platforms/tiktok'
import { HostBridgeFailure, type HostBridgeDriver } from './HostBridgeServer'
import type { HostVoicePath } from '../server/HostBridgeProtocol'
import { validatePlatformSessionCommand, type PlatformSessionCommand, type PlatformSessionState } from '../shared/platformSession'

type Platform = Pick<TikTokPlatform, 'openLoginBrowser' | 'attachLoginBrowser' | 'getPlatformSessionState' | 'setLiveTarget' | 'getLoginQrPreview' | 'startCommentListener' | 'stopCommentListener' | 'subscribeBusiness' | 'subscribeListenerInvalidation' | 'performConfirmedComment' | 'disconnect'>
export interface NativeHostDependencies {
  accountId: string
  platform: Platform
  createBrowser(): Promise<BrowserSession>
  attachBrowser(endpoint: string, pageUrl: string): Promise<BrowserSession>
  attachEndpoint?: string
  localTranslate?: (text: string, signal: AbortSignal) => Promise<unknown>
  closeLocalTranslation?: () => Promise<void>
  model?: (messages: { role: 'system' | 'user'; content: string }[], signal: AbortSignal) => Promise<string>
  voice?: (path: HostVoicePath, signal: AbortSignal) => Promise<unknown>
  recording?: (action: 'status' | 'start' | 'stop', signal: AbortSignal) => Promise<unknown>
}
function aborted(signal: AbortSignal) { if (signal.aborted) throw Error('HOST_ABORTED') }
function object(value: unknown): Record<string, unknown> | undefined {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : undefined
}

/** Reuses the actual platform's login, native listeners and confirmed single-submit path. */
export class NativeHostDriver implements HostBridgeDriver {
  private session?: BrowserSession
  private sessionId?: string
  private busy = false
  private closing = false
  private closeWork?: Promise<void>
  private voiceOwned = false
  private voiceOperation?: { controller: AbortController; work: Promise<unknown> }
  private capture?: { target: { username: string; url: string }; controller: AbortController; disposers: (() => void)[] }
  constructor(private readonly deps: NativeHostDependencies) {}
  private usable(signal: AbortSignal) {
    aborted(signal)
    if (this.closing) throw new HostBridgeFailure(409, 'HOST_CLOSING')
  }
  async status() {
    return { version: 1 as const, capabilities: { capture: true, platform: true, send: true, ai: !!this.deps.model, localTranslation: !!this.deps.localTranslate, voice: !!this.deps.voice, recording: !!this.deps.recording }, platform: await this.state() }
  }
  private async state(): Promise<PlatformSessionState> {
    const base = { accountId: this.deps.accountId, platform: 'tiktok', supported: true, busy: this.busy }
    if (!this.session || this.session.page.isClosed()) return { ...base, browserOpen: false, loginStatus: 'closed', roomReady: false, captureReady: false }
    const snapshot = await this.deps.platform.getPlatformSessionState(this.session)
    return { ...base, ...snapshot, sessionId: this.sessionId, captureReady: snapshot.loginStatus === 'authenticated' && snapshot.roomReady && !this.busy }
  }
  private async releaseBrowser(session: BrowserSession) {
    if (session.ownership === 'external') await session.release?.()
    else await session.context.close()
  }
  async platform(input: PlatformSessionCommand, signal: AbortSignal) {
    const command = validatePlatformSessionCommand(input)
    if (command.accountId !== this.deps.accountId) throw Error('HOST_ACCOUNT_MISMATCH')
    this.usable(signal)
    if (command.action === 'state') return this.state()
    if (this.busy || this.capture && command.action !== 'qr-preview') throw Error('HOST_PLATFORM_BUSY')
    if (command.action === 'qr-preview') {
      if (!this.session || command.sessionId !== this.sessionId) throw Error('HOST_SESSION_CHANGED')
      return this.deps.platform.getLoginQrPreview(this.session)
    }
    this.busy = true
    try {
      if (command.action === 'open-login') {
        if (!this.session || this.session.page.isClosed() || this.session.ownership === 'external') {
          if (this.session) { const previous = this.session; this.session = undefined; this.sessionId = undefined; await this.releaseBrowser(previous) }
          this.usable(signal)
          const candidate = await this.deps.createBrowser()
          try { this.usable(signal) } catch (error) { await this.releaseBrowser(candidate); throw error }
          this.session = candidate; this.sessionId = randomUUID()
        }
        this.usable(signal)
        await this.deps.platform.openLoginBrowser(this.session)
      } else if (command.action === 'set-target') {
        if (!this.session || command.sessionId !== this.sessionId) throw Error('HOST_SESSION_CHANGED')
        await this.deps.platform.setLiveTarget(this.session, command.target)
      } else {
        const endpoint = command.action === 'attach-browser' ? command.endpoint : this.deps.attachEndpoint
        if (!endpoint) throw Error('HOST_ATTACH_ENDPOINT_REQUIRED')
        const attached = await this.deps.attachBrowser(endpoint, command.pageUrl)
        try { this.usable(signal); await this.deps.platform.attachLoginBrowser(attached, command.pageUrl); this.usable(signal) }
        catch (error) { await this.releaseBrowser(attached); throw error }
        const previous = this.session
        this.session = attached; this.sessionId = randomUUID()
        if (previous && previous !== attached) await this.releaseBrowser(previous)
      }
      this.usable(signal)
    } finally { this.busy = false }
    return this.state()
  }
  async start(emit: (event: any) => void, signal: AbortSignal) {
    this.usable(signal)
    if (this.capture || this.busy) throw Error('HOST_CAPTURE_ACTIVE')
    const state = await this.state()
    this.usable(signal)
    if (!state.captureReady || !state.target || !this.session) throw Error('HOST_ROOM_NOT_READY')
    const capture = { target: { ...state.target }, controller: new AbortController(), disposers: [] as (() => void)[] }
    this.capture = capture
    const stopOnAbort = () => { capture.controller.abort(); void this.deps.platform.stopCommentListener().catch(() => {}) }
    signal.addEventListener('abort', stopOnAbort, { once: true })
    capture.disposers.push(() => signal.removeEventListener('abort', stopOnAbort))
    capture.disposers.push(this.deps.platform.subscribeBusiness(observation => {
      if (this.capture === capture && !capture.controller.signal.aborted) emit({ kind: 'business', observation: { ...observation, scope: { accountId: this.deps.accountId, platform: 'tiktok', source: 'control' } } })
    }))
    capture.disposers.push(this.deps.platform.subscribeListenerInvalidation(() => {
      if (this.capture === capture) { capture.controller.abort(); emit({ kind: 'invalidated' }) }
    }))
    try {
      await this.deps.platform.startCommentListener(message => {
        if (this.capture === capture && !capture.controller.signal.aborted) emit({ kind: 'message', message })
      })
      aborted(signal); aborted(capture.controller.signal)
      if (this.capture !== capture) throw Error('HOST_CAPTURE_CHANGED')
      return { target: { ...capture.target } }
    } catch (error) { await this.stop(); throw error }
  }
  async stop() {
    const capture = this.capture
    this.capture = undefined
    if (capture) { capture.controller.abort(); for (const dispose of capture.disposers) dispose() }
    await this.deps.platform.stopCommentListener()
  }
  async send(text: string, signal: AbortSignal) {
    this.usable(signal)
    const capture = this.capture
    if (!capture || !this.session) throw Error('HOST_CAPTURE_NOT_ACTIVE')
    const owned = AbortSignal.any([signal, capture.controller.signal])
    aborted(owned)
    const state = await this.deps.platform.getPlatformSessionState(this.session)
    aborted(owned)
    if (this.capture !== capture || !state.browserOpen || state.loginStatus !== 'authenticated' || !state.roomReady || state.target?.url !== capture.target.url) throw Error('HOST_ROOM_CHANGED')
    const sent = await this.deps.platform.performConfirmedComment(text, owned)
    aborted(owned)
    if (!sent || this.capture !== capture) throw Error('HOST_SEND_UNCONFIRMED')
    return { sent: true }
  }
  async localTranslate(text: string, signal: AbortSignal) {
    if (!this.deps.localTranslate) throw new HostBridgeFailure(503, 'HOST_CAPABILITY_UNAVAILABLE')
    this.usable(signal); return this.deps.localTranslate(text, signal)
  }
  async interpret(prompt: string, signal: AbortSignal) {
    if (!this.deps.model) throw new HostBridgeFailure(503, 'HOST_CAPABILITY_UNAVAILABLE')
    this.usable(signal)
    const result = await interpretAssistantPrompt(prompt, messages => this.deps.model!(messages, signal))
    aborted(signal); return result
  }
  async translateDraft(input: ReplyDraftTranslationInput, signal: AbortSignal) {
    this.usable(signal)
    if (!this.deps.model) throw new HostBridgeFailure(503, 'HOST_CAPABILITY_UNAVAILABLE')
    return translateReplyDraft(input, messages => this.deps.model!(messages, signal), signal)
  }
  async voice(path: HostVoicePath, signal: AbortSignal) {
    if (!['/api/state', '/api/rec/start', '/api/rec/stop', '/api/rec/cancel'].includes(path)) throw new HostBridgeFailure(400, 'HOST_INVALID_VOICE_PATH')
    if (!this.deps.voice) throw new HostBridgeFailure(503, 'HOST_CAPABILITY_UNAVAILABLE')
    this.usable(signal)
    if (path === '/api/state') return this.deps.voice(path, signal)
    if (this.voiceOperation) throw new HostBridgeFailure(409, 'HOST_VOICE_BUSY')
    if (path !== '/api/rec/start' && !this.voiceOwned) throw new HostBridgeFailure(409, 'HOST_VOICE_NOT_OWNED')
    if (path === '/api/rec/start' && this.voiceOwned) throw new HostBridgeFailure(409, 'HOST_VOICE_ALREADY_RECORDING')
    const controller = new AbortController(), ownedSignal = AbortSignal.any([signal, controller.signal])
    const operation = { controller, work: Promise.resolve(undefined) as Promise<unknown> }
    this.voiceOperation = operation
    operation.work = Promise.resolve().then(async () => {
      if (path === '/api/rec/start') {
        const state = object(await this.deps.voice!('/api/state', ownedSignal))
        this.usable(ownedSignal)
        if (!state || typeof state.recording !== 'boolean' || !(state.busy === null || typeof state.busy === 'string')) throw new HostBridgeFailure(502, 'HOST_VOICE_STATE_UNCONFIRMED')
        if (state.recording || state.busy) throw new HostBridgeFailure(409, 'HOST_VOICE_SERVICE_BUSY')
        // Retain possible ownership after an uncertain network result. The bridge
        // must not abandon its microphone if it exits before the core can cancel.
        this.voiceOwned = true
      }
      this.usable(ownedSignal)
      const result = await this.deps.voice!(path, ownedSignal), reply = object(result)
      if (path === '/api/rec/start' && reply?.ok !== true && ['busy', 'no_button', 'not_recording'].includes(reply?.error as string)) this.voiceOwned = false
      if (path === '/api/rec/stop' && (reply?.ok === true || reply?.error === 'no_text')) this.voiceOwned = false
      if (path === '/api/rec/cancel' && reply?.ok === true && reply.recording === false) this.voiceOwned = false
      this.usable(ownedSignal)
      return result
    }).finally(() => { if (this.voiceOperation === operation) this.voiceOperation = undefined })
    return operation.work
  }
  private async closeVoice() {
    const operation = this.voiceOperation
    operation?.controller.abort()
    await operation?.work.catch(() => {})
    if (!this.voiceOwned || !this.deps.voice) return
    const signal = AbortSignal.timeout(15000)
    for (;;) {
      const state = object(await this.deps.voice('/api/state', signal))
      aborted(signal)
      if (!state || typeof state.recording !== 'boolean' || !(state.busy === null || typeof state.busy === 'string')) throw Error('HOST_VOICE_STATE_UNCONFIRMED')
      // HTTP cancellation cannot stop a server-side recStart. Its busy period
      // must end before recording=false can confirm that the mic is closed.
      if (state.busy) { await delay(100, undefined, { signal }); continue }
      if (state.recording) {
        const cancelled = object(await this.deps.voice('/api/rec/cancel', signal))
        aborted(signal)
        if (cancelled?.ok !== true || cancelled.recording !== false) throw Error('HOST_VOICE_CANCEL_UNCONFIRMED')
      }
      this.voiceOwned = false
      return
    }
  }
  async recording(action: 'status' | 'start' | 'stop', signal: AbortSignal) {
    if (!this.deps.recording) throw new HostBridgeFailure(503, 'HOST_CAPABILITY_UNAVAILABLE')
    this.usable(signal); return this.deps.recording(action, signal)
  }
  async closeRoom(signal: AbortSignal) {
    this.usable(signal)
    if (this.capture || this.busy) throw new HostBridgeFailure(409, 'HOST_CAPTURE_ACTIVE')
    if (!this.session || this.session.page.isClosed()) return { closed: false, alreadyClosed: true }
    if (this.session.ownership === 'external') return { closed: false, external: true }
    this.busy = true
    try {
      // Stop video/network playback but keep this owned persistent Chrome profile and login.
      await this.session.page.goto('about:blank', { waitUntil: 'domcontentloaded', timeout: 5000 })
      aborted(signal)
      return { closed: true, managed: true }
    } finally { this.busy = false }
  }
  close(): Promise<void> {
    if (this.closeWork) return this.closeWork
    this.closing = true
    return this.closeWork = (async () => {
      const failures: unknown[] = []
      for (const cleanup of [() => this.closeVoice(), () => this.stop(), () => this.deps.platform.disconnect(), async () => {
        if (this.session) { const session = this.session; this.session = undefined; await this.releaseBrowser(session) }
      }, async () => { await this.deps.closeLocalTranslation?.() }]) {
        try { await cleanup() } catch (error) { failures.push(error) }
      }
      if (failures.length) throw new AggregateError(failures, 'Host native cleanup failed')
    })()
  }
}
