/** TikTok's sole Electron call is resolveProxy. Native Node has no automatic system proxy discovery. */
export const session = { defaultSession: { resolveProxy: async (_url: string) => 'DIRECT' } }
