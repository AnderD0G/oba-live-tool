/** Never forward platform arguments: they may contain cookies, URLs or provider credentials. */
export function createLogger(scope: string): any {
  const write = (level: string) => (..._private: unknown[]) => {
    if (level === 'error' || level === 'warn' || process.env.OBA_HOST_DEBUG === '1') console.error(JSON.stringify({ component: 'host-platform', scope, level }))
  }
  return { debug: write('debug'), info: write('info'), success: write('success'), warn: write('warn'), error: write('error'), scope: (name: string) => createLogger(name) }
}
export default createLogger('native')
