export interface NativeModelOptions { baseUrl: string; model: string; apiKey: string }
/** Real chat completions, one attempt only. Inputs and credentials never enter logs/errors. */
export function nativeModel(options: NativeModelOptions, request = fetch) {
  const base = new URL(options.baseUrl)
  if (!['http:', 'https:'].includes(base.protocol) || base.username || base.password || base.search || base.hash || !options.model.trim() || !options.apiKey.trim()) throw Error('HOST_MODEL_CONFIGURATION_INVALID')
  const endpoint = new URL(`${base.pathname.replace(/\/$/, '')}/chat/completions`, base.origin)
  return async (messages: { role: 'system' | 'user'; content: string }[], signal: AbortSignal): Promise<string> => {
    const response = await request(endpoint, { method: 'POST', redirect: 'error', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${options.apiKey}` },
      body: JSON.stringify({ model: options.model, messages, temperature: 0, response_format: { type: 'json_object' } }), signal: AbortSignal.any([signal, AbortSignal.timeout(30000)]) })
    if (!response.ok || !response.body) { await response.body?.cancel().catch(() => {}); throw Error('HOST_MODEL_REQUEST_FAILED') }
    const reader = response.body.getReader(), chunks: Uint8Array[] = []
    let length = 0
    try {
      for (;;) { const chunk = await reader.read(); if (chunk.done) break; length += chunk.value.byteLength; if (length > 256 * 1024) throw Error('HOST_MODEL_RESPONSE_INVALID'); chunks.push(chunk.value) }
      const result = JSON.parse(Buffer.concat(chunks).toString('utf8'))
      const text = result?.choices?.[0]?.message?.content
      if (typeof text !== 'string' || !text.trim() || text.length > 20000) throw Error('HOST_MODEL_RESPONSE_INVALID')
      return text
    } catch { throw Error('HOST_MODEL_RESPONSE_INVALID') }
    finally { await reader.cancel().catch(() => {}) }
  }
}
