import assert from 'node:assert/strict'
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import test from 'node:test'
import { HostBridgeServer, type HostBridgeDriver } from '../host-bridge/HostBridgeServer'
import { createCoreRuntime } from '../server/CoreRuntime'

const accountId = 'isolated-host-core', adminToken = 'isolated-admin-core-host-token-32-characters', hostToken = 'isolated-native-host-token-32-characters'
async function setup(t: any) {
  const directory = await mkdtemp(join(tmpdir(), 'oba-core-real-host-'))
  const target = { username: 'fixture', url: 'https://www.tiktok.com/@fixture/live' }
  let emit: (event: any) => void = () => {}, starts = 0, stops = 0, sends = 0, recording = false, closed = 0
  const message = (id: string) => ({ msg_type: 'tiktok_comment', msg_id: id, user_id: `viewer-${id}`, nick_name: `Viewer ${id}`, content: 'Is this available?', metadata: { provenance: 'cdp-websocket-decoded' } })
  const driver: HostBridgeDriver = {
    status: async () => ({ version: 1, capabilities: { capture: true, platform: true, send: true, ai: true, voice: true, localTranslation: true, recording: false } }),
    platform: async () => ({ browserOpen: true, loginStatus: 'authenticated', roomReady: true, target }),
    start: async receive => { starts++; emit = receive; receive({ kind: 'message', message: message('startup-buffered') }); return { target } },
    stop: async () => { stops++ }, send: async (_text, signal) => { assert.equal(signal.aborted, false); sends++; return { sent: true } },
    close: async () => { closed++ },
    localTranslate: async () => ({ status: 'ready', method: 'chrome', chinese: '这件商品有货吗？', language: 'en', confidence: .99 }),
    translateDraft: async () => 'Yes, it is available.',
    voice: async path => { if (path === '/api/state') return { recording, busy: null }; recording = path === '/api/rec/start'; return { ok: true, recording, ...(path === '/api/rec/stop' ? { text: '有货，谢谢支持。' } : {}) } },
  }
  const host = new HostBridgeServer({ token: hostToken, accountId, host: '0.0.0.0', port: 0, driver })
  let core: Awaited<ReturnType<typeof createCoreRuntime>> | undefined, shutdownObserved = false
  t.after(async () => { try { try { if (!shutdownObserved) await core?.stop() } finally { await host.close() } } finally { await rm(directory, { recursive: true, force: true }) } })
  const baseUrl = await host.start()
  core = await createCoreRuntime({ dataDirectory: directory, adminToken, accountId, bridge: { baseUrl, token: hostToken }, adminHost: '127.0.0.1', adminPort: 0, mobileHost: '127.0.0.1', mobilePort: 0, advertisedAddress: '127.0.0.1', mobileAssetDirectory: resolve('public/assistant-mobile'), adminAssetDirectory: resolve('server/public') })
  const api = async (path: string, body?: unknown) => {
    const response = await fetch(core!.adminUrl + path, { headers: { Authorization: `Bearer ${adminToken}`, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) }, ...(body === undefined ? {} : { method: 'POST', body: JSON.stringify(body) }), signal: AbortSignal.timeout(5000) })
    return response.json() as Promise<any>
  }
  const command = (action: string, params: any = {}) => api('/api/command', { action, params: { accountId, ...params } })
  const state = () => api('/api/state')
  const mobile = async (path: string, body?: unknown) => (await fetch(core!.mobileUrls[0] + path, { ...(body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }), signal: AbortSignal.timeout(5000) })).json() as Promise<any>
  return { core, host, driver, api, command, state, mobile, message, emit: (event: any) => emit(event), counts: () => ({ starts, stops, sends, closed }),
    async observeLostHostShutdown() { try { await assert.rejects(core!.stop(), (error: any) => error.code === 'CAPTURE_STOP_FAILED') } finally { shutdownObserved = true } },
  }
}
async function until(read: () => Promise<any>, match: (value: any) => boolean) {
  const deadline = Date.now() + 7000
  for (;;) { const value = await read(); if (match(value)) return value; if (Date.now() > deadline) assert.fail('real host/core fixture did not settle'); await new Promise(done => setTimeout(done, 25)) }
}

test('real CoreRuntime and native HostBridgeServer interoperate over HTTP with startup replay, phone voice, translation and send deduplication', { timeout: 20000 }, async t => {
  const f = await setup(t), status = await f.api('/api/status')
  assert.equal(status.data.hostBridge.connected, true); assert.equal(status.data.capabilities.capture, true)
  const context = (await f.state()).data.context
  assert.equal((await f.command('context-save', { expectedRevision: context.revision, context: { ...context, translationEnabled: true, translationMode: 'local', replyMode: 'off', aiPaused: true } })).ok, true)
  assert.equal((await f.api('/api/platform', { action: 'state', accountId })).data.roomReady, true)
  assert.equal((await f.command('start')).ok, true)
  await until(f.state, v => v.data.rows[0]?.translation.status === 'ready')
  for (let n = 0; n < 5; n++) f.emit({ kind: 'message', message: f.message(`after-connect-${n}`) })
  const loaded = await until(f.state, v => v.data.rows.length === 6 && v.data.rows.every((r: any) => r.translation.status === 'ready'))
  const row = loaded.data.rows[0]
  assert.equal(loaded.data.health.dropped, 0)
  assert.equal((await f.mobile('api/command', { action: 'attention-pin', params: { rowId: row.id, pinned: true } })).ok, true)
  assert.ok((await f.mobile('api/state')).data.tasks.some((task: any) => task.id === row.id))
  assert.equal((await f.mobile('api/voice', { action: 'start', rowId: row.id })).data.status, 'recording')
  const spoken = await f.mobile('api/voice', { action: 'stop', rowId: row.id })
  assert.equal(spoken.data.text, '有货，谢谢支持。'); assert.equal(f.counts().sends, 0)
  const translated = await f.command('reply-translate', { rowId: row.id, chinese: spoken.data.text, requestId: 'real-host-draft' })
  assert.equal(translated.ok, true)
  const send = { rowId: row.id, expectedText: translated.data.reply.text, requestId: 'real-host-send' }
  assert.equal((await f.command('reply-approve', send)).ok, true)
  assert.equal((await f.command('reply-approve', send)).ok, true)
  assert.equal(f.counts().sends, 1)
  assert.equal((await f.command('stop')).ok, true)
  const final = await f.state()
  assert.equal(final.data.activeSession, undefined); assert.equal(final.data.health.pendingWrites, 0); assert.equal(final.data.health.dropped, 0)
  assert.equal(f.counts().starts, 1); assert.equal(f.counts().stops, 1)
  await mkdir(resolve('artifacts/docker-core'), { recursive: true })
  await writeFile(resolve('artifacts/docker-core/native-host-integration.json'), JSON.stringify({ realCoreRuntime: true, realHostBridgeServer: true, network: 'isolated loopback HTTP', externalDriver: 'fixture; no TikTok browser, model, microphone or public send', rawRows: final.data.rows.length, drops: final.data.health.dropped, pending: final.data.health.pendingWrites, starts: f.counts().starts, stops: f.counts().stops, fixtureSendCalls: f.counts().sends, startupReplay: true, mobileVoiceAndPin: true }, null, 2))
})

test('real native host loss interrupts its owned core scene and blocks stale sends', { timeout: 15000 }, async t => {
  const f = await setup(t)
  assert.equal((await f.command('start')).ok, true)
  await until(f.state, v => v.data.rows.length === 1)
  await f.host.close()
  const stopped = await until(f.state, v => !v.data.activeSession && v.data.sessions[0]?.status === 'interrupted')
  assert.equal(stopped.data.sessions[0].reason, 'HOST_BRIDGE_DISCONNECTED')
  assert.equal(f.counts().stops, 1); assert.equal(f.counts().sends, 0)
  // A vanished host cannot confirm release. Preserve the explicit uncertainty while
  // verifying shutdown still closes HTTP/database resources and never retries send.
  await f.observeLostHostShutdown()
})
