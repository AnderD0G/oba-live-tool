import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import test from 'node:test'

test('opt-in isolated pressure controls exercise delayed translation/send and exact request replay without real devices', { timeout: 30000 }, async t => {
  const folder = await mkdtemp(join(tmpdir(), 'oba-pressure-controls-test-')), output = join(folder, 'result.json')
  t.after(() => rm(folder, { recursive: true, force: true }))
  const result = await new Promise<{ code: number | null; output: string }>((done, reject) => {
    const child = spawn(process.execPath, [resolve('node_modules/tsx/dist/cli.mjs'), resolve('scripts/stress-assistant-mobile-effects.ts'), '--smoke', '--controls', '--rates=10', '--seconds=1', '--history=100', `--out=${output}`], { windowsHide: true, stdio: 'pipe' })
    let text = ''; child.stdout.on('data', data => { text += data }); child.stderr.on('data', data => { text += data }); child.once('error', reject); child.once('exit', code => done({ code, output: text }))
  })
  assert.equal(result.code, 0, result.output)
  const report = JSON.parse(await readFile(output, 'utf8'))
  assert.equal(report.controls?.enabled, true, 'the --controls flag must execute and report its isolated controls, not be silently ignored')
  assert.ok(report.controls.successfulProbes >= 1)
  assert.equal(report.controls.translateDraftCalls, report.controls.successfulProbes)
  assert.equal(report.controls.fixtureSendCalls, report.controls.successfulProbes, 'exact send request replay never invokes the fixture sender twice')
  assert.deepEqual(report.controls.errors, [])
  assert.equal(report.controls.realPublicMessagesSent, 0)
  assert.ok(report.controls.probes.every((probe: any) => probe.translateMs >= 90 && probe.sendMs >= 90 && probe.translationReplay && probe.sendReplay))
  assert.equal(report.received, report.durableRowsAfterCleanup); assert.equal(report.finalHealth.dropped, 0)
})
