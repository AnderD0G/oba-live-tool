// Explicitly isolated acceptance fixture, never included in the production image.
import { createServer } from 'node:http'
import { randomUUID } from 'node:crypto'
const token = process.env.FIXTURE_TOKEN, leases = new Map()
let recording = false, sends = 0
const server = createServer(async (request, response) => {
  if (request.headers.authorization !== `Bearer ${token}`) return response.writeHead(401).end()
  const url = new URL(request.url, 'http://fixture'), route = url.pathname
  let body = ''
  for await (const chunk of request) { body += chunk; if (body.length > 256 * 1024) return response.writeHead(413).end() }
  const input = body ? JSON.parse(body) : {}
  const reply = data => response.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ ok: true, data }))
  if (route === '/v1/status') return reply({ version: 1, capabilities: { capture: true, platform: true, localTranslation: true, voice: true, ai: true, send: true, recording: false } })
  if (route === '/v1/capture/start') {
    const lease = { leaseId: randomUUID(), generation: randomUUID(), captureSessionId: randomUUID(), startedAt: Date.now(), accountId: input.accountId, sequence: 0 }
    leases.set(lease.leaseId, lease); return reply({ ...lease, platform: 'tiktok' })
  }
  if (route === '/v1/capture/events') {
    const lease = leases.get(url.searchParams.get('leaseId'))
    if (!lease || lease.generation !== url.searchParams.get('generation') || lease.accountId !== url.searchParams.get('accountId')) return response.writeHead(409).end()
    lease.response = response; response.writeHead(200, { 'Content-Type': 'application/x-ndjson' }); response.flushHeaders(); return
  }
  if (route === '/v1/capture/stop') { const lease = leases.get(input.leaseId); if (lease && lease.generation === input.generation) { lease.response?.end(); leases.delete(input.leaseId) } return reply({ stopped: true }) }
  if (route === '/v1/local-translate') return reply({ status: 'ready', method: 'chrome', chinese: '这是隔离验收的合成中文译文。', language: 'en', confidence: .99 })
  if (route === '/v1/translate-draft') return reply({ text: 'Thank you for your support.' })
  if (route === '/v1/send') {
    const lease = leases.get(input.leaseId)
    if (!lease || lease.generation !== input.generation) return response.writeHead(409).end()
    sends++; return reply({ sent: true })
  }
  if (route === '/v1/voice') {
    if (input.path === '/api/state') return reply({ recording, busy: null })
    if (input.path === '/api/rec/start') { recording = true; return reply({ ok: true }) }
    recording = false; return reply({ ok: true, recording: false, text: '谢谢你的支持。' })
  }
  if (route === '/v1/platform') return reply({ accountId: input.accountId, sessionId: 'fixture-browser', platform: 'tiktok', supported: true, browserOpen: true, loginStatus: 'authenticated', roomReady: true, captureReady: true, busy: false })
  if (route === '/test/emit') {
    const lease = [...leases.values()].at(-1)
    if (!lease?.response) return response.writeHead(409).end()
    lease.response.write(JSON.stringify({ version: 1, leaseId: lease.leaseId, generation: lease.generation, sequence: ++lease.sequence, kind: 'message', message: input.message }) + '\n')
    return reply({ emitted: true })
  }
  if (route === '/test/close') { for (const lease of leases.values()) lease.response?.end(); return reply({ closed: true }) }
  if (route === '/test/status') return reply({ sends, recording, leases: leases.size })
  response.writeHead(404).end()
})
server.listen(17901, '0.0.0.0')
const heartbeat = setInterval(() => { for (const lease of leases.values()) lease.response?.write(JSON.stringify({ version: 1, leaseId: lease.leaseId, generation: lease.generation, sequence: ++lease.sequence, kind: 'heartbeat' }) + '\n') }, 10000)
process.once('SIGTERM', () => { clearInterval(heartbeat); for (const lease of leases.values()) lease.response?.end(); server.close() })
