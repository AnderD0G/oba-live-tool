import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { promisify } from 'node:util'
import test from 'node:test'
import { createCoreRuntime } from '../server/CoreRuntime'

test('private config importer uses current revisions on real core and never copies history or logs knowledge/token', { timeout: 30000 }, async t => {
  const folder = await mkdtemp(join(tmpdir(), 'oba-config-import-'))
  const token = 'private-config-fixture-token-32-chars'
  const core = await createCoreRuntime({ dataDirectory: join(folder, 'core'), adminToken: token, accountId: 'default', accountName: 'Fixture', adminHost: '127.0.0.1', adminPort: 0, mobileHost: '127.0.0.1', mobilePort: 0, advertisedAddress: '127.0.0.1', mobileAssetDirectory: resolve('public/assistant-mobile'), adminAssetDirectory: resolve('server/public') })
  t.after(async () => { await core.stop(); await rm(folder, { recursive: true, force: true }) })
  const state = async () => (await fetch(core.adminUrl + '/api/state', { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json()) as any).data
  const before = await state()
  const configuration = { format: 'oba-assistant-config', version: 1, accountId: 'default',
    context: { ...before.context, revision: 22, knowledge: 'PRIVATE fixture knowledge', instructions: 'PRIVATE fixture instruction', replyMode: 'off' },
    audiencePolicy: { ...before.audiencePolicy, revision: 8 }, replyPolicy: { ...before.replyPolicy, revision: 5 } }
  const source = join(folder, 'config.json'), key = join(folder, 'admin-token')
  await writeFile(source, JSON.stringify(configuration)); await writeFile(key, token)
  const run = promisify(execFile)
  const result = await run(process.execPath, ['scripts/import-docker-core-config.mjs', source, key, core.adminUrl + '/'], { windowsHide: true, timeout: 20000 })
  const receipt = JSON.parse(result.stdout)
  assert.equal(receipt.imported, true); assert.equal(receipt.applied.length, 3)
  assert.equal(receipt.audienceRecordsImported, 0); assert.equal(receipt.credentialsImported, false)
  assert.ok(!result.stdout.includes('PRIVATE')); assert.ok(!result.stdout.includes(token))
  const after = await state()
  assert.equal(after.context.revision, before.context.revision + 1)
  assert.equal(after.audiencePolicy.revision, before.audiencePolicy.revision + 1)
  assert.equal(after.replyPolicy.revision, before.replyPolicy.revision + 1)
  assert.equal(after.context.knowledge, configuration.context.knowledge)
  assert.equal(after.context.instructions, configuration.context.instructions)
  assert.equal(after.activeSession, undefined); assert.equal(after.rows.length, 0)
  assert.equal(await readFile(key, 'utf8'), token)
  const invalid = join(folder, 'invalid-policy.json')
  await writeFile(invalid, JSON.stringify({ ...configuration, audiencePolicy: { ...configuration.audiencePolicy, rules: 'invalid' } }))
  await assert.rejects(run(process.execPath, ['scripts/import-docker-core-config.mjs', invalid, key, core.adminUrl + '/'], { windowsHide: true, timeout: 20000 }), (error: any) => {
    const failure = JSON.parse(error.stderr)
    assert.equal(failure.partial, true); assert.equal(failure.applied.length, 1)
    assert.equal(failure.applied[0].action, 'context-save'); assert.ok(!error.stderr.includes(token)); return true
  })
  const partial = await state()
  assert.equal(partial.context.revision, after.context.revision + 1)
  assert.equal(partial.audiencePolicy.revision, after.audiencePolicy.revision)
  assert.equal(partial.replyPolicy.revision, after.replyPolicy.revision)
  await assert.rejects(run(process.execPath, ['scripts/import-docker-core-config.mjs', source, key, 'http://192.0.2.1:17892/'], { windowsHide: true, timeout: 5000 }), (error: any) => {
    const failure = JSON.parse(error.stderr); assert.equal(failure.code, 'LOCAL_ADMIN_ADDRESS_REQUIRED'); assert.deepEqual(failure.applied, []); return true
  })
})
