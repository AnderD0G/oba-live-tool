import assert from 'node:assert/strict'
import test from 'node:test'
import { HostBridgeServer, type HostBridgeDriver } from '../host-bridge/HostBridgeServer'

const token = 'isolated-host-fixture-secret-32-characters'
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(yes => { resolve = yes }); return { promise, resolve } }
async function eventually(check: () => boolean) { for (let n = 0; n < 100; n++) { if (check()) return; await new Promise(resolve => setTimeout(resolve, 5)) } assert.fail('fixture condition did not settle') }
async function fixture(t: any, patch: Partial<HostBridgeDriver> = {}, options: any = {}) {
  let stopped = 0, sends = 0
  const emitters: ((event: any) => void)[] = []
  const target = { username: 'fixture', url: 'https://www.tiktok.com/@fixture/live' }
  const driver: HostBridgeDriver = {
    status: async () => ({ version: 1, capabilities: { capture: true, platform: true, send: true, ai: false, voice: false, localTranslation: false, recording: false } }),
    platform: async () => ({ browserOpen: true, roomReady: true, loginStatus: 'authenticated', target }),
    start: async emit => { emitters.push(emit); return { target } }, stop: async () => { stopped++ }, send: async () => { sends++; return { sent: true } }, close: async () => {}, ...patch,
  }
  const server = new HostBridgeServer({ token, accountId: 'fixture', host: '127.0.0.1', port: 0, driver, ...options })
  const base = await server.start()
  const controllers: AbortController[] = []
  const request = (path: string, body?: unknown, signal?: AbortSignal) => {
    const controller = new AbortController(); controllers.push(controller)
    return fetch(base + path, { method: body === undefined ? 'GET' : 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.any([controller.signal, AbortSignal.timeout(3000), ...(signal ? [signal] : [])]) })
  }
  const start = async () => (await (await request('/v1/capture/start', { accountId: 'fixture', assistantSessionId: 'scene' })).json()).data
  const stream = (lease: any) => request(`/v1/capture/events?accountId=fixture&leaseId=${lease.leaseId}&generation=${lease.generation}`)
  t.after(async () => { options.beforeClose?.(); for (const controller of controllers) controller.abort(); await server.close() })
  return { server, driver, request, start, stream, target, emitters, counts: () => ({ stopped, sends }) }
}

test('host orphan startup cleanup stops the provider before waiting for its pending start', { timeout: 5000 }, async t => {
  const startGate = deferred<void>()
  let stopped = 0
  const f = await fixture(t, { start: async () => { await startGate.promise; return {} }, stop: async () => { stopped++; startGate.resolve() } }, { orphanTimeoutMs: 25, beforeClose: () => startGate.resolve() })
  const response = await f.request('/v1/capture/start', { accountId: 'fixture', assistantSessionId: 'scene' })
  assert.equal(response.status, 409)
  assert.equal(stopped, 1)
})

test('host never-connected leases expire, stale emitters cannot cross generations, and heartbeats carry their owner', async t => {
  const f = await fixture(t, {}, { orphanTimeoutMs: 30, heartbeatMs: 10 })
  const first = await f.start()
  await eventually(() => f.counts().stopped === 1)
  assert.equal((await f.request('/v1/send', { accountId: 'fixture', ...first, text: 'fixture' })).status, 409)
  const second = await f.start()
  const stream = await f.stream(second), reader = stream.body!.getReader()
  f.emitters[0]({ kind: 'message', message: { msg_id: 'old' } })
  const heartbeat = JSON.parse(new TextDecoder().decode((await reader.read()).value).trim())
  assert.equal(heartbeat.kind, 'heartbeat'); assert.equal(heartbeat.generation, second.generation); assert.equal(heartbeat.sequence, 1)
  await reader.cancel(); await eventually(() => f.counts().stopped === 2)
})

test('host refuses duplicate stream reservations even while startup is awaiting its provider', async t => {
  const gate = deferred<void>()
  const f = await fixture(t, { start: async () => { await gate.promise; return {} } }, { beforeClose: () => gate.resolve() })
  const start = f.request('/v1/capture/start', { accountId: 'fixture', assistantSessionId: 'scene' })
  await eventually(() => !!(f.server as any).lease)
  const lease = (f.server as any).lease.value
  const left = f.stream(lease), right = f.stream(lease)
  await new Promise(resolve => setTimeout(resolve, 20)); gate.resolve(); await start
  const responses = await Promise.all([left, right])
  assert.deepEqual(responses.map(response => response.status).sort(), [200, 409])
  for (const response of responses) await response.body?.cancel()
})

test('host byte overflow fails capture closed without waiting for the event-count limit', async t => {
  const f = await fixture(t)
  const lease = await f.start()
  for (let n = 0; n < 12; n++) f.emitters[0]({ kind: 'message', message: { msg_id: String(n), content: 'x'.repeat(100000) } })
  await eventually(() => f.counts().stopped === 1)
  assert.equal((await f.stream(lease)).status, 409)
  assert.equal((await f.request('/v1/send', { accountId: 'fixture', leaseId: lease.leaseId, generation: lease.generation, text: 'fixture' })).status, 409)
})

for (const operation of ['send', 'translate-draft', 'local-translate'] as const) test(`host HTTP disconnect aborts one pending ${operation} without retrying`, async t => {
  const entered = deferred<void>(), finished = deferred<void>()
  let calls = 0, aborted = false
  const wait = async (signal: AbortSignal) => { calls++; entered.resolve(); signal.addEventListener('abort', () => { aborted = true; finished.resolve() }, { once: true }); await finished.promise }
  const patch: Partial<HostBridgeDriver> = operation === 'send' ? { send: async (_text, signal) => { await wait(signal); return { sent: true } } } : operation === 'translate-draft' ? { translateDraft: async (_input, signal) => { await wait(signal); return 'fixture text' } } : { localTranslate: async (_text, signal) => { await wait(signal); return { status: 'uncertain' } } }
  const f = await fixture(t, patch, { beforeClose: () => finished.resolve() })
  const lease = operation === 'send' ? await f.start() : undefined
  const body = operation === 'send' ? { accountId: 'fixture', leaseId: lease.leaseId, generation: lease.generation, text: 'fixture' } : operation === 'translate-draft' ? { accountId: 'fixture', input: { chinese: '测试', targetLanguage: 'en' } } : { text: 'fixture' }
  const controller = new AbortController()
  const pending = f.request(`/v1/${operation}`, body, controller.signal)
  void pending.catch(() => {})
  await entered.promise; controller.abort()
  await assert.rejects(pending)
  await eventually(() => aborted)
  assert.equal(calls, 1)
})

test('host rechecks authentication and target before handing a send to the driver', async t => {
  const f = await fixture(t)
  const lease = await f.start()
  const body = { accountId: 'fixture', leaseId: lease.leaseId, generation: lease.generation, text: 'fixture' }
  f.driver.platform = async () => ({ browserOpen: true, roomReady: true, loginStatus: 'required', target: f.target })
  assert.equal((await f.request('/v1/send', body)).status, 409)
  f.driver.platform = async () => ({ browserOpen: true, roomReady: true, loginStatus: 'authenticated', target: { ...f.target, url: 'https://www.tiktok.com/@other/live' } })
  assert.equal((await f.request('/v1/send', body)).status, 409)
  assert.equal(f.counts().sends, 0)
})

test('failed stop keeps the host closed to new captures and never acknowledges an unconfirmed cleanup', async t => {
  const f = await fixture(t, { stop: async () => { throw Error('fixture cleanup failed') } }, { beforeClose: () => { f.driver.stop = async () => {}; (f.server as any).lease = undefined } })
  const lease = await f.start(), stop = { accountId: 'fixture', leaseId: lease.leaseId, generation: lease.generation }
  assert.equal((await f.request('/v1/capture/stop', stop)).status, 502)
  assert.notEqual((await f.request('/v1/capture/stop', stop)).status, 200)
  assert.equal((await f.request('/v1/capture/start', { accountId: 'fixture', assistantSessionId: 'new-scene' })).status, 409)
})
