import assert from 'node:assert/strict'
import { test } from 'node:test'
import { HostBridgeServer } from '../host-bridge/HostBridgeServer'

const token = 'fixture-host-secret-32-characters-long'
async function fixture(run: (f: any) => Promise<void>) {
  let receive: (value: any) => void = () => {}, stopped = 0, sent = 0, aborted = false
  const driver = {
    status: async () => ({ version: 1, capabilities: { capture: true, platform: true, send: true, ai: false, voice: false, recording: false, localTranslation: false } }),
    platform: async () => ({ browserOpen: true, loginStatus: 'authenticated', roomReady: true, target: { username: 'fixture', url: 'https://www.tiktok.com/@fixture/live' } }),
    start: async (emit: any) => { receive = emit; emit({ kind: 'message', message: { msg_id: 'startup' } }); return { target: { username: 'fixture', url: 'https://www.tiktok.com/@fixture/live' } } },
    stop: async () => { stopped++ },
    send: async (_text: string, signal: AbortSignal) => { sent++; if (signal.aborted) aborted = true; return { sent: true } },
    close: async () => {},
  }
  const server = new HostBridgeServer({ token, accountId: 'default', host: '127.0.0.1', port: 0, driver })
  const base = await server.start()
  const request = (path: string, body?: any, key = token) => fetch(`${base}${path}`, { method: body ? 'POST' : 'GET', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(3000) })
  try { await run({ request, base, server, driver, emit: (v: any) => receive(v), counts: () => ({ stopped, sent, aborted }) }) }
  finally { await server.close() }
}

test('host bridge authenticates, binds one account and rejects unlisted voice endpoints', async () => fixture(async ({ request }: any) => {
  assert.equal((await request('/v1/status?accountId=default', undefined, 'wrong')).status, 401)
  assert.equal((await request('/v1/status?accountId=other')).status, 403)
  assert.equal((await request('/v1/voice', { accountId: 'default', path: '/api/eval' })).status, 400)
  assert.equal((await request('/v1/status?accountId=default')).status, 200)
}))

test('host bridge replays startup events, checks generations and releases a disconnected stream', async () => fixture(async ({ request, counts }: any) => {
  const started = await (await request('/v1/capture/start', { accountId: 'default', assistantSessionId: 'scene-1' })).json()
  assert.equal(started.ok, true)
  const lease = started.data
  const wrong = await request('/v1/capture/stop', { accountId: 'default', leaseId: lease.leaseId, generation: 'wrong' })
  assert.equal(wrong.status, 409)
  const response = await request(`/v1/capture/events?accountId=default&leaseId=${lease.leaseId}&generation=${lease.generation}`)
  const reader = response.body.getReader()
  const line = new TextDecoder().decode((await reader.read()).value).split('\n').filter(Boolean).map(JSON.parse)[0]
  assert.equal(line.message.msg_id, 'startup')
  assert.equal(line.sequence, 1)
  assert.equal(line.generation, lease.generation)
  await reader.cancel()
  await new Promise(resolve => setTimeout(resolve, 40))
  assert.equal(counts().stopped, 1)
}))

test('host bridge sends only under the current lease, never retries and stops on bounded event overflow', async () => fixture(async ({ request, emit, counts }: any) => {
  assert.equal((await request('/v1/send', { accountId: 'default', text: 'fixture only' })).status, 409)
  const lease = (await (await request('/v1/capture/start', { accountId: 'default', assistantSessionId: 'scene' })).json()).data
  assert.equal((await request('/v1/send', { accountId: 'default', leaseId: lease.leaseId, generation: 'wrong', text: 'fixture only' })).status, 409)
  const sent = await (await request('/v1/send', { accountId: 'default', leaseId: lease.leaseId, generation: lease.generation, text: 'fixture only' })).json()
  assert.equal(sent.data.sent, true)
  assert.equal(counts().sent, 1)
  for (let i = 0; i < 2100; i++) emit({ kind: 'message', message: { msg_id: `${i}` } })
  await new Promise(resolve => setTimeout(resolve, 40))
  assert.equal(counts().stopped, 1)
  assert.equal((await request('/v1/send', { accountId: 'default', leaseId: lease.leaseId, generation: lease.generation, text: 'fixture only' })).status, 409)
}))
