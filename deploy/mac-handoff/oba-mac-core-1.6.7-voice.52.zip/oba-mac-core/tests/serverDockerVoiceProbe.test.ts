import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { mkdir, writeFile } from 'node:fs/promises'
import { createServer } from 'node:net'
import { resolve } from 'node:path'
import { promisify } from 'node:util'
import test from 'node:test'
const exec = promisify(execFile)
test('Docker core can probe the existing private voice service without recording or eval', { skip: process.env.OBA_DOCKER_VOICE_PROBE !== '1', timeout: 30000 }, async t => {
  const name = `oba-core-voice-probe-${randomUUID().slice(0,8)}`, token = randomUUID() + randomUUID()
  const socket = createServer(); await new Promise<void>(done => socket.listen(0,'127.0.0.1',done)); const port = (socket.address() as any).port; await new Promise<void>(done => socket.close(() => done()))
  const docker = async (...args: string[]) => (await exec('docker', args, { windowsHide: true, timeout: 20000, maxBuffer: 1024 * 1024 })).stdout.trim()
  t.after(async () => { await docker('stop','--time','10',name).catch(() => {}); await docker('rm',name).catch(() => {}) })
  await docker('run','--rm','-d','--name',name,'--network','oba-voice-poc_default','-p',`127.0.0.1:${port}:${port}`,'-e',`OBA_ADMIN_PORT=${port}`,'-e',`OBA_ADMIN_TOKEN=${token}`,'-e','OBA_MOBILE_PORT=17893','-e','OBA_VOICE_SERVICE_URL=http://chromium:7799/','oba-core:local')
  const deadline = Date.now() + 12000
  for (;;) { try { if ((await fetch(`http://127.0.0.1:${port}/healthz`)).ok) break } catch {} if (Date.now() > deadline) throw Error('probe core not ready'); await new Promise(done => setTimeout(done,100)) }
  const response = await fetch(`http://127.0.0.1:${port}/api/status`,{headers:{Authorization:`Bearer ${token}`}}).then(value=>value.json()) as any
  assert.equal(response.ok,true); assert.equal(response.data.voiceSource,'private-service'); assert.equal(response.data.capabilities.voice,true)
  assert.equal(response.data.capabilities.capture,false); assert.equal(response.data.hostBridge.configured,false)
  await mkdir(resolve('artifacts/docker-core'),{recursive:true})
  await writeFile(resolve('artifacts/docker-core/private-voice-probe.json'),JSON.stringify({passed:true,at:new Date().toISOString(),voiceSource:response.data.voiceSource,voiceAvailable:true,captureAvailable:false,scope:'actual core container joined existing private voice network; read-only GET /api/state capability check only; no record/start/stop/cancel/eval invoked',imageId:await docker('image','inspect','oba-core:local','--format','{{.Id}}')},null,2))
})
