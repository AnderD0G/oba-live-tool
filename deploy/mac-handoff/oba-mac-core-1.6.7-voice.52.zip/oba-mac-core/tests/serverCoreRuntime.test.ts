import assert from 'node:assert/strict'
import { randomUUID } from 'node:crypto'
import { mkdtemp, rm } from 'node:fs/promises'
import { createServer, type ServerResponse } from 'node:http'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import test from 'node:test'
import { HostBridgeClient } from '../server/HostBridgeClient'

const adminToken = 'isolated-test-admin-token-32-characters'
async function runtimeFactory() {
  const module = await import('../server/CoreRuntime').catch(() => undefined)
  assert.equal(typeof module?.createCoreRuntime, 'function', 'independent Node core entry is implemented')
  return module!.createCoreRuntime
}
async function temporary(t: any) {
  const path = await mkdtemp(join(tmpdir(), 'oba-server-core-'))
  t.coreCleanups = []
  t.after(async () => { try { for (const close of t.coreCleanups.reverse()) await close() } finally { await rm(path, { recursive: true, force: true }) } })
  return path
}
async function api(base: string, path: string, body?: unknown, token = adminToken) {
  const response = await fetch(base + path, { headers: { Authorization: `Bearer ${token}`, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) },
    ...(body === undefined ? {} : { method: 'POST', body: JSON.stringify(body) }) })
  return { status: response.status, body: await response.json() as any }
}
async function until(read: () => Promise<any>, match: (value: any) => boolean) {
  const deadline = Date.now() + 8000
  for (;;) { const value = await read(); if (match(value)) return value; if (Date.now() > deadline) assert.fail('fixture did not settle'); await new Promise(done => setTimeout(done, 20)) }
}
async function host(t: any) {
  const token = 'isolated-host-bridge-token-32-characters', requests: string[] = [], sends: string[] = []
  const leases = new Map<string, { id: string; generation: string; response?: ServerResponse; sequence: number }>()
  let recording = false, holdDraft = false
  const heldDrafts: ServerResponse[] = []
  const server = createServer(async (request, response) => {
    if (request.headers.authorization !== `Bearer ${token}`) { response.writeHead(401).end(); return }
    const url = new URL(request.url!, 'http://fixture'), path = url.pathname
    requests.push(path)
    if (path === '/v1/capture/events') {
      const lease = leases.get(url.searchParams.get('leaseId')!)!
      lease.response = response; response.writeHead(200, { 'Content-Type': 'application/x-ndjson' }); response.flushHeaders(); return
    }
    let input: any = {}; for await (const data of request) input = JSON.parse(data.toString())
    let data: any
    if (path === '/v1/status') data = { version: 1, capabilities: { capture: true, platform: true, localTranslation: true, voice: true, send: true, ai: true, recording: false } }
    else if (path === '/v1/capture/start') { const leaseId = randomUUID(); const generation = randomUUID(); leases.set(leaseId, { id: leaseId, generation, sequence: 0 }); data = { leaseId, generation, captureSessionId: randomUUID(), startedAt: Date.now(), platform: 'tiktok' } }
    else if (path === '/v1/capture/stop') { leases.get(input.leaseId)?.response?.end(); data = { stopped: true } }
    else if (path === '/v1/local-translate') data = { status: 'ready', method: 'chrome', chinese: '这件商品有货吗？', language: 'en', confidence: .99 }
    else if (path === '/v1/translate-draft') { if (holdDraft) { heldDrafts.push(response); return } data = { text: 'Thank you for your support.' } }
    else if (path === '/v1/send') { sends.push(input.text); data = { sent: true } }
    else if (path === '/v1/voice') {
      if (input.path === '/api/state') data = { recording, busy: null }
      else if (input.path === '/api/rec/start') { recording = true; data = { ok: true } }
      else { recording = false; data = { ok: true, recording: false, text: '谢谢你的支持。' } }
    } else data = { version: 1, loginStatus: 'authenticated', roomReady: true }
    response.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ ok: true, data }))
  })
  await new Promise<void>(done => server.listen(0, '127.0.0.1', done))
  t.coreCleanups.push(() => { for (const lease of leases.values()) lease.response?.end(); server.closeAllConnections(); return new Promise<void>(done => server.close(() => done())) })
  return { baseUrl: `http://127.0.0.1:${(server.address() as any).port}`, token, requests, sends, leases,
    emit(message: any, generation?: string) { const lease = [...leases.values()].at(-1)!; const sequence = generation && generation !== lease.generation ? lease.sequence + 1 : ++lease.sequence; lease.response!.write(JSON.stringify({ version: 1, leaseId: lease.id, generation: generation ?? lease.generation, sequence, kind: 'message', message }) + '\n') },
    gap() { const lease = [...leases.values()].at(-1)!; lease.sequence += 2; lease.response!.write(JSON.stringify({ version: 1, leaseId: lease.id, generation: lease.generation, sequence: lease.sequence, kind: 'heartbeat' }) + '\n') },
    closeStream() { [...leases.values()].at(-1)?.response?.end() },
    holdDraft() { holdDraft = true },
    releaseDraft() { holdDraft = false; for (const response of heldDrafts) response.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ ok: true, data: { text: 'Thank you for your support.' } })); heldDrafts.length = 0 },
  }
}
const options = (dataDirectory: string) => ({ dataDirectory, adminToken, accountId: 'a', accountName: 'Isolated core', adminHost: '127.0.0.1', adminPort: 0, mobileHost: '127.0.0.1', mobilePort: 0, advertisedAddress: '127.0.0.1', mobileAssetDirectory: resolve('public/assistant-mobile'), adminAssetDirectory: resolve('server/public') })

test('standalone core persists real configuration and refuses unauthorized, foreign-account and unavailable-device operations', async t => {
  const create = await runtimeFactory(), directory = await temporary(t)
  let core = await create(options(directory)); (t as any).coreCleanups.push(() => core.stop())
  assert.equal((await api(core.adminUrl, '/api/state', undefined, 'wrong')).status, 401)
  const status = (await api(core.adminUrl, '/api/status')).body
  assert.equal(status.data.capabilities.capture, false)
  assert.equal(status.data.capabilities.voice, false)
  const wrong = await api(core.adminUrl, '/api/command', { action: 'state', params: { accountId: 'other' } })
  assert.equal(wrong.status, 400)
  const state = (await api(core.adminUrl, '/api/state')).body.data
  const context = { ...state.context, knowledge: 'Persistent fixture knowledge', translationEnabled: false, replyMode: 'off', aiPaused: true }
  assert.equal((await api(core.adminUrl, '/api/command', { action: 'context-save', params: { accountId: 'a', expectedRevision: context.revision, context } })).body.ok, true)
  const start = await api(core.adminUrl, '/api/command', { action: 'start', params: { accountId: 'a' } })
  assert.equal(start.body.ok, false)
  assert.equal((await api(core.adminUrl, '/api/state')).body.data.activeSession, undefined)
  await core.stop(); core = await create(options(directory))
  assert.equal((await api(core.adminUrl, '/api/state')).body.data.context.knowledge, context.knowledge)
  const mobile = await fetch(core.mobileUrls[0] + 'api/state').then(response => response.json()) as any
  assert.equal(mobile.ok, true); assert.equal(mobile.data.context, undefined)
  assert.equal((await fetch(core.adminUrl + '/')).status, 200)
  assert.equal((await fetch(core.adminUrl + '/').then(response => response.text())).includes(adminToken), false)
})

test('network host lease drives real SQLite, local translation, mobile tasks, voice draft and idempotent send', async t => {
  const create = await runtimeFactory(), directory = await temporary(t), bridge = await host(t)
  const core = await create({ ...options(directory), bridge }); (t as any).coreCleanups.push(() => core.stop())
  const command = (action: string, params: any = {}) => api(core.adminUrl, '/api/command', { action, params: { accountId: 'a', ...params } })
  assert.equal((await command('start', { platform: 'douyin' })).body.ok, false, 'the TikTok host must not produce facts mislabeled as another platform')
  assert.equal(bridge.requests.includes('/v1/capture/start'), false)
  const state = (await api(core.adminUrl, '/api/state')).body.data
  assert.equal((await command('context-save', { expectedRevision: state.context.revision, context: { ...state.context, translationEnabled: true, translationMode: 'local', replyMode: 'off', aiPaused: true } })).body.ok, true)
  assert.equal((await command('start')).body.ok, true)
  bridge.emit({ msg_type: 'tiktok_comment', msg_id: 'stale', user_id: 'old', nick_name: 'Old', content: 'Stale' }, 'wrong-generation')
  bridge.emit({ msg_type: 'tiktok_comment', msg_id: 'event-one', user_id: 'viewer', nick_name: 'Viewer', content: 'Is this item available?' })
  const ready = await until(() => api(core.adminUrl, '/api/state'), result => result.body.data.rows.some((row: any) => row.translation.status === 'ready'))
  assert.equal(ready.body.data.rows.length, 1)
  const row = ready.body.data.rows[0]
  assert.equal(row.original, 'Is this item available?'); assert.equal(row.translation.chinese, '这件商品有货吗？')
  const mobile = (path: string, body?: unknown) => fetch(core.mobileUrls[0] + path, body === undefined ? undefined : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then(response => response.json()) as Promise<any>
  assert.equal((await mobile('api/command', { action: 'attention-pin', params: { rowId: row.id, pinned: true } })).ok, true)
  assert.equal((await mobile('api/state')).data.tasks[0].id, row.id)
  assert.equal((await mobile('api/voice', { action: 'start', rowId: row.id })).data.status, 'recording')
  const voice = await mobile('api/voice', { action: 'stop', rowId: row.id })
  assert.equal(voice.data.text, '谢谢你的支持。'); assert.equal(bridge.sends.length, 0)
  const translated = await command('reply-translate', { rowId: row.id, chinese: voice.data.text, requestId: 'draft-one' })
  assert.equal(translated.body.ok, true)
  const params = { rowId: row.id, expectedText: translated.body.data.reply.text, requestId: 'send-one' }
  assert.equal((await command('reply-approve', params)).body.ok, true)
  assert.equal((await command('reply-approve', params)).body.ok, true)
  assert.equal(bridge.sends.length, 1)
  assert.equal((await command('stop')).body.ok, true)
  assert.ok(bridge.requests.includes('/v1/capture/stop'))
})

test('an unexpected host stream end interrupts its scene rather than silently remaining collecting', async t => {
  const create = await runtimeFactory(), directory = await temporary(t), bridge = await host(t)
  const core = await create({ ...options(directory), bridge }); (t as any).coreCleanups.push(() => core.stop())
  assert.equal((await api(core.adminUrl, '/api/command', { action: 'start', params: { accountId: 'a' } })).body.ok, true)
  bridge.closeStream()
  const stopped = await until(() => api(core.adminUrl, '/api/state'), result => !result.body.data.activeSession && result.body.data.sessions[0].status === 'interrupted')
  assert.equal(stopped.body.data.sessions[0].status, 'interrupted')
  assert.equal(stopped.body.data.sessions[0].reason, 'HOST_BRIDGE_DISCONNECTED')
})

test('bridge ownership tags preserve DOM, native and absent provenance without promoting trust', async t => {
  await temporary(t)
  const fixture = await host(t), client = new HostBridgeClient(fixture), received: any[] = []
  ;(t as any).coreCleanups.push(() => client.close())
  await client.startCapture('a', randomUUID(), { onCreated: async () => {}, onMessage: message => received.push(message), onBusiness: () => {}, onDisconnected: () => {} })
  fixture.emit({ msg_type: 'tiktok_comment', metadata: { provenance: 'dom-observation' } })
  fixture.emit({ msg_type: 'tiktok_comment' })
  fixture.emit({ msg_type: 'tiktok_comment', metadata: { provenance: 'cdp-websocket-decoded' } })
  await until(async () => received, value => value.length === 3)
  assert.equal(received[0].metadata.provenance, 'dom-observation')
  assert.equal(Object.hasOwn(received[1].metadata, 'provenance'), false)
  assert.equal(received[2].metadata.provenance, 'cdp-websocket-decoded')
  assert.ok(received.every(message => typeof message.metadata.captureGeneration === 'string'))
})

test('a gap in the owning host sequence fails closed and interrupts capture', async t => {
  const create = await runtimeFactory(), directory = await temporary(t), bridge = await host(t)
  const core = await create({ ...options(directory), bridge }); (t as any).coreCleanups.push(() => core.stop())
  assert.equal((await api(core.adminUrl, '/api/command', { action: 'start', params: { accountId: 'a' } })).body.ok, true)
  bridge.gap()
  const ended = await until(() => api(core.adminUrl, '/api/state'), result => result.body.data.sessions[0].status === 'interrupted')
  assert.equal(ended.body.data.sessions[0].reason, 'HOST_BRIDGE_DISCONNECTED')
})

test('shutdown cancels an in-flight management translation before waiting for HTTP drain', async t => {
  const create = await runtimeFactory(), directory = await temporary(t), bridge = await host(t)
  const core = await create({ ...options(directory), bridge }); (t as any).coreCleanups.push(() => core.stop())
  const command = (action: string, params: any = {}) => api(core.adminUrl, '/api/command', { action, params: { accountId: 'a', ...params } })
  const context = (await api(core.adminUrl, '/api/state')).body.data.context
  await command('context-save', { expectedRevision: context.revision, context: { ...context, translationEnabled: true, translationMode: 'local', replyMode: 'off', aiPaused: true } })
  await command('start')
  bridge.emit({ msg_type: 'tiktok_comment', msg_id: 'shutdown-row', user_id: 'viewer', nick_name: 'Viewer', content: 'Hello', metadata: { provenance: 'sdk-decoded' } })
  const ready = await until(() => api(core.adminUrl, '/api/state'), result => result.body.data.rows[0]?.translation.status === 'ready')
  const rowId = ready.body.data.rows[0].id
  assert.equal((await command('attention-pin', { rowId, pinned: true })).body.ok, true)
  bridge.holdDraft()
  const request = command('reply-translate', { rowId, chinese: '谢谢支持。', requestId: 'held-shutdown' }).catch(() => undefined)
  await until(async () => bridge.requests, value => value.includes('/v1/translate-draft'))
  const stopping = core.stop()
  const completed = await Promise.race([stopping.then(() => true), new Promise<boolean>(done => setTimeout(() => done(false), 1500))])
  bridge.releaseDraft(); await stopping; await request
  assert.equal(completed, true, 'core cancellation must run while HTTP listeners drain, rather than waiting for the model timeout')
})
