import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'
import { AssistantDeskService } from '../electron/main/services/assistantDesk/AssistantDeskService'

async function fixture(t: any, condition = { field: 'comments', operator: 'gte', value: 2 }) {
  const folder = await mkdtemp(join(tmpdir(), 'oba-attention-refresh-')), accountId = 'refresh-fixture'
  let now = 1800000000000
  const service = new AssistantDeskService(folder, { now: () => now, interpret: async () => { throw Error('No model in refresh fixture') }, send: async () => { throw Error('No sender in refresh fixture') }, startCapture: async () => ({ release: async () => {} }) })
  t.after(async () => { await service.shutdown(); await rm(folder, { recursive: true, force: true }) })
  const internal = service as any
  const execute = async (action: string, params: any = {}) => { const value = await service.execute({ action, params: { accountId, ...params } } as any); assert.equal(value.ok, true, JSON.stringify(value)); return (value as any).data }
  const policy = { enabled: true, attentionWindowSeconds: 600, rules: [{ id: 'fixture-rule', label: 'Fixture audience', enabled: true, priority: 100, conditions: [condition], result: { tier: 'gold', label: 'Fixture audience', autoAttention: true } }] }
  const setPolicy = async (patch: any = {}) => { const current = await execute('policy-get'); return execute('policy-save', { expectedRevision: current.revision, policy: { ...policy, ...patch } }) }
  const context = await execute('context-get')
  await execute('context-save', { expectedRevision: context.revision, context: { ...context, aiPaused: true, replyMode: 'off', translationEnabled: false, attentionMaxAgeSeconds: 600 } })
  await setPolicy()
  let scene = await execute('start')
  const row = (id: string, viewer = id, patch: any = {}) => ({ id, accountId, sessionId: scene.id, platform: 'tiktok', receivedAt: now, sourceEventId: `event-${id}`, userId: `viewer-${viewer}`, audienceUuid: `uuid-${viewer}`, nickname: `Fixture ${viewer}`, kind: 'comment', original: `Question ${id}`, translation: { status: 'ready', source: 'local', chinese: '这是合成问题。', language: 'en' }, reply: { status: 'none' }, ...patch })
  const persist = async (id: string, viewer = id, patch: any = {}) => { const value = row(id, viewer, patch); await internal.persist('row', accountId, value); return value }
  const reads: string[] = [], remember = internal.rememberPolicyAttention.bind(internal)
  internal.rememberPolicyAttention = (value: any) => { reads.push(value.id); return remember(value) }
  return { service, internal, accountId, execute, state: () => execute('state'), setPolicy, persist, row, reads, now: () => now, at: (value: number) => { now = value }, advance: (ms: number) => { now += ms }, scene: () => scene, restart: async () => { await execute('stop'); scene = await execute('start'); return scene } }
}

test('unchanged snapshots do not classify every stored candidate again; one changed viewer refreshes only its rows', async t => {
  const f = await fixture(t)
  await f.persist('a-one', 'a'); await f.persist('b-one', 'b'); await f.persist('b-two', 'b')
  await f.state(); f.reads.length = 0
  await f.state(); f.advance(100); await f.state()
  assert.deepEqual(f.reads, [], 'a read with unchanged facts must not reclassify its entire candidate window')
  await f.persist('a-two', 'a'); f.reads.length = 0
  const state = await f.state()
  assert.deepEqual(new Set(state.attention.rows.map((row: any) => row.id)), new Set(['a-one', 'a-two', 'b-one', 'b-two']))
  assert.deepEqual(new Set(f.reads), new Set(['a-one', 'a-two']), 'new audience counters must update its older comments without reclassifying unrelated viewers')
})

test('policy, tag, context and enriched language changes remain immediately visible', async t => {
  const f = await fixture(t, { field: 'messageLanguage', operator: 'eq', value: 'vi' } as any)
  const row = await f.persist('language-row', 'a')
  assert.equal((await f.state()).attention.total, 0)
  await f.internal.persist('row', f.accountId, { ...row, translation: { ...row.translation, language: 'vi' } })
  assert.equal((await f.state()).attention.total, 1)
  await f.setPolicy({ rules: [{ id: 'manual-country', label: 'Manual country', enabled: true, priority: 100, conditions: [{ field: 'manualCountry', operator: 'eq', value: 'TH' }], result: { tier: 'gold', label: 'Manual country', autoAttention: true } }] })
  assert.equal((await f.state()).attention.total, 0)
  await f.execute('audience-tag', { audienceUuid: 'uuid-a', expectedRevision: 0, countryCode: 'TH' })
  assert.equal((await f.state()).attention.total, 1)
  await f.setPolicy({ enabled: false })
  assert.equal((await f.state()).attention.total, 0)
})

test('future rows reclassify when wall time admits them, even after a policy change with no further facts', async t => {
  const f = await fixture(t, { field: 'payLevel', operator: 'gte', value: 15 })
  await f.setPolicy({ enabled: false })
  const initial = f.now()
  await f.persist('future', 'a', { receivedAt: initial + 5000, payLevel: 20 })
  await f.state(); await f.setPolicy({ enabled: true }); await f.state()
  f.advance(6000)
  assert.deepEqual((await f.state()).attention.rows.map((row: any) => row.id), ['future'])
  f.at(initial)
  assert.equal((await f.state()).attention.rows.length, 0, 'a reversed clock cannot expose future rows')
  f.advance(6000)
  assert.deepEqual((await f.state()).attention.rows.map((row: any) => row.id), ['future'])
})

test('context window expansion, pause/resume and session replacement cannot reuse an old refresh owner', async t => {
  const f = await fixture(t, { field: 'comments', operator: 'gte', value: 1 })
  const initial = f.now()
  await f.persist('current', 'a')
  await f.state(); const clock = (await f.state()).attention.window
  await f.execute('attention-countdown', { windowId: clock.id, paused: true })
  f.advance(700000)
  assert.ok((await f.state()).attention.rows.some((row: any) => row.id === 'current'), 'paused logical time retains current work')
  await f.execute('attention-countdown', { windowId: (await f.state()).attention.window.id, paused: false })
  f.advance(601000)
  assert.equal((await f.state()).attention.total, 0)
  await f.restart(); await f.persist('new-scene', 'a')
  assert.deepEqual((await f.state()).attention.rows.map((row: any) => row.id), ['new-scene'])
  assert.ok(f.now() > initial)
})

test('a failed read refresh keeps dirty viewers and retries the complete membership transaction', async t => {
  const f = await fixture(t)
  await f.persist('first', 'a'); await f.state(); await f.persist('second', 'a')
  const remember = f.internal.rememberPolicyAttention.bind(f.internal)
  let visited = 0
  f.internal.rememberPolicyAttention = (row: any) => { if (++visited === 2) throw Error('Fixture refresh interrupted'); return remember(row) }
  const failed = await f.service.execute({ action: 'state', params: { accountId: f.accountId } })
  assert.equal(failed.ok, false)
  f.internal.rememberPolicyAttention = remember
  assert.deepEqual(new Set((await f.state()).attention.rows.map((row: any) => row.id)), new Set(['first', 'second']))
})

test('dirty viewer tracking has a bounded full-refresh fallback and unknown identities remain conservative', async t => {
  const f = await fixture(t, { field: 'comments', operator: 'gte', value: 1 })
  await f.persist('known', 'a'); await f.state()
  assert.equal(typeof f.internal.markPolicyAttentionDirty, 'function', 'mutation-driven policy refresh tracking is implemented')
  for (let n = 0; n < 10000; n++) f.internal.markPolicyAttentionDirty(f.accountId, `uuid-${n}`)
  const dirty = f.internal.policyAttentionRefresh.get(f.accountId)
  assert.equal(dirty.full, true); assert.ok(dirty.viewers.size <= 512)
  for (let n = 0; n < 1000; n++) f.internal.markPolicyAttentionDirty(`other-account-${n}`, `uuid-${n}`)
  assert.ok(f.internal.policyAttentionRefresh.size <= 100, 'unknown account invalidations cannot grow an unbounded tracking map')
  await f.state()
  await f.persist('unknown', 'unknown', { userId: undefined, audienceUuid: undefined })
  f.reads.length = 0; await f.state()
  assert.ok(f.reads.includes('known'), 'an observation without stable identity cannot silently bypass refresh')
})

test('non-comment metadata updates and a wider TTL refresh formerly excluded viewer comments', async t => {
  const f = await fixture(t, { field: 'payLevel', operator: 'gte', value: 15 })
  let context = await f.execute('context-get')
  await f.execute('context-save', { expectedRevision: context.revision, context: { ...context, attentionMaxAgeSeconds: 60 } })
  await f.persist('old-comment', 'a'); await f.state()
  f.advance(70000)
  await f.persist('metadata-like', 'a', { kind: 'like', original: '', payLevel: 20 })
  assert.ok(!(await f.state()).attention.rows.some((row: any) => row.id === 'old-comment'))
  context = await f.execute('context-get')
  await f.execute('context-save', { expectedRevision: context.revision, context: { ...context, attentionMaxAgeSeconds: 120 } })
  assert.ok((await f.state()).attention.rows.some((row: any) => row.id === 'old-comment'), 'newer public metadata from a like applies to the older comment after its TTL expands')
})

test('the same audience UUID in another account does not invalidate or populate this account membership', async t => {
  const f = await fixture(t)
  await f.persist('owner-first', 'a'); await f.state(); f.reads.length = 0
  const policy = await f.execute('policy-get')
  await f.internal.persist('audience-policy', 'other', policy)
  const started = await f.service.execute({ action: 'start', params: { accountId: 'other' } })
  assert.equal(started.ok, true)
  const scene = (started as any).data
  for (const id of ['other-first', 'other-second']) await f.internal.persist('row', 'other', f.row(id, 'a', { accountId: 'other', sessionId: scene.id }))
  f.reads.length = 0
  assert.equal((await f.state()).attention.total, 0)
  assert.deepEqual(f.reads, [], 'another account viewer mutation must not trigger a full refresh here')
  const other = await f.service.execute({ action: 'state', params: { accountId: 'other' } })
  assert.equal(other.ok, true)
  assert.deepEqual(new Set((other as any).data.attention.rows.map((row: any) => row.id)), new Set(['other-first', 'other-second']))
})
