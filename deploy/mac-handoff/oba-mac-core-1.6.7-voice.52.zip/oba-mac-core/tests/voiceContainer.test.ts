import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath, pathToFileURL } from 'node:url'
import test from 'node:test'
import { parse } from 'yaml'

const directory = fileURLToPath(new URL('../deploy/voice-container/', import.meta.url))
const tools = await import(pathToFileURL(`${directory}/probe-tools.mjs`).href)

test('voice POC publishes only a loopback HTTPS desktop, preserving existing voice ports', async () => {
  const config = parse(await readFile(`${directory}/compose.yaml`, 'utf8'))
  assert.equal(config.name, 'oba-voice-poc')
  assert.deepEqual(config.services.chromium.ports, ['127.0.0.1:13443:3001'])
  assert.equal(config.services.voice.network_mode, 'service:chromium')
  assert.equal(config.services.voice.ports, undefined)
  assert.equal(config.services.chromium.environment.SELKIES_MICROPHONE_ENABLED, 'true')
  assert.equal(config.services.chromium.environment.SELKIES_MICROPHONE_ON_START, 'false')
  assert.equal(config.services.chromium.environment.SELKIES_AUDIO_ENABLED, 'true')
  assert.equal(config.services.chromium.environment.SELKIES_AUDIO_ON_START, 'false')
  assert.equal(config.services.chromium.privileged, undefined)
  assert.equal(config.services.chromium.devices, undefined)
  assert.deepEqual(config.services.chromium.volumes, ['profile:/config'])
  assert.match(config.services.chromium.environment.CHROME_CLI, /--remote-debugging-port=9223/)
  assert.match(config.services.chromium.environment.CHROME_CLI, /--user-data-dir=\/config\/oba-voice-profile/)
})

test('synthetic audio is a deterministic 440Hz mono WAV, with no real input device', () => {
  const wav = tools.createToneWav({ seconds: 2, sampleRate: 48000, frequency: 440 })
  assert.equal(wav.toString('ascii', 0, 4), 'RIFF')
  assert.equal(wav.toString('ascii', 8, 12), 'WAVE')
  assert.equal(wav.readUInt16LE(22), 1)
  assert.equal(wav.readUInt32LE(24), 48000)
  assert.equal(wav.readUInt16LE(34), 16)
  assert.equal(wav.length, 44 + 2 * 48000 * 2)
  let crossings = 0
  let prior = 0
  for (let offset = 44; offset < wav.length; offset += 2) {
    const sample = wav.readInt16LE(offset)
    if (prior <= 0 && sample > 0) crossings++
    prior = sample
  }
  assert.equal(crossings, 880)
})

test('audio evidence rejects silence and unrelated noise rather than treating device presence as success', () => {
  assert.equal(tools.isForwardedTone({ maxRms: 0, peakHz: 440 }), false)
  assert.equal(tools.isForwardedTone({ maxRms: 0.1, peakHz: 1000 }), false)
  assert.equal(tools.isForwardedTone({ maxRms: 0.1, peakHz: 440 }), true)
  assert.equal(tools.isForwardedTone({ maxRms: NaN, peakHz: 440 }), false)
})

test('container audio probe measures the selected virtual microphone and releases it on failure', () => {
  const expression = tools.audioProbeExpression()
  assert.match(expression, /getUserMedia/)
  assert.match(expression, /getFloatTimeDomainData/)
  assert.match(expression, /getFloatFrequencyData/)
  assert.match(expression, /finally/)
  assert.match(expression, /getTracks\(\).*stop\(/s)
  assert.doesNotMatch(expression, /fetch\(|WebSocket\(/)
})
