import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { mkdir, writeFile } from 'node:fs/promises'
import { createServer } from 'node:net'
import { resolve } from 'node:path'
import { promisify } from 'node:util'
import test from 'node:test'
const exec = promisify(execFile)
const docker = async (...args: string[]) => (await exec('docker', args, { windowsHide: true, timeout: 90000, maxBuffer: 1024 * 1024 })).stdout.trim()
const freePort = async () => { const socket = createServer(); await new Promise<void>(done => socket.listen(0, '127.0.0.1', done)); const port = (socket.address() as any).port; await new Promise<void>(done => socket.close(() => done())); return port }
async function until<T>(read: () => Promise<T>, match: (value: T) => boolean, timeout = 15000) {
  const deadline = Date.now() + timeout
  for (;;) { try { const value = await read(); if (match(value)) return value } catch {} if (Date.now() > deadline) throw Error('container fixture did not settle'); await new Promise(done => setTimeout(done, 100)) }
}

test('actual Docker core runs network capture, mobile workflow and persisted restart without production services', { skip: process.env.OBA_DOCKER_TEST !== '1', timeout: 180000 }, async t => {
  const suffix = randomUUID().slice(0, 8), network = `oba-core-check-net-${suffix}`, volume = `oba-core-check-data-${suffix}`, core = `oba-core-check-main-${suffix}`, host = `oba-core-check-host-${suffix}`
  const [adminPort, mobilePort, fixturePort] = await Promise.all([freePort(), freePort(), freePort()])
  const adminToken = randomUUID() + randomUUID(), bridgeToken = randomUUID() + randomUUID()
  const image = process.env.OBA_CORE_TEST_IMAGE ?? 'oba-core:local', started = Date.now()
  const api = async (port: number, path: string, body?: unknown, token = adminToken) => {
    const response = await fetch(`http://127.0.0.1:${port}${path}`, { headers: { Authorization: `Bearer ${token}`, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) }, ...(body === undefined ? {} : { method: 'POST', body: JSON.stringify(body) }), signal: AbortSignal.timeout(15000) })
    return { status: response.status, body: await response.json() as any }
  }
  const command = (action: string, params: any = {}) => api(adminPort, '/api/command', { action, params: { accountId: 'fixture', ...params } })
  const fixture = (path: string, body?: unknown) => api(fixturePort, path, body, bridgeToken)
  const report: any = { scope: 'real Docker core and persistent volume; separate authenticated network fixture bridge', startedAt: new Date().toISOString(), image, passed: false }
  t.after(async () => {
    await docker('stop', '--time', '60', core).catch(() => {})
    await docker('rm', core).catch(() => {})
    await docker('stop', '--time', '5', host).catch(() => {})
    await docker('rm', host).catch(() => {})
    await docker('volume', 'rm', volume).catch(() => {})
    await docker('network', 'rm', network).catch(() => {})
    report.elapsedMs = Date.now() - started; report.cleanedUp = true
    await mkdir(resolve('artifacts/docker-core'), { recursive: true })
    await writeFile(resolve('artifacts/docker-core/container-functional.json'), JSON.stringify(report, null, 2))
  })
  await docker('network', 'create', network); await docker('volume', 'create', volume)
  await docker('run', '-d', '--name', host, '--network', network, '--network-alias', 'fixture-host', '-p', `127.0.0.1:${fixturePort}:17901`, '-e', `FIXTURE_TOKEN=${bridgeToken}`,
    '--mount', `type=bind,source=${resolve('tests/serverFixtureHost.mjs')},target=/fixture.mjs,readonly`, 'public.ecr.aws/docker/library/node:24-bookworm-slim', 'node', '/fixture.mjs')
  await until(() => fixture('/v1/status'), result => result.body.ok)
  await docker('run', '-d', '--name', core, '--network', network, '-p', `127.0.0.1:${adminPort}:${adminPort}`, '-p', `127.0.0.1:${mobilePort}:${mobilePort}`,
    '-e', `OBA_ADMIN_PORT=${adminPort}`, '-e', `OBA_MOBILE_PORT=${mobilePort}`, '-e', 'OBA_MOBILE_ADDRESS=127.0.0.1', '-e', 'OBA_ACCOUNT_ID=fixture',
    '-e', `OBA_ADMIN_TOKEN=${adminToken}`, '-e', 'OBA_HOST_BRIDGE_URL=http://fixture-host:17901/', '-e', `OBA_HOST_BRIDGE_TOKEN=${bridgeToken}`, '-v', `${volume}:/data`, image)
  await until(() => api(adminPort, '/api/status'), result => result.body.data?.hostBridge.connected)
  assert.equal((await api(adminPort, '/api/state', undefined, 'wrong')).status, 401)
  assert.equal((await api(adminPort, '/api/platform', { action: 'state', accountId: 'fixture' })).body.data.loginStatus, 'authenticated')
  let state = (await api(adminPort, '/api/state')).body.data
  assert.equal(state.database.engine, 'sqlite')
  assert.equal((await command('context-save', { expectedRevision: state.context.revision, context: { ...state.context, knowledge: 'Container restart fixture', translationEnabled: true, translationMode: 'local', replyMode: 'off', aiPaused: true } })).body.ok, true)
  assert.equal((await command('start')).body.ok, true)
  await fixture('/test/emit', { message: { msg_type: 'tiktok_comment', msg_id: 'docker-first', user_id: 'viewer', nick_name: 'Viewer', content: 'Is this item available?', pay_level: 20, follower_count: 200, metadata: { provenance: 'cdp-websocket-decoded' } } })
  const translated = await until(() => api(adminPort, '/api/state'), result => result.body.data.rows[0]?.translation.status === 'ready')
  state = translated.body.data; const row = state.rows[0]
  assert.equal(row.original, 'Is this item available?')
  const mobileUrl = (await api(adminPort, '/api/mobile')).body.data.urls[0]
  const mobile = async (path: string, body?: unknown) => { const response = await fetch(mobileUrl + path, body === undefined ? undefined : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); return response.json() as Promise<any> }
  assert.equal((await mobile('api/command', { action: 'attention-pin', params: { rowId: row.id, pinned: true } })).ok, true)
  assert.ok((await mobile('api/state')).data.tasks.some((task: any) => task.id === row.id))
  assert.equal((await mobile('api/voice', { action: 'start', rowId: row.id })).data.status, 'recording')
  const voice = await mobile('api/voice', { action: 'stop', rowId: row.id }); assert.equal(voice.data.text, '谢谢你的支持。')
  const draft = await command('reply-translate', { rowId: row.id, chinese: voice.data.text, requestId: 'docker-draft' }); assert.equal(draft.body.ok, true)
  const send = { rowId: row.id, expectedText: draft.body.data.reply.text, requestId: 'docker-send' }
  assert.equal((await command('reply-approve', send)).body.ok, true); assert.equal((await command('reply-approve', send)).body.ok, true)
  assert.equal((await fixture('/test/status')).body.data.sends, 1)
  const marker = await mobile('api/command', { action: 'segment-toggle', params: { requestId: 'mark-open', sessionId: state.activeSession.id, expectedOpenSegmentId: null } }); assert.equal(marker.ok, true)
  assert.equal((await mobile('api/command', { action: 'segment-toggle', params: { requestId: 'mark-close', sessionId: state.activeSession.id, expectedOpenSegmentId: marker.data.id } })).ok, true)
  // Modest headroom load, not an upper-limit stress test.
  for (let i = 0; i < 30; i++) { await fixture('/test/emit', { message: { msg_type: 'tiktok_comment', msg_id: `docker-${i}`, user_id: `viewer-${i}`, nick_name: `Fixture ${i}`, content: `Synthetic item question ${i}`, metadata: { provenance: 'sdk-decoded' } } }); await new Promise(done => setTimeout(done, 100)) }
  await until(() => api(adminPort, '/api/state'), result => result.body.data.rows.length === 31 && result.body.data.health.pendingWrites === 0)
  assert.equal((await command('stop')).body.ok, true)
  state = (await api(adminPort, '/api/state')).body.data
  assert.equal(state.health.dropped, 0); assert.equal(state.currentMarker.completed, 0)
  assert.equal(state.segments.length, 1); assert.ok(state.segments[0].endedAt)
  await docker('restart', '--time', '60', core)
  const restored = await until(() => api(adminPort, '/api/state'), result => result.body.ok)
  assert.equal(restored.body.data.context.knowledge, 'Container restart fixture'); assert.equal(restored.body.data.rows.length, 31); assert.equal(restored.body.data.activeSession, undefined)
  assert.equal((await command('reply-approve', send)).body.ok, true); assert.equal((await fixture('/test/status')).body.data.sends, 1)
  report.passed = true; report.rows = 31; report.dropped = restored.body.data.health.dropped; report.persistedRestart = true; report.sendAttempts = 1; report.voiceFixtureOnly = true
  report.node = await docker('exec', core, 'node', '-p', 'process.version')
  report.imageId = await docker('image', 'inspect', image, '--format', '{{.Id}}')
  report.baseIndexDigest = 'sha256:a5f4366e834695d5f363b920c104953a535d3a9864d1bdf74566a0ebe01daee5'
  report.checks = ['admin auth', 'platform route', 'network capture lease', 'real SQLite', 'local translation adapter', 'mobile pin/tasks', 'voice draft', 'translation', 'send idempotency before/after restart', 'mobile marker', '31-row zero-drop modest input', 'graceful restart persistence']
})
