import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import test from 'node:test'

async function factory() { const module = await import('../server/VoiceServiceClient').catch(() => undefined); assert.equal(typeof module?.VoiceServiceClient, 'function', 'fixed private voice-service adapter exists'); return module!.VoiceServiceClient }
async function fixture(t: any) {
  const paths: string[] = []
  let recording = false
  const server = createServer((request, response) => {
    paths.push(`${request.method} ${request.url}`)
    if (request.url === '/api/state') return response.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ recording, busy: null }))
    if (request.url === '/api/rec/start') recording = true
    else recording = false
    response.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ ok: true, recording, text: '隔离语音输入。' }))
  })
  await new Promise<void>(done => server.listen(0, '127.0.0.1', done))
  t.after(() => { server.closeAllConnections(); return new Promise<void>(done => server.close(() => done())) })
  return { url: `http://127.0.0.1:${(server.address() as any).port}/`, paths }
}
test('private voice adapter only calls the four fixed endpoints and never exposes eval', async t => {
  const Client = await factory(), f = await fixture(t), client = new Client({ baseUrl: f.url })
  assert.equal(await client.available(), true)
  assert.equal((await client.request('/api/rec/start', 1000) as any).recording, true)
  assert.equal((await client.request('/api/rec/stop', 1000) as any).text, '隔离语音输入。')
  await client.request('/api/rec/cancel', 1000)
  await assert.rejects(() => client.request('/api/eval' as any, 1000))
  assert.deepEqual(f.paths, ['GET /api/state', 'POST /api/rec/start', 'POST /api/rec/stop', 'POST /api/rec/cancel'])
  assert.throws(() => new Client({ baseUrl: f.url + 'api/eval' }))
})
test('core reports separately reachable private voice even when the native host bridge is unavailable', async t => {
  await factory()
  const { createCoreRuntime } = await import('../server/CoreRuntime'), f = await fixture(t)
  const directory = await mkdtemp(join(tmpdir(), 'oba-core-private-voice-'))
  const core = await createCoreRuntime({ dataDirectory: directory, adminToken: 'private-voice-test-token-24-characters', accountId: 'a', adminHost: '127.0.0.1', adminPort: 0, mobileHost: '127.0.0.1', mobilePort: 0, advertisedAddress: '127.0.0.1', adminAssetDirectory: resolve('server/public'), mobileAssetDirectory: resolve('public/assistant-mobile'), voiceService: { baseUrl: f.url } })
  t.after(async () => { await core.stop(); await rm(directory, { recursive: true, force: true }) })
  const response = await fetch(core.adminUrl + '/api/status', { headers: { Authorization: 'Bearer private-voice-test-token-24-characters' } }).then(value => value.json()) as any
  assert.equal(response.data.hostBridge.connected, false)
  assert.equal(response.data.capabilities.capture, false)
  assert.equal(response.data.capabilities.voice, true)
  assert.equal(response.data.voiceSource, 'private-service')
})
test('private voice transport fails closed on redirects and oversized responses', async t => {
  const Client = await factory(), seen: string[] = []
  const server = createServer((request, response) => { seen.push(request.url!); if (request.url === '/api/state') response.writeHead(302, { Location: '/api/eval' }).end(); else response.writeHead(200).end('x'.repeat(130 * 1024)) })
  await new Promise<void>(done => server.listen(0, '127.0.0.1', done))
  t.after(() => { server.closeAllConnections(); return new Promise<void>(done => server.close(() => done())) })
  const client = new Client({ baseUrl: `http://127.0.0.1:${(server.address() as any).port}/` })
  assert.equal(await client.available(), false)
  await assert.rejects(() => client.request('/api/rec/stop', 1000))
  assert.deepEqual(seen, ['/api/state', '/api/rec/stop'])
})
