import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createServer } from 'node:http'
import { resolve } from 'node:path'
import test from 'node:test'
import { NativeHostDriver } from '../host-bridge/NativeHostDriver'
import { nativeModel } from '../host-bridge/provider'

function fixture(extra: any = {}) {
  let closedOwned = 0, releasedExternal = 0, submitted = 0, stopped = 0, business: any, invalidated: any
  const navigations: string[] = []
  const target = { username: 'fixture', url: 'https://www.tiktok.com/@fixture/live' }
  let snapshot: any = { browserOpen: true, loginStatus: 'authenticated', roomReady: true, target }
  const owned = { ownership: 'owned', page: { isClosed: () => false, goto: async (url: string) => { navigations.push(url) } }, context: { close: async () => { closedOwned++ } } }
  const external = { ownership: 'external', page: { isClosed: () => false }, context: { close: async () => assert.fail('Never close an attached user context') }, release: async () => { releasedExternal++ } }
  const platform: any = {
    openLoginBrowser: async () => {}, attachLoginBrowser: async () => {}, getPlatformSessionState: async () => snapshot,
    setLiveTarget: async () => {}, getLoginQrPreview: async () => ({}), startCommentListener: async (receive: any) => receive({ msg_type: 'tiktok_comment', msg_id: 'startup', content: 'fixture' }),
    stopCommentListener: async () => { stopped++ }, subscribeBusiness: (callback: any) => { business = callback; return () => { business = undefined } }, subscribeListenerInvalidation: (callback: any) => { invalidated = callback; return () => { invalidated = undefined } },
    performConfirmedComment: async () => { submitted++; return true }, disconnect: async () => {},
  }
  const driver = new NativeHostDriver({ accountId: 'a', platform, createBrowser: async () => owned as any, attachBrowser: async () => external as any, ...extra })
  const signal = new AbortController().signal
  return { driver, platform, signal, target, navigations, change: (value: any) => { snapshot = { ...snapshot, ...value } }, business: (value: any) => business?.(value), invalidate: () => invalidated?.('PAGE_CHANGED'), counts: () => ({ closedOwned, releasedExternal, submitted, stopped }) }
}

test('native driver uses the real login/capture/send contract and releases attached Chrome without closing its context', async () => {
  const f = fixture(), events: any[] = []
  try {
    const opened = await f.driver.platform({ accountId: 'a', action: 'open-login' }, f.signal)
    assert.equal(opened.loginStatus, 'authenticated')
    assert.equal(typeof opened.sessionId, 'string')
    await assert.rejects(f.driver.platform({ accountId: 'a', action: 'set-target', sessionId: 'wrong', target: '@fixture' }, f.signal))
    await f.driver.platform({ accountId: 'a', action: 'attach-browser', endpoint: 'http://127.0.0.1:9222', pageUrl: f.target.url }, f.signal)
    assert.equal(f.counts().closedOwned, 1)
    const capture = await f.driver.start(event => events.push(event), f.signal)
    assert.deepEqual(capture.target, f.target)
    assert.equal(events[0].message.msg_id, 'startup')
    f.business({ businessType: 'WebcastRoomUserSeqMessage', receivedAt: 1 })
    assert.deepEqual(events[1].observation.scope, { accountId: 'a', platform: 'tiktok', source: 'control' })
    assert.equal((await f.driver.send('fixture only', f.signal)).sent, true)
    assert.equal(f.counts().submitted, 1)
    f.change({ target: { username: 'other', url: 'https://www.tiktok.com/@other/live' } })
    await assert.rejects(f.driver.send('must not submit', f.signal))
    assert.equal(f.counts().submitted, 1)
    f.invalidate()
    assert.equal(events.at(-1).kind, 'invalidated')
    await assert.rejects(f.driver.send('must not submit', f.signal))
  } finally { await f.driver.close() }
  assert.equal(f.counts().releasedExternal, 1)
})

test('native abort while rechecking the authenticated room prevents submission and unknown voice paths never reach the service', async () => {
  let voiceCalls = 0
  const f = fixture({ voice: async () => { voiceCalls++; return {} } })
  try {
    await f.driver.platform({ accountId: 'a', action: 'open-login' }, f.signal)
    await f.driver.start(() => {}, f.signal)
    let release!: () => void
    f.platform.getPlatformSessionState = async () => { await new Promise<void>(resolve => { release = resolve }); return { browserOpen: true, loginStatus: 'authenticated', roomReady: true, target: f.target } }
    const controller = new AbortController()
    const send = f.driver.send('must not submit', controller.signal)
    controller.abort(); release()
    await assert.rejects(send)
    assert.equal(f.counts().submitted, 0)
    await assert.rejects(f.driver.voice('/api/eval' as any, f.signal))
    assert.equal(voiceCalls, 0)
  } finally { await f.driver.close() }
})

test('closing a managed room requires stopped capture, stops playback with a blank page, and never navigates an external user page', async () => {
  const f = fixture()
  try {
    await f.driver.platform({ accountId: 'a', action: 'open-login' }, f.signal)
    await f.driver.start(() => {}, f.signal)
    await assert.rejects((f.driver as any).closeRoom(f.signal))
    await f.driver.stop()
    assert.deepEqual(await (f.driver as any).closeRoom(f.signal), { closed: true, managed: true })
    assert.deepEqual(f.navigations, ['about:blank'])
    assert.equal(f.counts().closedOwned, 0, 'the owned persistent profile remains available and signed in')
    await f.driver.platform({ accountId: 'a', action: 'attach-browser', endpoint: 'http://127.0.0.1:9222', pageUrl: f.target.url }, f.signal)
    assert.deepEqual(await (f.driver as any).closeRoom(f.signal), { closed: false, external: true })
    assert.deepEqual(f.navigations, ['about:blank'])
  } finally { await f.driver.close() }
})

test('native shutdown still closes owned resources when platform listener cleanup fails', async () => {
  let localClosed = 0
  const f = fixture({ closeLocalTranslation: async () => { localClosed++ } })
  await f.driver.platform({ accountId: 'a', action: 'open-login' }, f.signal)
  f.platform.stopCommentListener = async () => { throw Error('fixture listener cleanup failed') }
  await assert.rejects(f.driver.close())
  assert.equal(f.counts().closedOwned, 1)
  assert.equal(localClosed, 1)
})

test('a browser created after shutdown is released without adoption and no new platform operation can reopen the driver', async () => {
  let release!: (session: any) => void, closed = 0, created = 0
  const candidate = { ownership: 'owned', page: { isClosed: () => false }, context: { close: async () => { closed++ } } }
  const f = fixture({ createBrowser: async () => { created++; return new Promise(resolve => { release = resolve }) } })
  const controller = new AbortController()
  const opening = f.driver.platform({ accountId: 'a', action: 'open-login' }, controller.signal)
  controller.abort()
  await f.driver.close()
  release(candidate)
  await assert.rejects(opening)
  assert.equal(closed, 1, 'late owned browser must be released instead of surviving shutdown')
  await assert.rejects(f.driver.platform({ accountId: 'a', action: 'open-login' }, f.signal))
  await assert.rejects(f.driver.start(() => {}, f.signal))
  assert.equal(created, 1)
})

test('model HTTP failures cancel the unread response and never retry or disclose credentials', async () => {
  let calls = 0, cancelled = 0
  const model = nativeModel({ baseUrl: 'https://fixture.invalid/v1', model: 'fixture', apiKey: 'PRIVATE-FIXTURE-KEY' }, async () => {
    calls++
    return new Response(new ReadableStream({ cancel: () => { cancelled++ } }), { status: 401 })
  })
  await assert.rejects(model([{ role: 'user', content: 'fixture' }], new AbortController().signal), error => !String(error).includes('PRIVATE-FIXTURE-KEY'))
  assert.equal(calls, 1); assert.equal(cancelled, 1)
})

test('host shutdown cancels only the microphone started by this bridge and does not cancel external recording', async () => {
  for (const external of [false, true]) {
    let recording = external
    const paths: string[] = []
    const f = fixture({ voice: async (path: string) => {
      paths.push(path)
      if (path === '/api/state') return { recording, busy: null }
      if (path === '/api/rec/start') { recording = true; return { ok: true } }
      if (path === '/api/rec/cancel') { recording = false; return { ok: true, recording: false } }
      assert.fail('Recognition must never be run during shutdown')
    } })
    if (external) await assert.rejects(f.driver.voice('/api/rec/start', f.signal))
    else assert.equal((await f.driver.voice('/api/rec/start', f.signal) as any).ok, true)
    await f.driver.close()
    assert.equal(recording, external)
    assert.equal(paths.filter(path => path === '/api/rec/cancel').length, external ? 0 : 1)
    assert.equal(paths.filter(path => path === '/api/rec/start').length, external ? 0 : 1)
  }
})

test('an uncertain pending voice start is cancelled after shutdown without publishing late recognition', async () => {
  let entered!: () => void
  const starting = new Promise<void>(resolve => { entered = resolve })
  let recording = false, cancels = 0
  const f = fixture({ voice: async (path: string, signal: AbortSignal) => {
    if (path === '/api/state') return { recording, busy: null }
    if (path === '/api/rec/start') {
      entered()
      await new Promise<void>(resolve => signal.addEventListener('abort', () => resolve(), { once: true }))
      recording = true; return { ok: true }
    }
    if (path === '/api/rec/cancel') { cancels++; recording = false; return { ok: true, recording: false } }
    assert.fail('Shutdown must cancel, never recognize')
  } })
  const pending = f.driver.voice('/api/rec/start', f.signal)
  void pending.catch(() => {})
  await starting
  await f.driver.close()
  await assert.rejects(pending)
  assert.equal(recording, false); assert.equal(cancels, 1)
})

test('shutdown waits for a detached service start to leave its busy state before confirming microphone cleanup', { timeout: 3000 }, async () => {
  let enter!: () => void
  const entered = new Promise<void>(resolve => { enter = resolve })
  let serviceStarting = false, recording = false, cancels = 0, busyReads = 0
  const f = fixture({ voice: async (path: string, signal: AbortSignal) => {
    if (path === '/api/state') {
      if (serviceStarting && !busyReads++) setTimeout(() => { serviceStarting = false; recording = true }, 20)
      return { recording, busy: serviceStarting ? 'recStart' : null }
    }
    if (path === '/api/rec/start') {
      serviceStarting = true; enter()
      await new Promise<void>(resolve => signal.addEventListener('abort', () => resolve(), { once: true }))
      throw Error('The client request disconnected, but the service start is still running')
    }
    if (path === '/api/rec/cancel') { cancels++; recording = false; return { ok: true, recording: false } }
    assert.fail('Shutdown must not run recognition')
  } })
  const pending = f.driver.voice('/api/rec/start', f.signal)
  void pending.catch(() => {})
  await entered
  await f.driver.close()
  await assert.rejects(pending)
  assert.equal(cancels, 1, 'busy with recording=false is still an uncertain owned start')
  assert.equal(recording, false)
})

test('a definite busy start refusal never grants ownership and confirmed no-text stop releases it', async () => {
  for (const startRejected of [false, true]) {
    let recording = false, cancels = 0
    const f = fixture({ voice: async (path: string) => {
      if (path === '/api/state') return { recording, busy: null }
      if (path === '/api/rec/start') {
        recording = true
        return startRejected ? { ok: false, error: 'busy' } : { ok: true }
      }
      if (path === '/api/rec/stop') { recording = false; return { ok: false, error: 'no_text' } }
      if (path === '/api/rec/cancel') { cancels++; recording = false; return { ok: true, recording: false } }
    } })
    await f.driver.voice('/api/rec/start', f.signal)
    if (!startRejected) {
      await f.driver.voice('/api/rec/stop', f.signal)
      recording = true // A different application begins a later dictation.
    }
    await assert.rejects(f.driver.voice('/api/rec/cancel', f.signal))
    await f.driver.close()
    assert.equal(recording, true)
    assert.equal(cancels, 0, 'the bridge cannot clean another application’s microphone')
  }
})

test('unconfirmed microphone cancellation reports shutdown failure while still releasing other owned resources', async () => {
  let localClosed = 0, recording = false
  const f = fixture({ closeLocalTranslation: async () => { localClosed++ }, voice: async (path: string) => {
    if (path === '/api/state') return { recording, busy: null }
    if (path === '/api/rec/start') { recording = true; return { ok: true } }
    if (path === '/api/rec/cancel') return { ok: true, recording: true }
  } })
  await f.driver.platform({ accountId: 'a', action: 'open-login' }, f.signal)
  await f.driver.voice('/api/rec/start', f.signal)
  await assert.rejects(f.driver.close())
  assert.equal(f.counts().closedOwned, 1)
  assert.equal(localClosed, 1)
})

test('native model uses real bounded chat completions once and reuses the existing translation contracts', async t => {
  const requests: any[] = []
  const server = createServer(async (request, response) => {
    let body = ''; for await (const part of request) body += part
    const parsed = JSON.parse(body); requests.push({ path: request.url, authorization: request.headers.authorization, body: parsed })
    const user = JSON.parse(parsed.messages[1].content)
    const content = user.sourceChinese ? { targetLanguage: user.targetLanguage, text: 'Welcome.' } : { sourceLanguage: 'und', translatedCommentChinese: '', replyText: 'Welcome.', translatedReplyChinese: '欢迎。', needsReview: true, knowledgeEvidence: [] }
    response.setHeader('Content-Type', 'application/json'); response.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify(content) } }] }))
  })
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
  t.after(() => new Promise<void>(resolve => server.close(() => resolve())))
  const port = (server.address() as { port: number }).port
  const f = fixture({ model: nativeModel({ baseUrl: `http://127.0.0.1:${port}/v1`, model: 'fixture-model', apiKey: 'fixture-provider-key' }) })
  try {
    const result = await f.driver.translateDraft({ chinese: '欢迎。', targetLanguage: 'en' }, f.signal)
    assert.equal(result, 'Welcome.')
    const context = { knowledge: '', instructions: '', translationEnabled: false, replyMode: 'review', replyTargetLanguage: 'en' }
    const event = { action: 'enter', text: '', nickname: 'Viewer' }
    const interpreted = await f.driver.interpret(`Frame.\nCONTROLLED_CONTEXT=${JSON.stringify(context)}\nUNTRUSTED_EVENT=${JSON.stringify(event)}\nUNTRUSTED_COMMENT=${JSON.stringify({ text: '', nickname: 'Viewer' })}`, f.signal)
    assert.equal(JSON.parse(interpreted).language, 'und')
    assert.equal(requests.length, 2)
    assert.ok(requests.every(request => request.path === '/v1/chat/completions' && request.authorization === 'Bearer fixture-provider-key' && request.body.model === 'fixture-model'))
  } finally { await f.driver.close() }
})

test('native build imports and --check runs in Node without Electron, Chrome, microphone or provider side effects', { timeout: 30000 }, () => {
  execFileSync(process.execPath, ['scripts/build-host-bridge.mjs'], { cwd: resolve('.'), stdio: 'pipe' })
  const imported = execFileSync(process.execPath, ['--input-type=module', '-e', "const bridge=await import('./dist-host-bridge/index.mjs');console.log(typeof bridge.HostBridgeServer,typeof bridge.createNativeHostDriver)"], { cwd: resolve('.'), encoding: 'utf8' })
  assert.match(imported, /function function/)
  const resources = execFileSync(process.execPath, ['--input-type=module', '-e', "const P=await import('tiktok-live-proto/v3');const x=P.WebcastChatMessage.encode({...P.WebcastChatMessage.decode(new Uint8Array()),content:'fixture-resource'}).finish();if(P.WebcastChatMessage.decode(x).content!=='fixture-resource')throw Error('protobuf resource failure');const sdk=await import('tiktok-live-connector');if(typeof sdk.TikTokLiveConnection!=='function')throw Error('SDK resource failure');const playwright=await import('playwright');if(typeof playwright.chromium.launchPersistentContext!=='function')throw Error('Playwright runtime failure');console.log('runtime-resources-ok')"], { cwd: resolve('dist-host-bridge'), encoding: 'utf8' })
  assert.match(resources, /runtime-resources-ok/)
  const checked = execFileSync(process.execPath, ['dist-host-bridge/index.mjs', '--check'], { cwd: resolve('.'), encoding: 'utf8', env: { ...process.env, OBA_HOST_TOKEN: 'fixture-host-secret-at-least-32-characters', OBA_HOST_TOKEN_FILE: '', OBA_AI_API_KEY: '', OBA_AI_API_KEY_FILE: '', OBA_OBS_URL: '', OBA_VOICE_URL: '' } })
  assert.equal(JSON.parse(checked).platform.browserOpen, false)
  assert.equal(checked.includes('fixture-host-secret'), false)
})
