import type {
  AttributeDefinition,
  PublishedAttributeDictionary,
} from '../../shared/audienceAttributes'
import { captureScope } from './analysisCaptureFixture'

export function definition(overrides: Partial<AttributeDefinition> = {}): AttributeDefinition {
  return {
    id: 'level',
    name: '用户等级',
    type: 'integer',
    semantic: 'basic',
    candidates: [{ path: '/user/level', priority: 1 }],
    ...overrides,
  }
}
export function dictionary(
  overrides: Partial<PublishedAttributeDictionary> = {},
): PublishedAttributeDictionary {
  return {
    platform: captureScope.platform,
    source: captureScope.source,
    version: 1,
    publishedAt: 500,
    acceptedFormatVersions: [1],
    identity: { userIdPath: '/user/uid', nicknamePath: '/user/name' },
    definitions: [
      definition(),
      definition({
        id: 'followed',
        name: '是否关注',
        type: 'boolean',
        semantic: 'follow',
        candidates: [{ path: '/user/followed', priority: 1 }],
      }),
    ],
    ...overrides,
  }
}
