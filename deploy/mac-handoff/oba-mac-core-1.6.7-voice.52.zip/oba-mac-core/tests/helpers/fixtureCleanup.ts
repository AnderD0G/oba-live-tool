const cleanups = new Map<string, Set<() => void | Promise<void>>>()
export function registerFixtureCleanup(root: string, close: () => void | Promise<void>) {
  let set = cleanups.get(root)
  if (!set) {
    set = new Set()
    cleanups.set(root, set)
  }
  set.add(close)
}
export async function closeFixtureResources(root: string) {
  const set = cleanups.get(root)
  cleanups.delete(root)
  let failure: unknown
  for (const close of [...(set ?? [])].reverse()) {
    try {
      await close()
    } catch (error) {
      failure ??= error
    }
  }
  if (failure) throw failure
}
