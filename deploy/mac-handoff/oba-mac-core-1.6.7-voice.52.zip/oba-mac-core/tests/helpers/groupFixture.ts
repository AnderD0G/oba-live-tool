import { mapObservation } from '../../electron/main/services/analysisRoom/AttributeMapper'
import type {
  AudienceGroup,
  AudienceGroupsConfig,
  GroupEvaluationInput,
} from '../../shared/audienceGroups'
import { businessObservation, captureScope } from './analysisCaptureFixture'
import { dictionary } from './attributeFixture'
export function group(overrides: Partial<AudienceGroup> = {}): AudienceGroup {
  return {
    id: 'vip',
    name: '高等级观众',
    enabled: true,
    platform: 'xiaohongshu',
    source: 'control',
    events: ['viewer.comment'],
    all: [{ field: { kind: 'attribute', id: 'level' }, op: 'gte', value: 20 }],
    priority: 10,
    strategy: {
      channel: 'voice-preferred',
      guidance: '问是否想看新品，不推断购买',
      includeNickname: false,
    },
    ...overrides,
  }
}
export function groups(items = [group()], enabled = true): AudienceGroupsConfig {
  return { enabled, items }
}
export function groupInput(overrides: Partial<GroupEvaluationInput> = {}): GroupEvaluationInput {
  return JSON.parse(
    JSON.stringify({
      scope: captureScope,
      event: 'viewer.comment',
      userId: '00123',
      context: { event: 'viewer.comment', user: { id: '00123', score: 20 }, room: {} },
      attributes: mapObservation(businessObservation(21), dictionary()),
      dictionaryVersion: 1,
      effectiveMode: 'selective',
      ...overrides,
    }),
  )
}
