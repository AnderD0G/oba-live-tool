import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { mkdir, mkdtemp, writeFile, rm, lstat, realpath } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import test, { type TestContext } from 'node:test';
import { stageLegacyCapture } from "../../electron/main/services/analysisRoom/CaptureMigration";
import { createTypedStageSchema } from "../../electron/main/services/analysisRoom/CaptureTypedStageSchema";
import { typedStageImportPolicy } from "../../electron/main/services/analysisRoom/CaptureTypedStageImport";
import { CAPTURE_STORAGE_LIMITS } from "../../electron/main/services/analysisRoom/CaptureStorage";
import { CAPACITY_POLICY_V2 } from "../../electron/main/services/analysisRoom/CaptureCapacityPolicyV2";
import { validateAttributeDraft } from "../../electron/main/services/analysisRoom/AttributeMapper";
import { PreviewProofStore, previewDigest } from "../../electron/main/services/analysisRoom/PreviewProofStore";
import * as dictionary from "../../electron/main/services/analysisRoom/CaptureDictionaryControl";
export const owner = { kind: 'mapping' as const, platform: 'tiktok' as const, source: 'control' as const };
const sha = (v: string | Uint8Array) => createHash('sha256').update(v).digest('hex');
const canonical = (v: unknown): string => v === null || typeof v !== 'object' ? (Object.is(v, -0) ? '-0' : JSON.stringify(v)) : Array.isArray(v) ? '[' + v.map(canonical).join(',') + ']' : '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canonical((v as Record<string, unknown>)[k])).join(',') + '}';
const code = (c: string) => (e: unknown) => (e as {
    code?: string;
}).code === c;
export async function fixture(t: TestContext) {
    const folder = await mkdtemp(join(tmpdir(), 'task70-')), physical = await lstat(folder), root = join(folder, 'source'), identity = { databaseId: randomUUID(), generation: 1, schemaVersion: 1 as const }, file = join(folder, 'capture.pending-' + randomUUID() + '.sqlite');
    await mkdir(join(root, 'dictionaries'), { recursive: true });
    await writeFile(join(root, 'dictionaries', 'tiktok-control.json'), ' {"retained":"原始旧文件"} ');
    await stageLegacyCapture({ root, staging: file, identity, mode: 'create' });
    const db = new DatabaseSync(file);
    t.after(async () => { db.close(); const now = await lstat(folder); assert.equal(now.ino, physical.ino); assert.equal(now.dev, physical.dev); assert.equal(await realpath(folder), folder); assert.equal(resolve(join(folder, '..')), resolve(tmpdir())); await rm(folder, { recursive: true, force: true }); });
    const h = createHash('sha256');
    for (const row of db.prepare('SELECT * FROM legacy_sources ORDER BY id').all())
        for (const v of [row.id, row.relative_path, row.size, row.sha256, row.fingerprint, row.verified]) {
            const b = Buffer.from(String(v));
            h.update(String(b.length) + ':').update(b);
        }
    const base = { identity, runId: randomUUID(), manifestDigest: h.digest('hex'), limits: CAPTURE_STORAGE_LIMITS, policy: typedStageImportPolicy(CAPTURE_STORAGE_LIMITS, 0) };
    await createTypedStageSchema(db, base);
    return { db, identity, file, binding: { base, policy: CAPACITY_POLICY_V2 } };
}
export const small = () => validateAttributeDraft({ identity: { userIdPath: '/id' }, acceptedFormatVersions: [1, 2], definitions: [{ id: 'flag', name: '标识', type: 'enum', semantic: 'basic', candidates: [{ path: '/flag', priority: 0 }], enumValues: [0, false, 'zero'], conversion: { kind: 'table', entries: [{ from: '0', to: 0 }, { from: false, to: false }] } }] });
function rowsFor(draft: ReturnType<typeof small>): any[] { const result: any[] = []; draft.acceptedFormatVersions.forEach((value, n) => result.push({ kind: 'format', ordinal: n + 1, value })); draft.definitions.forEach((d, n) => result.push({ kind: 'definition', ordinal: n + 1, id: d.id, name: d.name, type: d.type, semantic: d.semantic, ...d.ttlMs === undefined ? {} : { ttlMs: d.ttlMs }, ...d.conversion ? { conversionKind: d.conversion.kind } : {} })); draft.definitions.forEach((d, n) => d.candidates.forEach((c, i) => result.push({ kind: 'candidate', definitionOrdinal: n + 1, ordinal: i + 1, ...c }))); draft.definitions.forEach((d, n) => d.enumValues?.forEach((value, i) => result.push({ kind: 'enum', definitionOrdinal: n + 1, ordinal: i + 1, value }))); draft.definitions.forEach((d, n) => { if (d.conversion?.kind === 'table')
    d.conversion.entries.forEach((e, i) => result.push({ kind: 'entry', definitionOrdinal: n + 1, ordinal: i + 1, ...e })); }); return result; }
function digestRows(rows: any[]) { let digest = '0'.repeat(64); for (const row of rows) {
    const body = canonical(row);
    digest = sha(digest + ':' + Buffer.byteLength(body) + ':' + body);
} return digest; }
export async function sealed(f: Awaited<ReturnType<typeof fixture>>, draft = small(), batchSize = 48) {
    const rows = rowsFor(draft), generationId = randomUUID(), counts = { formats: draft.acceptedFormatVersions.length, definitions: draft.definitions.length, candidates: rows.filter(r => r.kind === 'candidate').length, enums: rows.filter(r => r.kind === 'enum').length, entries: rows.filter(r => r.kind === 'entry').length };
    let ack = dictionary.prepareDictionaryGeneration(f.db, f.binding, { operationId: randomUUID(), owner, generationId, expectedDictionaryRevision: dictionary.dictionaryHead(f.db, f.binding, owner)?.revision ?? 0, identity: draft.identity, expectedCounts: counts, contentDigest: digestRows(rows) });
    for (let start = 0; start < rows.length; start += batchSize)
        ack = dictionary.appendDictionaryRows(f.db, f.binding, { operationId: randomUUID(), owner, generationId, expectedStageRevision: ack.resultStageRevision, rows: rows.slice(start, start + batchSize) });
    for (let n = 0; n < 200 && ack.phase !== 'sealed'; n++)
        ack = dictionary.verifyDictionaryGenerationStep(f.db, f.binding, { operationId: randomUUID(), owner, generationId, expectedStageRevision: ack.resultStageRevision });
    assert.equal(ack.phase, 'sealed');
    return { generationId, ack, rows };
}
