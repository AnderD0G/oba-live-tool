import { join } from 'node:path'
import type { TestContext } from 'node:test'
import {
  AnalysisCaptureStore,
  NODE_CAPTURE_IO,
} from '../../electron/main/services/analysisRoom/AnalysisCaptureStore'
import { AnalysisQueries } from '../../electron/main/services/analysisRoom/AnalysisQueries'
import { AnalysisReanalyzer } from '../../electron/main/services/analysisRoom/AnalysisReanalyzer'
import { AnalysisRoomApi } from '../../electron/main/services/analysisRoom/AnalysisRoomApi'
import { AnalysisRoomRuntime } from '../../electron/main/services/analysisRoom/AnalysisRoomRuntime'
import { AnalysisRoomService } from '../../electron/main/services/analysisRoom/AnalysisRoomService'
import { AttributeDictionaryService } from '../../electron/main/services/analysisRoom/AttributeDictionaryService'
import { AudienceGroupService } from '../../electron/main/services/analysisRoom/AudienceGroupService'
import { CommentSubscriptionCoordinator } from '../../electron/main/services/CommentSubscriptionCoordinator'
import { captureDirectory, captureScope as scope } from './analysisCaptureFixture'
import { interactionModuleFixture } from './interactionModuleFixture'
import { registerFixtureCleanup } from './fixtureCleanup'

export async function analysisApiFixture(
  t: TestContext,
  options: {
    onAudit?: ConstructorParameters<typeof AnalysisRoomApi>[0]['onAudit']
    onLifecycle?: (session: import('../../shared/analysisRoom').AnalysisSession) => void
  } = {},
) {
  const root = await captureDirectory(t)
  const module = interactionModuleFixture(root)
  const store = new AnalysisCaptureStore({
    root: join(root, 'analysis'),
    io: { ...NODE_CAPTURE_IO },
  })
  await store.recover()
  let groups!: AudienceGroupService
  let runtime!: AnalysisRoomRuntime
  let connected = true
  let supported = true
  const dictionaries = new AttributeDictionaryService({
    store,
    enabledGroupReferences: (platform, source) => groups.enabledReferences(platform, source),
    onPublished: dictionary =>
      runtime.cache.invalidateDictionary(
        dictionary.platform,
        dictionary.source,
        dictionary.version,
      ),
  })
  await dictionaries.ready
  groups = new AudienceGroupService({
    store,
    repository: module.interactionGroupRepository(),
    dictionary: (platform, source) => dictionaries.published(platform, source),
  })
  let starts = 0
  let stops = 0
  const subscriptions = new CommentSubscriptionCoordinator({
    scope,
    listener: {
      _isCommentListener: true,
      startCommentListener: async () => {
        starts++
      },
      stopCommentListener: async () => {
        stops++
      },
    },
    observeBusiness: () => {},
  })
  const capture = new AnalysisRoomService({ store, subscriptions: () => subscriptions })
  const reanalyzer = new AnalysisReanalyzer({ store, dictionaries })
  runtime = new AnalysisRoomRuntime({
    groups,
    capture,
    dictionary: (platform, source) => dictionaries.published(platform, source),
    scope: () => scope,
  })
  const audit: unknown[] = []
  const changed: unknown[] = []
  const api = new AnalysisRoomApi({
    store,
    capture,
    queries: new AnalysisQueries(store),
    dictionaries,
    groups,
    reanalyzer,
    runtime,
    capabilities: () => ({
      scope,
      connected,
      supported,
      sources: ['control'],
      formatVersion: 1,
      limits: { maxBytes: 131072, maxDepth: 16 },
    }),
    onAudit: event => {
      audit.push(event)
      options.onAudit?.(event)
    },
    onChanged: event => changed.push(event),
    onLifecycle: options.onLifecycle,
  })
  t.after(() => api.shutdown())
  registerFixtureCleanup(root, () => api.shutdown())
  return {
    api,
    store,
    reanalyzer,
    dictionaries,
    groups,
    audit,
    changed,
    starts: () => starts,
    stops: () => stops,
    setConnected: (value: boolean) => {
      connected = value
    },
    setSupported: (value: boolean) => {
      supported = value
    },
  }
}
