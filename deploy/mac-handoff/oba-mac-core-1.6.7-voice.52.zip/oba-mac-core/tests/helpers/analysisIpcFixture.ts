import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { runInThisContext } from 'node:vm'
import { buildSync } from 'esbuild'
import { join } from 'node:path'
import ts from 'typescript'
import { createAnalysisRoomApi } from '../../electron/main/services/analysisRoom/AnalysisRoomApi'
import { CommentSubscriptionCoordinator } from '../../electron/main/services/CommentSubscriptionCoordinator'
import { captureScope as scope } from './analysisCaptureFixture'
import { interactionModuleFixture } from './interactionModuleFixture'
import { registerFixtureCleanup } from './fixtureCleanup'

export function analysisIpcFixture(
  root: string,
  options: { auditWrite?: (entry: unknown) => boolean } = {},
) {
  const source = new URL('../../electron/main/ipc/analysisRoom.ts', import.meta.url)
  const workerFile = join(root, 'fresh-analysis-worker.cjs')
  buildSync({
    entryPoints: [
      fileURLToPath(
        new URL(
          '../../electron/main/services/analysisRoom/FreshAnalysisDatabaseWorker.ts',
          import.meta.url,
        ),
      ),
    ],
    outfile: workerFile,
    bundle: true,
    platform: 'node',
    format: 'cjs',
    target: 'node22',
    logLevel: 'silent',
  })
  const require = createRequire(source)
  const subscriptions = new CommentSubscriptionCoordinator({
    scope,
    listener: {
      _isCommentListener: true,
      startCommentListener: async () => {},
      stopCommentListener: async () => {},
    },
    observeBusiness: () => {},
  })
  const handlers = new Map<string, Array<(input: any) => void>>()
  const audit: unknown[] = []
  const changes: unknown[] = []
  const quitHandlers: Array<(event: { preventDefault(): void }) => void> = []
  let ipc: any
  let quits = 0
  const session = {
    getAnalysisScope: () => scope,
    getAnalysisCapabilities: () => ({
      scope,
      connected: true,
      supported: true,
      sources: ['control'],
      formatVersion: 1,
      limits: { maxBytes: 131072, maxDepth: 16 },
    }),
    getCommentSubscriptions: () => subscriptions,
  }
  const interaction = interactionModuleFixture(root)
  const modules: Record<string, unknown> = {
    '../services/analysisRoom/AnalysisRoomApi': {
      createAnalysisRoomApi: async (options: Parameters<typeof createAnalysisRoomApi>[0]) => {
        const api = await createAnalysisRoomApi({ ...options, workerFile })
        registerFixtureCleanup(root, () => api.shutdown())
        return api
      },
    },
    electron: {
      app: {
        getPath: () => root,
        on: (event: string, fn: any) => {
          if (event === 'before-quit') quitHandlers.push(fn)
        },
        quit: () => {
          quits++
        },
      },
    },
    '../event/eventBus': {
      emitter: {
        on: (event: string, fn: any) => handlers.set(event, [...(handlers.get(event) ?? []), fn]),
      },
    },
    '../managers/AccountManager': {
      accountManager: { accountSessions: new Map([[scope.accountId, session]]) },
    },
    '../utils/ipc': {
      typedIpcMainHandle: (_: string, fn: any) => {
        ipc = fn
      },
    },
    '../windowManager': { default: { send: (_: string, event: unknown) => changes.push(event) } },
    './interactionRouting': interaction,
    './audit': {
      recordAudit: (entry: unknown) => {
        audit.push(entry)
        return options.auditWrite?.(entry) ?? true
      },
    },
    './hooks': { getAnalysisHookSummaries: () => [] },
  }
  const compiled = ts.transpileModule(readFileSync(source, 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText
  const exports: any = {}
  runInThisContext(`(function(require,exports){\n${compiled}\n})`, {
    filename: fileURLToPath(source),
  })((id: string) => modules[id] ?? require(id), exports)
  return {
    exports,
    audit,
    changes,
    handlers,
    subscriptions,
    call: (command: unknown) => ipc(undefined, command),
    quitHandlers,
    quits: () => quits,
    emit: (event: string, input: unknown) => {
      for (const fn of handlers.get(event) ?? []) fn(input)
    },
  }
}
