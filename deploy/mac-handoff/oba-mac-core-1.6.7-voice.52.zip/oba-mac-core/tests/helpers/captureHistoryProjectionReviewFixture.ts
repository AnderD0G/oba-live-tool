import assert from 'node:assert/strict'
import {randomUUID,createHash} from 'node:crypto'
import {mkdtemp,mkdir,writeFile,rm} from 'node:fs/promises'
import {tmpdir} from 'node:os'
import {join,resolve,sep} from 'node:path'
import {DatabaseSync} from 'node:sqlite'
import test,{type TestContext} from 'node:test'
import {stageLegacyCapture} from "../../electron/main/services/analysisRoom/CaptureMigration"
import {CAPTURE_STORAGE_LIMITS} from "../../electron/main/services/analysisRoom/CaptureStorage"
import {createTypedStageSchema,type TypedStageBinding} from "../../electron/main/services/analysisRoom/CaptureTypedStageSchema"
import {beginSessionImport,stepSessionImport,typedStageImportPolicy} from "../../electron/main/services/analysisRoom/CaptureTypedStageImport"
import {HistoryProjection} from "../../electron/main/services/analysisRoom/CaptureHistoryProjection"
export async function fixture(t:TestContext,count=4,attributes=4,bad=false,options:{metadata?:Record<string,unknown>;sequences?:number[];unknown?:boolean;text?:string;allStrings?:boolean;uppercase?:boolean}={}){
 const folder=await mkdtemp(join(tmpdir(),'task79-peer-')),root=join(folder,'legacy'),sessionId=randomUUID(),jobId=options.uppercase?randomUUID().toUpperCase():randomUUID(),scope={accountId:'account-79',platform:'tiktok' as const,source:'control' as const}
 const session={id:sessionId,scope,status:'completed',complete:true,createdAt:0,stoppedAt:0,bytes:0,formatVersion:1,counters:{received:0,saved:0,dropped:0,pending:0,parseFailed:0,redacted:0}}
 const job={id:jobId,scope,sessionId,mappingVersion:3,status:'completed' as const,received:count,saved:count,createdAt:0,finishedAt:0}
 const dictionary={platform:scope.platform,source:scope.source,version:3,publishedAt:0,identity:{userIdPath:'/id'},acceptedFormatVersions:[1],definitions:Array.from({length:attributes},(_,i)=>({id:'a'+i,name:'a'+i,type:(i===1?'boolean':i===2||options.allStrings&&i>=2?'string':'integer') as 'boolean'|'string'|'integer',semantic:'basic' as const,candidates:[{path:'/a'+i,priority:0}]}))}
 const p={scope,observationId:'fact',sequence:0,streamId:'stream',observedAt:0,mappingVersion:3,timeBasis:'local-sequence' as const,expiresAt:0}
 const snapshot={origin:'history',scope,userId:'0001234567890123456789',nickname:'\ud800',mappingVersion:3,observationId:'snapshot',sequence:0,streamId:'stream',observedAt:0,values:Object.fromEntries(dictionary.definitions.map((d,i)=>[d.id,options.unknown&&i===0?{...p,type:d.type,status:'unknown',reason:'MISSING',platformTime:0,path:'/zero'}:{...p,type:d.type,status:'known',value:i===1?false:d.type==='string'?options.text??'\ud800':0}]))}
 await mkdir(join(root,'sessions',sessionId),{recursive:true});await mkdir(join(root,'history',jobId),{recursive:true})
 await writeFile(join(root,'sessions',sessionId,'metadata.json'),JSON.stringify(session));await writeFile(join(root,'history',jobId,'metadata.json'),JSON.stringify({...job,...options.metadata}))
 const lines=Array.from({length:count},(_,i)=>JSON.stringify({resultSequence:options.sequences?.[i]??i+1,snapshot}).replace('"value":0','"value":-0')+'\n')
 if(bad)lines.splice(1,0,'malformed\n')
 await writeFile(join(root,'history',jobId,'000000.jsonl'),lines.join(''))
 const identity={databaseId:randomUUID(),generation:1,schemaVersion:1 as const},file=join(folder,`capture.pending-${randomUUID()}.sqlite`)
 await stageLegacyCapture({root,staging:file,identity,mode:'create'});const db=new DatabaseSync(file)
 const closers:Array<()=>void>=[]
 t.after(async()=>{for(const close of closers)close();db.close();assert.ok(resolve(folder).startsWith(resolve(tmpdir())+sep));assert.ok(folder.includes('task79-'));await rm(folder,{recursive:true,force:true})})
 const h=createHash('sha256');for(const row of db.prepare('SELECT * FROM legacy_sources ORDER BY id').all())for(const value of [row.id,row.relative_path,row.size,row.sha256,row.fingerprint,row.verified]){const bytes=Buffer.from(String(value));h.update(String(bytes.length)+':').update(bytes)}
 const limits={...CAPTURE_STORAGE_LIMITS},binding:TypedStageBinding={identity,runId:randomUUID(),manifestDigest:h.digest('hex'),limits,policy:typedStageImportPolicy(limits,123)}
 await createTypedStageSchema(db,binding);let ack=beginSessionImport(db,binding,{operationId:randomUUID(),expectedRevision:0});while(ack.cursor.phase!=='metadata-complete')ack=stepSessionImport(db,binding,{operationId:randomUUID(),expectedRevision:ack.resultRevision})
 const metaId=Number(db.prepare('SELECT id FROM legacy_sources WHERE relative_path=?').get(`history/${jobId}/metadata.json`)!.id),resultId=Number(db.prepare('SELECT id FROM legacy_sources WHERE relative_path=?').get(`history/${jobId}/000000.jsonl`)!.id)
 const spans=db.prepare('SELECT start_offset,next_offset FROM legacy_lines WHERE source_id=? ORDER BY line').all(resultId).map(r=>({sourceId:resultId,startOffset:Number(r.start_offset),nextOffset:Number(r.next_offset)}))
 return {folder,file,db,binding,scope,jobId,sessionId,job,dictionary,snapshot,metaId,spans,closers}
}
