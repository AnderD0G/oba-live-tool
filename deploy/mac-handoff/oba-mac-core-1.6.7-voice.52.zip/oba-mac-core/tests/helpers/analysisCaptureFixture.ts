import { randomUUID } from 'node:crypto'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import type { TestContext } from 'node:test'
import type { BusinessObservation } from '../../shared/analysisRoom'
import { closeFixtureResources } from './fixtureCleanup'

export const captureScope = {
  accountId: '账号A',
  platform: 'xiaohongshu' as const,
  source: 'control' as const,
}
export function businessObservation(
  sequence: number,
  overrides: Partial<BusinessObservation> = {},
): BusinessObservation {
  return {
    scope: captureScope,
    observationId: randomUUID(),
    streamId: 'stream-1',
    sequence,
    receivedAt: 1000 + sequence,
    formatVersion: 1,
    businessType: 'future',
    roomId: 'room-1',
    data: { user: { uid: '00123', level: sequence, followed: false } },
    complete: true,
    removedPaths: [],
    truncatedPaths: [],
    ...overrides,
  }
}
export async function captureDirectory(t: TestContext, beforeCleanup?: () => Promise<void>): Promise<string> {
  const root = await mkdtemp(join(tmpdir(), 'oba-analysis-capture-'))
  t.after(async () => {
    await beforeCleanup?.()
    if (dirname(root) !== resolve(tmpdir()) || !basename(root).startsWith('oba-analysis-capture-'))
      throw new Error('Unsafe test cleanup path')
    await closeFixtureResources(root)
    await rm(root, { recursive: true, force: true })
  })
  return root
}
export function gate() {
  let resolve!: () => void
  const promise = new Promise<void>(yes => {
    resolve = yes
  })
  return { promise, resolve }
}
