import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { runInThisContext } from 'node:vm'
import ts from 'typescript'
import { registerFixtureCleanup } from './fixtureCleanup'
import type * as ProductionModule from '../../electron/main/ipc/interactionRouting'

const source = new URL('../../electron/main/ipc/interactionRouting.ts', import.meta.url)
const sourceRequire = createRequire(source)
export function interactionModuleFixture(root: string): typeof ProductionModule {
  const compiled = ts.transpileModule(readFileSync(source, 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText
  const modules: Record<string, unknown> = {
    electron: { app: { getPath: () => root, on() {} } },
    '#/event/eventBus': { emitter: { on() {} } },
    '../managers/AccountManager': {
      accountManager: {
        accountSessions: new Map(),
        accountNames: new Map([['账号A', '账号A']]),
        getAccountName: (id: string) => id,
      },
    },
    './audit': { recordAudit() {} },
  }
  const module = { exports: {} }
  const execute = runInThisContext(`(function(require,module,exports){${compiled}\n})`, {
    filename: source.pathname,
  })
  execute((id: string) => modules[id] ?? sourceRequire(id), module, module.exports)
  const result = module.exports as typeof ProductionModule
  registerFixtureCleanup(root, () => result.closeInteractionRoutingDatabase())
  return result
}
