import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import test from 'node:test'

test('the independent bundle starts without Electron, serves real persisted state and shuts down', { timeout: 20000 }, async t => {
  const script = resolve('scripts/build-server.mjs')
  assert.ok(await readFile(script).catch(() => undefined), 'independent server build script exists')
  await new Promise<void>((done, reject) => { const child = spawn(process.execPath, [script], { stdio: 'pipe', windowsHide: true }); let error = ''; child.stderr.on('data', data => { error += data }); child.once('error', reject); child.once('exit', code => code === 0 ? done() : reject(Error(error))) })
  const folder = await mkdtemp(join(tmpdir(), 'oba-server-entry-'))
  const child = spawn(process.execPath, [resolve('dist-server/main.cjs')], { env: { ...process.env, OBA_DATA_DIR: folder, OBA_ADMIN_HOST: '127.0.0.1', OBA_MOBILE_HOST: '127.0.0.1', OBA_ADMIN_PORT: '0', OBA_MOBILE_PORT: '0', OBA_MOBILE_ADDRESS: '127.0.0.1', OBA_ADMIN_TOKEN: 'fixture-admin-token-at-least-24-characters', OBA_HOST_BRIDGE_URL: '', OBA_HOST_BRIDGE_TOKEN: '' }, windowsHide: true, stdio: ['pipe','pipe','pipe','ipc'] })
  const exited = new Promise<number | null>(done => child.once('exit', done))
  t.after(async () => { if (child.exitCode === null) child.kill(); await exited; await rm(folder, { recursive: true, force: true }) })
  const ready = await new Promise<any>((done, reject) => {
    let buffer = ''; const timeout = setTimeout(() => reject(Error('independent server startup timed out')), 8000)
    child.stdout.on('data', data => { buffer += data; const line = buffer.split('\n').find(value => value.startsWith('{')); if (line) { clearTimeout(timeout); done(JSON.parse(line)) } })
    child.once('exit', code => { clearTimeout(timeout); reject(Error(`server exited ${code}`)) })
  })
  const response = await fetch(ready.adminUrl + '/api/state', { headers: { Authorization: 'Bearer fixture-admin-token-at-least-24-characters' } })
  const body = await response.json() as any
  assert.equal(body.ok, true); assert.equal(body.data.database.engine, 'sqlite')
  assert.equal(body.data.activeSession, undefined)
  const html = await fetch(ready.adminUrl + '/').then(response => response.text())
  assert.ok(html.includes('开始采集')); assert.ok(html.includes('手机入口'))
  child.send('shutdown')
  await exited
  assert.equal(child.exitCode, 0)
})
