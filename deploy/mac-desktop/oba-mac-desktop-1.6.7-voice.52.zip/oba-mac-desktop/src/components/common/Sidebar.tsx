import { ClipboardList, Filter, FlaskConical, Languages, Printer, Sparkles, Workflow } from 'lucide-react'
import { NavLink } from 'react-router'
import { autoReplyPlatforms } from '@/abilities'
import { useCurrentAutoMessage } from '@/hooks/useAutoMessage'
import { useCurrentAutoPopUp } from '@/hooks/useAutoPopUp'
import { useAutoReply } from '@/hooks/useAutoReply'
import { useCurrentLiveControl } from '@/hooks/useLiveControl'
import { cn } from '@/lib/utils'
import {
  CarbonBlockStorage,
  CarbonChat,
  CarbonContentDeliveryNetwork,
  CarbonGift,
  CarbonIbmEventAutomation,
  CarbonIbmWatsonTextToSpeech,
  CarbonSettings,
} from '../icons/carbon'

interface SidebarTab {
  id: string
  name: string
  isRunning?: boolean
  icon: React.ReactNode
  platform?: LiveControlPlatform[]
}

export default function Sidebar() {
  const isAutoMessageRunning = useCurrentAutoMessage(context => context.isRunning)
  const isAutoPopupRunning = useCurrentAutoPopUp(context => context.isRunning)
  const { isRunning: isAutoReplyRunning } = useAutoReply()
  const platform = useCurrentLiveControl(context => context.platform)

  const tabs: SidebarTab[] = [
    { id: '/director', name: '互动导播', icon: <Workflow className="w-5 h-5" /> },
    { id: '/assistant-desk', name: '实时助播台', icon: <Languages className="w-5 h-5" /> },
    { id: '/audit', name: '互动审查日志', icon: <ClipboardList className="w-5 h-5" /> },
    { id: '/setup', name: '安装与环境检查', icon: <CarbonSettings className="w-5 h-5" /> },
    { id: '/comment-catcher', name: '弹幕捕手', icon: <Filter className="w-5 h-5" /> },
    { id: '/capture-printing', name: '扣号打印', icon: <Printer className="w-5 h-5" /> },
    {
      id: '/',
      name: '打开中控台',
      icon: <CarbonContentDeliveryNetwork className="w-5 h-5" />,
    },
    { id: '/analysis-room', name: '自动分析室', icon: <FlaskConical className="w-5 h-5" /> },
    {
      id: '/auto-message',
      name: '自动发言',
      isRunning: isAutoMessageRunning,
      icon: <CarbonChat className="w-5 h-5" />,
    },
    {
      id: '/auto-popup',
      name: '自动弹窗',
      isRunning: isAutoPopupRunning,
      icon: <CarbonBlockStorage className="w-5 h-5" />,
    },
    {
      id: '/auto-reply',
      name: '自动回复',
      isRunning: isAutoReplyRunning,
      icon: <CarbonIbmEventAutomation className="w-5 h-5" />,
      platform: autoReplyPlatforms,
    },
    {
      id: '/obs-effect',
      name: 'OBS 设置',
      icon: <Sparkles className="w-5 h-5" />,
    },
    {
      id: '/hooks',
      name: '钩子设置',
      icon: <Workflow className="w-5 h-5" />,
    },
    {
      id: '/red-packet',
      name: '一键发红包',
      icon: <CarbonGift className="w-5 h-5" />,
      platform: ['douyin', 'buyin'],
    },
    {
      id: '/ai-chat',
      name: 'AI 助手',
      icon: <CarbonIbmWatsonTextToSpeech className="w-5 h-5" />,
    },
    {
      id: '/settings',
      name: '应用设置',
      icon: <CarbonSettings className="w-5 h-5" />,
    },
  ]

  const filteredTabs = tabs.filter(tab => {
    if (tab.platform) {
      return tab.platform.includes(platform)
    }
    return true
  })

  return (
    <aside className="h-full w-64 min-w-[256px] overflow-y-auto bg-background border-r">
      <div className="p-6">
        <h2 className="text-lg font-semibold mb-6">功能列表</h2>
        <nav className="space-y-2">
          {filteredTabs.map(tab => (
            <NavLink
              key={tab.id}
              to={tab.id}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all relative',
                  isActive
                    ? 'bg-primary/10 text-primary shadow-xs'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                )
              }
            >
              {tab.icon}
              {tab.name}
              {tab.isRunning && (
                <span className="absolute right-3 w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              )}
            </NavLink>
          ))}
        </nav>
      </div>
    </aside>
  )
}
